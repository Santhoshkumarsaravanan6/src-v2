import * as React from 'react';

import { Icon, c } from '../ui';
import { img } from '../images';

/** Innovation page. Layout and styling come from SalesHome.module.scss. */
const InnovationPage: React.FC = () => (
  <>
    <div className={c('hero sm')}>
      <img className={c('art')} src={img.hero} alt="" />
      <div className={c('copy')}>
        <div className={c('cr')}>Home &nbsp;/&nbsp; Innovation</div>
        <h1>Innovation</h1>
        <p>Launch-ready concepts, trend intelligence and a searchable ingredient and claims library.</p>
        <a className={c('btn')}>
          Browse launch-ready concepts
          {' '}
          <Icon n="arrowr" s={17} sw={2} />
        </a>
      </div>
      <div className={c('panel')}>
        <div className={c('fac')}>
          <div className={c('ib')}>
            <Icon n="flask" s={28} sw={1.5} />
          </div>
          <div>
            <b>New Formulas</b>
            <span>Launch-ready concepts</span>
          </div>
          <div className={c('ch')}>
            <Icon n="chev" s={24} sw={2} />
          </div>
        </div>
        <div className={c('fac')}>
          <div className={c('ib')}>
            <Icon n="trend" s={28} sw={1.5} />
          </div>
          <div>
            <b>Trend Reports</b>
            <span>Quarterly insights</span>
          </div>
          <div className={c('ch')}>
            <Icon n="chev" s={24} sw={2} />
          </div>
        </div>
      </div>
    </div>
    <div className={c('tiles')} style={{ '--c': 'repeat(4,1fr)' } as React.CSSProperties}>
      <a className={c('tile sq')} style={{ background: '#e4f3f6', color: '#0a3f52' } as React.CSSProperties}>
        <Icon n="flask" s={44} sw={1.5} />
        <b>New Formulas</b>
        <span>Launch-ready concepts</span>
      </a>
      <a className={c('tile sq')} style={{ background: '#fff0e8', color: '#b8431c' } as React.CSSProperties}>
        <Icon n="trend" s={44} sw={1.5} />
        <b>Trend Reports</b>
        <span>Market &amp; consumer trends</span>
      </a>
      <a className={c('tile sq')} style={{ background: '#e4f1f8', color: '#0a5f70' } as React.CSSProperties}>
        <Icon n="bulb" s={44} sw={1.5} />
        <b>Innovation Presentations</b>
        <span>Customer-ready decks</span>
      </a>
      <a className={c('tile sq')} style={{ background: '#e3f4ee', color: '#16785f' } as React.CSSProperties}>
        <Icon n="list" s={44} sw={1.5} />
        <b>Ingredient &amp; Claims Library</b>
        <span>Functions, claims &amp; support</span>
      </a>
    </div>
    <div className={c('tabs')}>
      <a className={c('on')}>New Formulas</a>
      <a>Trend Reports</a>
      <a>Presentations</a>
      <a>Ingredient &amp; Claims Library</a>
    </div>
    <div className={c('sh')}>
      <h2>New Formulas &amp; Launch-Ready Concepts</h2>
      <span>Ready to sample or customize</span>
    </div>
    <div className={c('row r4')} style={{ '--c': 'repeat(4,1fr)', marginTop: '16px' } as React.CSSProperties}>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <img src={img.jar} style={{ width: '100%', height: '170px', objectFit: 'cover', background: '#e9f5f8', borderRadius: '6px', marginBottom: '12px' } as React.CSSProperties} alt="" />
        <div style={{ fontSize: '17px', fontWeight: '700', color: 'var(--deep)', marginBottom: '5px' } as React.CSSProperties}>Barrier-repair night cream</div>
        <div style={{ fontSize: '13.5px', color: 'var(--mut)', marginBottom: '10px', lineHeight: '1.4' } as React.CSSProperties}>Ceramide complex, fragrance-free, ready for sampling</div>
        <span className={c('tag')}>Skincare</span>
        {' '}
        <span className={c('tag g')}>Launch-ready</span>
        {' '}
      </div>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <img src={img.dropper} style={{ width: '100%', height: '170px', objectFit: 'cover', background: '#e9f5f8', borderRadius: '6px', marginBottom: '12px' } as React.CSSProperties} alt="" />
        <div style={{ fontSize: '17px', fontWeight: '700', color: 'var(--deep)', marginBottom: '5px' } as React.CSSProperties}>Brightening vitamin C serum</div>
        <div style={{ fontSize: '13.5px', color: 'var(--mut)', marginBottom: '10px', lineHeight: '1.4' } as React.CSSProperties}>Stable 15% format with airless pack option</div>
        <span className={c('tag')}>Skincare</span>
        {' '}
        <span className={c('tag g')}>Launch-ready</span>
        {' '}
      </div>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <img src={img.tube} style={{ width: '100%', height: '170px', objectFit: 'cover', background: '#e9f5f8', borderRadius: '6px', marginBottom: '12px' } as React.CSSProperties} alt="" />
        <div style={{ fontSize: '17px', fontWeight: '700', color: 'var(--deep)', marginBottom: '5px' } as React.CSSProperties}>Tinted mineral SPF 30</div>
        <div style={{ fontSize: '13.5px', color: 'var(--mut)', marginBottom: '10px', lineHeight: '1.4' } as React.CSSProperties}>Sheer finish, reef-safe filters</div>
        <span className={c('tag b')}>OTC</span>
        {' '}
        <span className={c('tag o')}>In development</span>
        {' '}
      </div>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <img src={img.bottle} style={{ width: '100%', height: '170px', objectFit: 'cover', background: '#e9f5f8', borderRadius: '6px', marginBottom: '12px' } as React.CSSProperties} alt="" />
        <div style={{ fontSize: '17px', fontWeight: '700', color: 'var(--deep)', marginBottom: '5px' } as React.CSSProperties}>Scalp-care treatment</div>
        <div style={{ fontSize: '13.5px', color: 'var(--mut)', marginBottom: '10px', lineHeight: '1.4' } as React.CSSProperties}>Sulfate-free, peptide and niacinamide blend</div>
        <span className={c('tag o')}>Haircare</span>
        {' '}
        <span className={c('tag g')}>Launch-ready</span>
        {' '}
      </div>
    </div>
    <div className={c('row r2')} style={{ '--c': '1fr 1fr', marginTop: '22px' } as React.CSSProperties}>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="trend" s={22} sw={1.7} />
            Trend Reports
          </h3>
          <a className={c('vl')}>View all</a>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#e4f1f8', color: '#0a5f70' } as React.CSSProperties}>
            <Icon n="trend" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Clean &amp; skin-first beauty 2027</b>
            <span className={c('s')}>Quarterly report &middot; Nov 2026</span>
          </div>
          <div className={c('ri')}>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#fff0ea', color: '#0a3f52' } as React.CSSProperties}>
            <Icon n="trend" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Scalp care goes mainstream</b>
            <span className={c('s')}>Haircare insight &middot; Oct 2026</span>
          </div>
          <div className={c('ri')}>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#e4f3f6', color: '#0a3f52' } as React.CSSProperties}>
            <Icon n="trend" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Multifunctional color cosmetics</b>
            <span className={c('s')}>Color insight &middot; Sep 2026</span>
          </div>
          <div className={c('ri')}>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
      </div>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="bulb" s={22} sw={1.7} />
            Innovation Presentations
          </h3>
          <a className={c('vl')}>View all</a>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#fff0e8', color: '#b8431c' } as React.CSSProperties}>
            <Icon n="bulb" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Q4 launch-ready concepts</b>
            <span className={c('s')}>Customer-ready deck &middot; 24 slides</span>
          </div>
          <div className={c('ri')}>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#e3f4ee', color: '#16785f' } as React.CSSProperties}>
            <Icon n="bulb" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Hayward innovation lab overview</b>
            <span className={c('s')}>Capabilities deck &middot; 12 slides</span>
          </div>
          <div className={c('ri')}>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#e8eff4', color: '#0e7c8c' } as React.CSSProperties}>
            <Icon n="bulb" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Clean formulation roadmap</b>
            <span className={c('s')}>Strategy deck &middot; 18 slides</span>
          </div>
          <div className={c('ri')}>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
      </div>
    </div>
    <div className={c('row')} style={{ '--c': '1fr', marginTop: '22px' } as React.CSSProperties}>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="list" s={22} sw={1.7} />
            Ingredient &amp; Claims Library
          </h3>
          <a className={c('vl')}>Open full library</a>
        </div>
        <table>
          <tbody>
            <tr className={c('hd')}>
              <th>Ingredient</th>
              <th>Function</th>
              <th>Claims supported</th>
              <th>Category</th>
              <th>Clean status</th>
            </tr>
            <tr>
              <td data-label="Ingredient">
                <b>Niacinamide</b>
              </td>
              <td data-label="Function">Skin conditioning</td>
              <td data-label="Claims supported">Visibly refines pores, evens tone</td>
              <td data-label="Category">Skincare</td>
              <td data-label="Clean status">
                <span className={c('tag g')}>Credo &amp; Sephora</span>
              </td>
            </tr>
            <tr>
              <td data-label="Ingredient">
                <b>Ceramide NP</b>
              </td>
              <td data-label="Function">Barrier support</td>
              <td data-label="Claims supported">Helps restore moisture barrier</td>
              <td data-label="Category">Skincare</td>
              <td data-label="Clean status">
                <span className={c('tag g')}>Credo &amp; Sephora</span>
              </td>
            </tr>
            <tr>
              <td data-label="Ingredient">
                <b>Peptide complex</b>
              </td>
              <td data-label="Function">Scalp conditioning</td>
              <td data-label="Claims supported">Supports a healthy-looking scalp</td>
              <td data-label="Category">Haircare</td>
              <td data-label="Clean status">
                <span className={c('tag g')}>Credo &amp; Sephora</span>
              </td>
            </tr>
            <tr>
              <td data-label="Ingredient">
                <b>Zinc oxide</b>
              </td>
              <td data-label="Function">UV filter</td>
              <td data-label="Claims supported">Broad-spectrum protection</td>
              <td data-label="Category">OTC</td>
              <td data-label="Clean status">
                <span className={c('tag b')}>FDA monograph</span>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </>
);

export default InnovationPage;
