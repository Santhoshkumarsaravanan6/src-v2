import * as React from 'react';

import { Icon, c } from '../ui';
import { img } from '../images';

/** Accounts page. Layout and styling come from SalesHome.module.scss. */
const AccountsPage: React.FC = () => (
  <>
    <div className={c('hero sm')}>
      <img className={c('art')} src={img.hero} alt="" />
      <div className={c('copy')}>
        <div className={c('cr')}>Home &nbsp;/&nbsp; Accounts</div>
        <h1>Accounts</h1>
        <p>Account plans, quarterly business review decks and one-click access to the CRM.</p>
        <a className={c('btn')}>
          Open CRM
          {' '}
          <Icon n="arrowr" s={17} sw={2} />
        </a>
      </div>
      <div className={c('panel')}>
        <div className={c('fac')}>
          <div className={c('ib')}>
            <Icon n="users" s={28} sw={1.5} />
          </div>
          <div>
            <b>Account Plans</b>
            <span>Strategic accounts</span>
          </div>
          <div className={c('ch')}>
            <Icon n="chev" s={24} sw={2} />
          </div>
        </div>
        <div className={c('fac')}>
          <div className={c('ib')}>
            <Icon n="file" s={28} sw={1.5} />
          </div>
          <div>
            <b>CRM</b>
            <span>Open customer records</span>
          </div>
          <div className={c('ch')}>
            <Icon n="chev" s={24} sw={2} />
          </div>
        </div>
      </div>
    </div>
    <div className={c('tiles')} style={{ '--c': 'repeat(3,1fr)' } as React.CSSProperties}>
      <a className={c('tile sq')} style={{ background: '#e4f3f6', color: '#0a3f52' } as React.CSSProperties}>
        <Icon n="users" s={44} sw={1.5} />
        <b>Account Plans</b>
        <span>Plan per strategic account</span>
      </a>
      <a className={c('tile sq')} style={{ background: '#fff0e8', color: '#b8431c' } as React.CSSProperties}>
        <Icon n="trend" s={44} sw={1.5} />
        <b>QBR Decks</b>
        <span>Quarterly business reviews</span>
      </a>
      <a className={c('tile sq')} style={{ background: '#e4f1f8', color: '#0a5f70' } as React.CSSProperties}>
        <Icon n="link" s={44} sw={1.5} />
        <b>CRM</b>
        <span>Customer records &amp; pipeline</span>
      </a>
    </div>
    <div className={c('row r2')} style={{ '--c': '1.4fr 1fr', marginTop: '22px' } as React.CSSProperties}>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="users" s={22} sw={1.7} />
            Account Plans
          </h3>
          <a className={c('vl')}>View all</a>
        </div>
        <table>
          <tbody>
            <tr className={c('hd')}>
              <th>Account</th>
              <th>Segment</th>
              <th>Owner</th>
              <th>Stage</th>
              <th>Plan</th>
            </tr>
            <tr>
              <td data-label="Account">
                <b>Account A</b>
              </td>
              <td data-label="Segment">Skincare</td>
              <td data-label="Owner">Sales rep</td>
              <td data-label="Stage">
                <span className={c('tag g')}>Active</span>
              </td>
              <td data-label="Plan">
                <Icon n="ext" s={17} sw={1.6} />
              </td>
            </tr>
            <tr>
              <td data-label="Account">
                <b>Account B</b>
              </td>
              <td data-label="Segment">Haircare</td>
              <td data-label="Owner">Sales rep</td>
              <td data-label="Stage">
                <span className={c('tag b')}>Sampling</span>
              </td>
              <td data-label="Plan">
                <Icon n="ext" s={17} sw={1.6} />
              </td>
            </tr>
            <tr>
              <td data-label="Account">
                <b>Account C</b>
              </td>
              <td data-label="Segment">Color cosmetics</td>
              <td data-label="Owner">Sales rep</td>
              <td data-label="Stage">
                <span className={c('tag o')}>Quoting</span>
              </td>
              <td data-label="Plan">
                <Icon n="ext" s={17} sw={1.6} />
              </td>
            </tr>
            <tr>
              <td data-label="Account">
                <b>Account D</b>
              </td>
              <td data-label="Segment">OTC</td>
              <td data-label="Owner">Sales rep</td>
              <td data-label="Stage">
                <span className={c('tag g')}>Active</span>
              </td>
              <td data-label="Plan">
                <Icon n="ext" s={17} sw={1.6} />
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="trend" s={22} sw={1.7} />
            QBR Decks
          </h3>
          <a className={c('vl')}>View all</a>
        </div>
        <div className={c('lr')}>
          <div className={c('db')}>
            <i>DEC</i>
            <b>15</b>
          </div>
          <div className={c('g')}>
            <b>Q4 2026 QBR: Account A</b>
            <span className={c('s')}>Hayward, CA</span>
          </div>
          <div className={c('ri')}>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('db')}>
            <i>SEP</i>
            <b>22</b>
          </div>
          <div className={c('g')}>
            <b>Q3 2026 QBR: Account B</b>
            <span className={c('s')}>Video call</span>
          </div>
          <div className={c('ri')}>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('db')}>
            <i>JUN</i>
            <b>18</b>
          </div>
          <div className={c('g')}>
            <b>Q2 2026 QBR: Account C</b>
            <span className={c('s')}>Scottsdale, AZ</span>
          </div>
          <div className={c('ri')}>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
      </div>
    </div>
    <div className={c('row')} style={{ '--c': '1fr', marginTop: '22px' } as React.CSSProperties}>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div style={{ textAlign: 'center', padding: '26px 10px' } as React.CSSProperties}>
          <div style={{ width: '76px', height: '76px', borderRadius: '50%', background: '#e4f3f6', color: 'var(--top)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 14px' } as React.CSSProperties}>
            <Icon n="link" s={36} sw={1.5} />
          </div>
          <div style={{ fontSize: '21px', fontWeight: '700', color: 'var(--deep)' } as React.CSSProperties}>Customer Accounts (CRM)</div>
          <div style={{ fontSize: '14px', color: 'var(--mut)', margin: '8px 0 6px' } as React.CSSProperties}>Pipeline, contacts and activity for every account.</div>
          <a className={c('btn')}>
            Open CRM
            {' '}
            <Icon n="ext" s={17} sw={1.8} />
          </a>
        </div>
      </div>
    </div>
  </>
);

export default AccountsPage;
