import * as React from 'react';

import { Icon, c } from '../ui';
import { img } from '../images';

/** Regulatory page. Layout and styling come from SalesHome.module.scss. */
const RegulatoryPage: React.FC = () => (
  <>
    <div className={c('hero sm')}>
      <img className={c('art')} src={img.hero} alt="" />
      <div className={c('copy')}>
        <div className={c('cr')}>Home &nbsp;/&nbsp; Regulatory</div>
        <h1>Regulatory</h1>
        <p>Clean standards, restricted substances, OTC/FDA and MoCRA guidance, and customer questionnaire templates.</p>
        <a className={c('btn')}>
          View clean standards
          {' '}
          <Icon n="arrowr" s={17} sw={2} />
        </a>
      </div>
      <div className={c('panel')}>
        <div className={c('fac')}>
          <div className={c('ib')}>
            <Icon n="shieldc" s={28} sw={1.5} />
          </div>
          <div>
            <b>Clean Standards</b>
            <span>Credo &amp; Sephora</span>
          </div>
          <div className={c('ch')}>
            <Icon n="chev" s={24} sw={2} />
          </div>
        </div>
        <div className={c('fac')}>
          <div className={c('ib')}>
            <Icon n="file" s={28} sw={1.5} />
          </div>
          <div>
            <b>MoCRA &amp; FDA</b>
            <span>Guidance &amp; updates</span>
          </div>
          <div className={c('ch')}>
            <Icon n="chev" s={24} sw={2} />
          </div>
        </div>
      </div>
    </div>
    <div className={c('tiles')} style={{ '--c': 'repeat(4,1fr)' } as React.CSSProperties}>
      <a className={c('tile sq')} style={{ background: '#e4f3f6', color: '#0a3f52' } as React.CSSProperties}>
        <Icon n="shieldc" s={44} sw={1.5} />
        <b>Clean Standards</b>
        <span>Credo, Sephora &amp; retailer lists</span>
      </a>
      <a className={c('tile sq')} style={{ background: '#fff0e8', color: '#b8431c' } as React.CSSProperties}>
        <Icon n="shield" s={44} sw={1.5} />
        <b>Restricted Substances</b>
        <span>RSL by market &amp; retailer</span>
      </a>
      <a className={c('tile sq')} style={{ background: '#e4f1f8', color: '#0a5f70' } as React.CSSProperties}>
        <Icon n="file" s={44} sw={1.5} />
        <b>OTC / FDA &amp; MoCRA</b>
        <span>Guidance &amp; checklists</span>
      </a>
      <a className={c('tile sq')} style={{ background: '#e3f4ee', color: '#16785f' } as React.CSSProperties}>
        <Icon n="clip" s={44} sw={1.5} />
        <b>Questionnaire Templates</b>
        <span>Customer compliance forms</span>
      </a>
    </div>
    <div className={c('row r2')} style={{ '--c': '1fr 1fr', marginTop: '22px' } as React.CSSProperties}>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="shieldc" s={22} sw={1.7} />
            Clean Standards
          </h3>
          <a className={c('vl')}>View all</a>
        </div>
        <table>
          <tbody>
            <tr className={c('hd')}>
              <th>Standard</th>
              <th>Scope</th>
              <th>Last reviewed</th>
              <th />
            </tr>
            <tr>
              <td data-label="Standard">
                <b>Credo Clean Standard</b>
              </td>
              <td data-label="Scope">Skincare, haircare, color</td>
              <td data-label="Last reviewed">Oct 2026</td>
              <td data-label="">
                <Icon n="ext" s={17} sw={1.6} />
              </td>
            </tr>
            <tr>
              <td data-label="Standard">
                <b>Clean at Sephora</b>
              </td>
              <td data-label="Scope">All categories</td>
              <td data-label="Last reviewed">Oct 2026</td>
              <td data-label="">
                <Icon n="ext" s={17} sw={1.6} />
              </td>
            </tr>
            <tr>
              <td data-label="Standard">
                <b>Retailer-specific lists</b>
              </td>
              <td data-label="Scope">Per customer</td>
              <td data-label="Last reviewed">Sep 2026</td>
              <td data-label="">
                <Icon n="ext" s={17} sw={1.6} />
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="shield" s={22} sw={1.7} />
            Restricted Substances Lists
          </h3>
          <a className={c('vl')}>View all</a>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#e4f3f6', color: '#0a3f52' } as React.CSSProperties}>
            <Icon n="shield" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Master restricted substances list</b>
            <span className={c('s')}>Updated Oct 2026 &middot; PDF</span>
          </div>
          <div className={c('ri')}>
            <span className={c('tag g')}>Current</span>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#fff0e8', color: '#b8431c' } as React.CSSProperties}>
            <Icon n="shield" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>EU &amp; UK cosmetics annexes</b>
            <span className={c('s')}>Updated Sep 2026 &middot; PDF</span>
          </div>
          <div className={c('ri')}>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#e4f1f8', color: '#0a5f70' } as React.CSSProperties}>
            <Icon n="shield" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>California &amp; state-level lists</b>
            <span className={c('s')}>Updated Sep 2026 &middot; PDF</span>
          </div>
          <div className={c('ri')}>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
      </div>
    </div>
    <div className={c('row r2')} style={{ '--c': '1fr 1fr', marginTop: '22px' } as React.CSSProperties}>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="file" s={22} sw={1.7} />
            OTC / FDA &amp; MoCRA Guidance
          </h3>
          <a className={c('vl')}>View all</a>
        </div>
        <div className={c('lr')}>
          <div className={c('db')}>
            <i>NOV</i>
            <b>10</b>
          </div>
          <div className={c('g')}>
            <b>MoCRA facility registration renewal checklist</b>
            <span className={c('s')}>Guidance note</span>
          </div>
          <div className={c('ri')}>
            <Icon n="chev" s={18} sw={2} />
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('db')}>
            <i>OCT</i>
            <b>28</b>
          </div>
          <div className={c('g')}>
            <b>MoCRA compliance update</b>
            <span className={c('s')}>Regulatory update</span>
          </div>
          <div className={c('ri')}>
            <Icon n="chev" s={18} sw={2} />
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('db')}>
            <i>OCT</i>
            <b>12</b>
          </div>
          <div className={c('g')}>
            <b>OTC monograph labeling quick guide</b>
            <span className={c('s')}>Guidance note</span>
          </div>
          <div className={c('ri')}>
            <Icon n="chev" s={18} sw={2} />
          </div>
        </div>
      </div>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="clip" s={22} sw={1.7} />
            Customer Questionnaire Templates
          </h3>
          <a className={c('vl')}>View all</a>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#e4f3f6', color: '#0a3f52' } as React.CSSProperties}>
            <Icon n="clip" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Standard supplier questionnaire</b>
            <span className={c('s')}>Word &middot; ready to complete</span>
          </div>
          <div className={c('ri')}>
            <span className={c('tag')}>Template</span>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#fff0e8', color: '#b8431c' } as React.CSSProperties}>
            <Icon n="clip" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Retailer compliance questionnaire</b>
            <span className={c('s')}>Word &middot; ready to complete</span>
          </div>
          <div className={c('ri')}>
            <span className={c('tag o')}>Template</span>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#e4f1f8', color: '#0a5f70' } as React.CSSProperties}>
            <Icon n="clip" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Ingredient disclosure form</b>
            <span className={c('s')}>Excel &middot; ready to complete</span>
          </div>
          <div className={c('ri')}>
            <span className={c('tag b')}>Template</span>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
      </div>
    </div>
  </>
);

export default RegulatoryPage;
