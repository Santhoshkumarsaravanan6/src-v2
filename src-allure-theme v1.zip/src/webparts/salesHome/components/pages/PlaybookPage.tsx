import * as React from 'react';

import { Icon, c } from '../ui';
import { img } from '../images';

/** Sales Playbook page. Layout and styling come from SalesHome.module.scss. */
const PlaybookPage: React.FC = () => (
  <>
    <div className={c('hero sm')}>
      <img className={c('art')} src={img.hero} alt="" />
      <div className={c('copy')}>
        <div className={c('cr')}>Home &nbsp;/&nbsp; Sales Playbook</div>
        <h1>Sales Playbook</h1>
        <p>The sales process, qualification, battle cards, templates and onboarding for every new rep.</p>
        <a className={c('btn')}>
          Start onboarding
          {' '}
          <Icon n="arrowr" s={17} sw={2} />
        </a>
      </div>
      <div className={c('panel')}>
        <div className={c('fac')}>
          <div className={c('ib')}>
            <Icon n="target" s={28} sw={1.5} />
          </div>
          <div>
            <b>Sales Process</b>
            <span>Qualify to launch</span>
          </div>
          <div className={c('ch')}>
            <Icon n="chev" s={24} sw={2} />
          </div>
        </div>
        <div className={c('fac')}>
          <div className={c('ib')}>
            <Icon n="swords" s={28} sw={1.5} />
          </div>
          <div>
            <b>Battle Cards</b>
            <span>Objection handling</span>
          </div>
          <div className={c('ch')}>
            <Icon n="chev" s={24} sw={2} />
          </div>
        </div>
      </div>
    </div>
    <div className={c('tiles')} style={{ '--c': 'repeat(4,1fr)' } as React.CSSProperties}>
      <a className={c('tile sq')} style={{ background: '#e4f3f6', color: '#0a3f52' } as React.CSSProperties}>
        <Icon n="target" s={44} sw={1.5} />
        <b>Sales Process &amp; Qualification</b>
        <span>Stages &amp; criteria</span>
      </a>
      <a className={c('tile sq')} style={{ background: '#fff0e8', color: '#b8431c' } as React.CSSProperties}>
        <Icon n="swords" s={44} sw={1.5} />
        <b>Battle Cards</b>
        <span>Objection handling</span>
      </a>
      <a className={c('tile sq')} style={{ background: '#e4f1f8', color: '#0a5f70' } as React.CSSProperties}>
        <Icon n="mail" s={44} sw={1.5} />
        <b>Email &amp; Proposal Templates</b>
        <span>Ready-to-send</span>
      </a>
      <a className={c('tile sq')} style={{ background: '#e3f4ee', color: '#16785f' } as React.CSSProperties}>
        <Icon n="grad" s={44} sw={1.5} />
        <b>New Rep Onboarding</b>
        <span>Training path</span>
      </a>
    </div>
    <div className={c('row')} style={{ '--c': '1fr', marginTop: '22px' } as React.CSSProperties}>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="target" s={22} sw={1.7} />
            Sales Process &amp; Qualification
          </h3>
        </div>
        <div className={c('steps')} style={{ '--c': 'repeat(5,1fr)' } as React.CSSProperties}>
          <div className={c('step')}>
            <i>1</i>
            <b>Prospect</b>
            <span>Identify brands that fit our categories</span>
          </div>
          <div className={c('step')}>
            <i>2</i>
            <b>Qualify</b>
            <span>Budget, volume, timeline and fit</span>
          </div>
          <div className={c('step')}>
            <i>3</i>
            <b>Develop</b>
            <span>Samples, formula and pricing</span>
          </div>
          <div className={c('step')}>
            <i>4</i>
            <b>Quote</b>
            <span>Costing and approval</span>
          </div>
          <div className={c('step')}>
            <i>5</i>
            <b>Launch</b>
            <span>PO, production and hand-off</span>
          </div>
        </div>
      </div>
    </div>
    <div className={c('row r2')} style={{ '--c': '1.35fr 1fr', marginTop: '22px' } as React.CSSProperties}>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="swords" s={22} sw={1.7} />
            Battle Cards &amp; Objection Handling
          </h3>
          <a className={c('vl')}>View all</a>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#fff0e8', color: '#b8431c' } as React.CSSProperties}>
            <Icon n="swords" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>We are concerned about minimum order quantities</b>
            <span className={c('s')}>Lead with pilot runs and scalable batches</span>
          </div>
          <div className={c('ri')}>
            <Icon n="chev" s={18} sw={2} />
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#e3f4ee', color: '#16785f' } as React.CSSProperties}>
            <Icon n="swords" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Can you meet clean-beauty standards?</b>
            <span className={c('s')}>Credo and Sephora compliance, documented</span>
          </div>
          <div className={c('ri')}>
            <Icon n="chev" s={18} sw={2} />
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#e4f1f8', color: '#0a5f70' } as React.CSSProperties}>
            <Icon n="swords" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>How fast can you get samples to us?</b>
            <span className={c('s')}>Sampling timelines by category</span>
          </div>
          <div className={c('ri')}>
            <Icon n="chev" s={18} sw={2} />
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#fff0ea', color: '#0a3f52' } as React.CSSProperties}>
            <Icon n="swords" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Why not a larger manufacturer?</b>
            <span className={c('s')}>Attention, speed and flexibility</span>
          </div>
          <div className={c('ri')}>
            <Icon n="chev" s={18} sw={2} />
          </div>
        </div>
      </div>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="mail" s={22} sw={1.7} />
            Email &amp; Proposal Templates
          </h3>
          <a className={c('vl')}>View all</a>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#e4f3f6', color: '#0a3f52' } as React.CSSProperties}>
            <Icon n="mail" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Introduction email</b>
            <span className={c('s')}>Word &middot; ready to send</span>
          </div>
          <div className={c('ri')}>
            <span className={c('tag')}>Template</span>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#fff0e8', color: '#b8431c' } as React.CSSProperties}>
            <Icon n="mail" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Follow-up after sample</b>
            <span className={c('s')}>Word &middot; ready to send</span>
          </div>
          <div className={c('ri')}>
            <span className={c('tag o')}>Template</span>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#e4f1f8', color: '#0a5f70' } as React.CSSProperties}>
            <Icon n="file" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Proposal template</b>
            <span className={c('s')}>PowerPoint &middot; 12 slides</span>
          </div>
          <div className={c('ri')}>
            <span className={c('tag b')}>Template</span>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
      </div>
    </div>
    <div className={c('row')} style={{ '--c': '1fr', marginTop: '22px' } as React.CSSProperties}>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="grad" s={22} sw={1.7} />
            New Rep Onboarding
          </h3>
          <a className={c('vl')}>View path</a>
        </div>
        <div style={{ marginBottom: '14px' } as React.CSSProperties}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '14px' } as React.CSSProperties}>
            <b style={{ fontWeight: '600' } as React.CSSProperties}>Week 1: Company &amp; products</b>
            <span style={{ color: 'var(--mut)' } as React.CSSProperties}>5 of 5</span>
          </div>
          <div className={c('bar')}>
            <i style={{ width: '100%' } as React.CSSProperties} />
          </div>
        </div>
        <div style={{ marginBottom: '14px' } as React.CSSProperties}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '14px' } as React.CSSProperties}>
            <b style={{ fontWeight: '600' } as React.CSSProperties}>Week 2: Capabilities &amp; facilities</b>
            <span style={{ color: 'var(--mut)' } as React.CSSProperties}>3 of 5</span>
          </div>
          <div className={c('bar')}>
            <i style={{ width: '60%' } as React.CSSProperties} />
          </div>
        </div>
        <div style={{ marginBottom: '14px' } as React.CSSProperties}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '14px' } as React.CSSProperties}>
            <b style={{ fontWeight: '600' } as React.CSSProperties}>Week 3: Pricing &amp; quoting</b>
            <span style={{ color: 'var(--mut)' } as React.CSSProperties}>1 of 4</span>
          </div>
          <div className={c('bar')}>
            <i style={{ width: '25%' } as React.CSSProperties} />
          </div>
        </div>
        <div style={{ marginBottom: '14px' } as React.CSSProperties}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '14px' } as React.CSSProperties}>
            <b style={{ fontWeight: '600' } as React.CSSProperties}>Week 4: Shadow &amp; first account</b>
            <span style={{ color: 'var(--mut)' } as React.CSSProperties}>0 of 3</span>
          </div>
          <div className={c('bar')}>
            <i style={{ width: '0%' } as React.CSSProperties} />
          </div>
        </div>
      </div>
    </div>
  </>
);

export default PlaybookPage;
