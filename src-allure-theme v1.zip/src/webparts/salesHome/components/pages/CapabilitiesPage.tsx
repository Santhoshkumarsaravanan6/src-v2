import * as React from 'react';

import { Icon, c } from '../ui';
import { img } from '../images';

/** Capabilities page. Layout and styling come from SalesHome.module.scss. */
const CapabilitiesPage: React.FC = () => (
  <>
    <div className={c('hero sm')}>
      <img className={c('art')} src={img.hero} alt="" />
      <div className={c('copy')}>
        <div className={c('cr')}>Home &nbsp;/&nbsp; Capabilities</div>
        <h1>Capabilities</h1>
        <p>Facility profiles, category capabilities, certifications and the case studies that prove them.</p>
        <a className={c('btn')}>
          Download capabilities deck
          {' '}
          <Icon n="arrowr" s={17} sw={2} />
        </a>
      </div>
      <div className={c('panel')}>
        <div className={c('fac')}>
          <div className={c('ib')}>
            <Icon n="factory" s={28} sw={1.5} />
          </div>
          <div>
            <b>Hayward, CA</b>
            <span>Manufacturing Facility</span>
          </div>
          <div className={c('ch')}>
            <Icon n="chev" s={24} sw={2} />
          </div>
        </div>
        <div className={c('fac')}>
          <div className={c('ib')}>
            <Icon n="factory" s={28} sw={1.5} />
          </div>
          <div>
            <b>Scottsdale, AZ</b>
            <span>Manufacturing Facility</span>
          </div>
          <div className={c('ch')}>
            <Icon n="chev" s={24} sw={2} />
          </div>
        </div>
      </div>
    </div>
    <div className={c('tiles')} style={{ '--c': 'repeat(4,1fr)' } as React.CSSProperties}>
      <a className={c('tile sq')} style={{ background: '#e4f3f6', color: '#0a3f52' } as React.CSSProperties}>
        <Icon n="drop" s={44} sw={1.5} />
        <b>Skincare</b>
        <span>Creams, serums, lotions &amp; cleansers</span>
      </a>
      <a className={c('tile sq')} style={{ background: '#fff0e8', color: '#b8431c' } as React.CSSProperties}>
        <Icon n="wind" s={44} sw={1.5} />
        <b>Haircare</b>
        <span>Shampoo, conditioner &amp; treatments</span>
      </a>
      <a className={c('tile sq')} style={{ background: '#e4f1f8', color: '#0a5f70' } as React.CSSProperties}>
        <Icon n="palette" s={44} sw={1.5} />
        <b>Color Cosmetics</b>
        <span>Face, lip &amp; eye products</span>
      </a>
      <a className={c('tile sq')} style={{ background: '#e3f4ee', color: '#16785f' } as React.CSSProperties}>
        <Icon n="shieldc" s={44} sw={1.5} />
        <b>OTC</b>
        <span>SPF, acne &amp; drug-regulated products</span>
      </a>
    </div>
    <div className={c('row r2')} style={{ '--c': '1fr 1fr', marginTop: '22px' } as React.CSSProperties}>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="factory" s={22} sw={1.7} />
            Hayward, CA Facility
          </h3>
        </div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '20px', alignItems: 'center' } as React.CSSProperties}>
          <img src={img.fac1} style={{ width: '230px', height: '144px', objectFit: 'cover', borderRadius: '8px', flex: 'none' } as React.CSSProperties} alt="" />
          <ul>
            <li style={{ fontSize: '14.5px', lineHeight: '1.6', marginLeft: '18px' } as React.CSSProperties}>Contract manufacturing</li>
            <li style={{ fontSize: '14.5px', lineHeight: '1.6', marginLeft: '18px' } as React.CSSProperties}>Filling &amp; assembly</li>
            <li style={{ fontSize: '14.5px', lineHeight: '1.6', marginLeft: '18px' } as React.CSSProperties}>Mass &amp; pilot production</li>
          </ul>
        </div>
        <div style={{ display: 'flex', gap: '10px', margin: '16px 0' } as React.CSSProperties}>
          <div style={{ flex: '1', padding: '12px 10px', borderRadius: '8px', background: '#e4f3f6', textAlign: 'center' } as React.CSSProperties}>
            <b style={{ display: 'block', fontSize: '19px', color: 'var(--deep)' } as React.CSSProperties}>&mdash;</b>
            <span style={{ fontSize: '12px', color: 'var(--mut)' } as React.CSSProperties}>Facility size (sq ft)</span>
          </div>
          <div style={{ flex: '1', padding: '12px 10px', borderRadius: '8px', background: '#e4f3f6', textAlign: 'center' } as React.CSSProperties}>
            <b style={{ display: 'block', fontSize: '19px', color: 'var(--deep)' } as React.CSSProperties}>&mdash;</b>
            <span style={{ fontSize: '12px', color: 'var(--mut)' } as React.CSSProperties}>Filling lines</span>
          </div>
          <div style={{ flex: '1', padding: '12px 10px', borderRadius: '8px', background: '#e4f3f6', textAlign: 'center' } as React.CSSProperties}>
            <b style={{ display: 'block', fontSize: '19px', color: 'var(--deep)' } as React.CSSProperties}>&mdash;</b>
            <span style={{ fontSize: '12px', color: 'var(--mut)' } as React.CSSProperties}>Typical lead time</span>
          </div>
        </div>
        <a className={c('btn')} style={{ marginTop: '2px' } as React.CSSProperties}>
          Download facility profile
          {' '}
          <Icon n="dl" s={17} sw={2} />
        </a>
      </div>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="factory" s={22} sw={1.7} />
            Scottsdale, AZ Facility
          </h3>
        </div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '20px', alignItems: 'center' } as React.CSSProperties}>
          <img src={img.fac2} style={{ width: '230px', height: '144px', objectFit: 'cover', borderRadius: '8px', flex: 'none' } as React.CSSProperties} alt="" />
          <ul>
            <li style={{ fontSize: '14.5px', lineHeight: '1.6', marginLeft: '18px' } as React.CSSProperties}>Specialized formulations</li>
            <li style={{ fontSize: '14.5px', lineHeight: '1.6', marginLeft: '18px' } as React.CSSProperties}>Innovation &amp; development</li>
            <li style={{ fontSize: '14.5px', lineHeight: '1.6', marginLeft: '18px' } as React.CSSProperties}>Scalable manufacturing</li>
          </ul>
        </div>
        <div style={{ display: 'flex', gap: '10px', margin: '16px 0' } as React.CSSProperties}>
          <div style={{ flex: '1', padding: '12px 10px', borderRadius: '8px', background: '#e4f3f6', textAlign: 'center' } as React.CSSProperties}>
            <b style={{ display: 'block', fontSize: '19px', color: 'var(--deep)' } as React.CSSProperties}>&mdash;</b>
            <span style={{ fontSize: '12px', color: 'var(--mut)' } as React.CSSProperties}>Facility size (sq ft)</span>
          </div>
          <div style={{ flex: '1', padding: '12px 10px', borderRadius: '8px', background: '#e4f3f6', textAlign: 'center' } as React.CSSProperties}>
            <b style={{ display: 'block', fontSize: '19px', color: 'var(--deep)' } as React.CSSProperties}>&mdash;</b>
            <span style={{ fontSize: '12px', color: 'var(--mut)' } as React.CSSProperties}>R&amp;D labs</span>
          </div>
          <div style={{ flex: '1', padding: '12px 10px', borderRadius: '8px', background: '#e4f3f6', textAlign: 'center' } as React.CSSProperties}>
            <b style={{ display: 'block', fontSize: '19px', color: 'var(--deep)' } as React.CSSProperties}>&mdash;</b>
            <span style={{ fontSize: '12px', color: 'var(--mut)' } as React.CSSProperties}>Typical lead time</span>
          </div>
        </div>
        <a className={c('btn')} style={{ marginTop: '2px' } as React.CSSProperties}>
          Download facility profile
          {' '}
          <Icon n="dl" s={17} sw={2} />
        </a>
      </div>
    </div>
    <div className={c('row r2')} style={{ '--c': '1.35fr 1fr', marginTop: '22px' } as React.CSSProperties}>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="shieldc" s={22} sw={1.7} />
            Certifications &amp; Audits
          </h3>
          <a className={c('vl')}>View all</a>
        </div>
        <table>
          <tbody>
            <tr className={c('hd')}>
              <th>Certification / audit</th>
              <th>Facility</th>
              <th>Status</th>
              <th>Updated</th>
            </tr>
            <tr>
              <td data-label="Certification / audit">
                <b>cGMP</b>
              </td>
              <td data-label="Facility">Hayward &amp; Scottsdale</td>
              <td data-label="Status">
                <span className={c('tag g')}>Current</span>
              </td>
              <td data-label="Updated">Oct 2026</td>
            </tr>
            <tr>
              <td data-label="Certification / audit">
                <b>ISO 22716</b>
              </td>
              <td data-label="Facility">Hayward</td>
              <td data-label="Status">
                <span className={c('tag g')}>Current</span>
              </td>
              <td data-label="Updated">Sep 2026</td>
            </tr>
            <tr>
              <td data-label="Certification / audit">
                <b>FDA registration</b>
              </td>
              <td data-label="Facility">Hayward &amp; Scottsdale</td>
              <td data-label="Status">
                <span className={c('tag g')}>Current</span>
              </td>
              <td data-label="Updated">Aug 2026</td>
            </tr>
            <tr>
              <td data-label="Certification / audit">
                <b>Customer audits</b>
              </td>
              <td data-label="Facility">Both</td>
              <td data-label="Status">
                <span className={c('tag')}>Reports available</span>
              </td>
              <td data-label="Updated">Nov 2026</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="book" s={22} sw={1.7} />
            Case Studies
          </h3>
          <a className={c('vl')}>View all</a>
        </div>
        <div className={c('lr')}>
          <img className={c('th')} src={img.n1} alt="" />
          <div className={c('g')}>
            <b>Private-label skincare launch</b>
            <span className={c('s')}>From concept to shelf in 14 weeks</span>
          </div>
        </div>
        <div className={c('lr')}>
          <img className={c('th')} src={img.n2} alt="" />
          <div className={c('g')}>
            <b>Sulfate-free haircare range</b>
            <span className={c('s')}>Scottsdale pilot to full production</span>
          </div>
        </div>
        <div className={c('lr')}>
          <img className={c('th')} src={img.n3} alt="" />
          <div className={c('g')}>
            <b>SPF OTC reformulation</b>
            <span className={c('s')}>Meeting FDA monograph requirements</span>
          </div>
        </div>
      </div>
    </div>
  </>
);

export default CapabilitiesPage;
