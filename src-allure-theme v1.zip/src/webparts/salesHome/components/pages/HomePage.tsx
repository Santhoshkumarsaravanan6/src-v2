import * as React from 'react';

import { Icon, c } from '../ui';
import { img } from '../images';
import type { IPageProps } from '../nav';

/** Home page. Layout and styling come from SalesHome.module.scss. */
const HomePage: React.FC<IPageProps> = ({ firstName }) => (
  <>
    <div className={c('hero')}>
      <img className={c('art')} src={img.hero} alt="" />
      <div className={c('copy')}>
        <div className={c('eb')}>Sales team portal</div>
        <div className={c('w')}>Welcome{firstName && <>, <span className={c('hl')}>{firstName}</span></>}</div>
        <h1>Allure Sales Hub</h1>
        <p>Your one-stop destination for capabilities, innovation, regulatory, marketing assets and sales resources.</p>
        <a className={c('btn')} data-go="capabilities" href="#">
          Explore Capabilities
          {' '}
          <Icon n="arrowr" s={17} sw={2} />
        </a>
      </div>
      <div className={c('panel')}>
        <div className={c('fac')}>
          <div className={c('ib')}>
            <Icon n="factory" s={28} sw={1.5} />
          </div>
          <div>
            <b>Hayward, CA</b>
            <span>Manufacturing Facility</span>
          </div>
          <div className={c('ch')}>
            <Icon n="chev" s={24} sw={2} />
          </div>
        </div>
        <div className={c('fac')}>
          <div className={c('ib')}>
            <Icon n="factory" s={28} sw={1.5} />
          </div>
          <div>
            <b>Scottsdale, AZ</b>
            <span>Manufacturing Facility</span>
          </div>
          <div className={c('ch')}>
            <Icon n="chev" s={24} sw={2} />
          </div>
        </div>
      </div>
    </div>
    <div className={c('tiles t6')} style={{ '--c': '269fr 256fr 240fr 257fr 248fr 242fr' } as React.CSSProperties}>
      <a className={c('tile')} style={{ background: '#e4f3f6', color: '#0a3f52' } as React.CSSProperties} data-go="capabilities" href="#">
        <Icon n="gear" s={44} sw={1.5} />
        <b>Capabilities</b>
        <span>Facilities, Processes &amp; Certifications</span>
      </a>
      <a className={c('tile')} style={{ background: '#fff0e8', color: '#b8431c' } as React.CSSProperties} data-go="innovation" href="#">
        <Icon n="flask" s={44} sw={1.5} />
        <b>Innovation</b>
        <span>New Formulas, Trends &amp; Ingredient Library</span>
      </a>
      <a className={c('tile')} style={{ background: '#e4f1f8', color: '#0a5f70' } as React.CSSProperties} data-go="pricing" href="#">
        <Icon n="coins" s={44} sw={1.5} />
        <b>Pricing</b>
        <span>Rate Cards, Quotations &amp; Costing Guidelines</span>
      </a>
      <a className={c('tile')} style={{ background: '#e3f4ee', color: '#16785f' } as React.CSSProperties} data-go="regulatory" href="#">
        <Icon n="shieldc" s={44} sw={1.5} />
        <b>Regulatory</b>
        <span>Compliance, FDA, MoCRA &amp; Restricted Substances</span>
      </a>
      <a className={c('tile')} style={{ background: '#fff0ea', color: '#0a3f52' } as React.CSSProperties} data-go="marketing-assets" href="#">
        <Icon n="image" s={44} sw={1.5} />
        <b>Marketing Assets</b>
        <span>Presentations, Photos, Videos &amp; Brand Assets</span>
      </a>
      <a className={c('tile')} style={{ background: '#e8eff4', color: '#0e7c8c' } as React.CSSProperties} data-go="events" href="#">
        <Icon n="cal" s={44} sw={1.5} />
        <b>Events</b>
        <span>Trade Shows, Calendar &amp; Event Resources</span>
      </a>
    </div>
    <div className={c('row r4')} style={{ '--c': '400fr 411fr 393fr 322fr', marginTop: '24px' } as React.CSSProperties}>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>Company Capabilities</h3>
          <a className={c('vl')}>
            <Icon n="arrowur" s={18} sw={1.8} />
          </a>
        </div>
        <div className={c('fcard')}>
          <img src={img.fac1} alt="" />
          <div>
            <h4>Hayward, CA Facility</h4>
            <ul>
              <li>Contract Manufacturing</li>
              <li>Filling &amp; Assembly</li>
              <li>Mass &amp; Pilot Production</li>
            </ul>
          </div>
        </div>
        <div className={c('hr')} style={{ margin: '13px 0' } as React.CSSProperties} />
        <div className={c('fcard')}>
          <img src={img.fac2} alt="" />
          <div>
            <h4>Scottsdale, AZ Facility</h4>
            <ul>
              <li>Specialized Formulations</li>
              <li>Innovation &amp; Development</li>
              <li>Scalable Manufacturing</li>
            </ul>
          </div>
        </div>
      </div>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="megaphone" s={22} sw={1.7} />
            Latest Updates
          </h3>
          <a className={c('vl')}>View All</a>
        </div>
        <div className={c('lr')}>
          <img className={c('th')} src={img.n1} alt="" />
          <div className={c('g')}>
            <b>New Skincare Line Now Available</b>
            <span className={c('s')}>Nov 10, 2026</span>
          </div>
        </div>
        <div className={c('lr')}>
          <img className={c('th')} src={img.n2} alt="" />
          <div className={c('g')}>
            <b>Successful Launch at Cosmoprof 2026</b>
            <span className={c('s')}>Nov 5, 2026</span>
          </div>
        </div>
        <div className={c('lr')}>
          <img className={c('th')} src={img.n3} alt="" />
          <div className={c('g')}>
            <b>MoCRA Compliance Update</b>
            <span className={c('s')}>Oct 28, 2026</span>
          </div>
        </div>
      </div>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="cal" s={22} sw={1.7} />
            Upcoming Events
          </h3>
          <a className={c('vl')}>View Calendar</a>
        </div>
        <div className={c('lr')}>
          <div className={c('db')}>
            <i>DEC</i>
            <b>03</b>
          </div>
          <div className={c('g')}>
            <b>Cosmoprof North America</b>
            <span className={c('s')}>Las Vegas, NV</span>
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('db')}>
            <i>JAN</i>
            <b>20</b>
          </div>
          <div className={c('g')}>
            <b>Beauty Innovation Summit</b>
            <span className={c('s')}>New York, NY</span>
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('db')}>
            <i>MAR</i>
            <b>10</b>
          </div>
          <div className={c('g')}>
            <b>Indie Beauty Expo</b>
            <span className={c('s')}>Los Angeles, CA</span>
          </div>
        </div>
      </div>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="link" s={22} sw={1.7} />
            Quick Links
          </h3>
        </div>
        <div className={c('ql')}>
          <Icon n="cal" s={20} sw={1.6} />
          <span>Sales Playbook</span>
          <Icon n="ext" s={17} sw={1.6} />
        </div>
        <div className={c('ql')}>
          <Icon n="file" s={20} sw={1.6} />
          <span>Customer Accounts (CRM)</span>
          <Icon n="ext" s={17} sw={1.6} />
        </div>
        <div className={c('ql')}>
          <Icon n="cal" s={20} sw={1.6} />
          <span>Company Documents</span>
          <Icon n="ext" s={17} sw={1.6} />
        </div>
        <div className={c('ql')}>
          <Icon n="cal" s={20} sw={1.6} />
          <span>R&amp;D Resources</span>
          <Icon n="ext" s={17} sw={1.6} />
        </div>
        <div className={c('ql')}>
          <Icon n="cal" s={20} sw={1.6} />
          <span>Sales Templates</span>
          <Icon n="ext" s={17} sw={1.6} />
        </div>
      </div>
    </div>
    <div className={c('row r2')} style={{ '--c': '1fr 1.45fr', marginTop: '18px' } as React.CSSProperties}>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="trophy" s={22} sw={1.7} />
            Recent Wins
          </h3>
          <a className={c('vl')}>View All</a>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#e3f4ee', color: '#16785f' } as React.CSSProperties}>
            <Icon n="check" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Won 3-SKU skincare program</b>
            <span className={c('s')}>Private-label launch for a new retail partner</span>
          </div>
          <div className={c('ri')}>
            <span className={c('tag')}>Skincare</span>
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#e3f4ee', color: '#16785f' } as React.CSSProperties}>
            <Icon n="check" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Sulfate-free shampoo line</b>
            <span className={c('s')}>Scottsdale facility, first PO received</span>
          </div>
          <div className={c('ri')}>
            <span className={c('tag o')}>Haircare</span>
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#e3f4ee', color: '#16785f' } as React.CSSProperties}>
            <Icon n="check" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>SPF OTC reformulation</b>
            <span className={c('s')}>Approved by the customer</span>
          </div>
          <div className={c('ri')}>
            <span className={c('tag b')}>OTC</span>
          </div>
        </div>
      </div>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="cal" s={22} sw={1.7} />
            Events Calendar
          </h3>
          <a className={c('vl')}>Full Calendar</a>
        </div>
        <div className={c('two')}>
          <div>
            <div style={{ fontSize: '14px', fontWeight: '700', color: 'var(--deep)', marginBottom: '10px' } as React.CSSProperties}>December 2026</div>
            <div className={c('cal')}>
              <div className={c('w')}>S</div>
              <div className={c('w')}>M</div>
              <div className={c('w')}>T</div>
              <div className={c('w')}>W</div>
              <div className={c('w')}>T</div>
              <div className={c('w')}>F</div>
              <div className={c('w')}>S</div>
              <div />
              <div />
              <div>1</div>
              <div>2</div>
              <div className={c('e')}>3</div>
              <div>4</div>
              <div>5</div>
              <div>6</div>
              <div>7</div>
              <div>8</div>
              <div className={c('e')}>9</div>
              <div>10</div>
              <div>11</div>
              <div>12</div>
              <div>13</div>
              <div>14</div>
              <div className={c('e')}>15</div>
              <div>16</div>
              <div>17</div>
              <div>18</div>
              <div>19</div>
              <div>20</div>
              <div>21</div>
              <div>22</div>
              <div>23</div>
              <div>24</div>
              <div>25</div>
              <div>26</div>
              <div>27</div>
              <div>28</div>
              <div>29</div>
              <div>30</div>
              <div>31</div>
            </div>
          </div>
          <div>
            <div className={c('lr')}>
              <div className={c('db')}>
                <i>DEC</i>
                <b>03</b>
              </div>
              <div className={c('g')}>
                <b>Cosmoprof North America</b>
                <span className={c('s')}>Las Vegas, NV</span>
              </div>
            </div>
            <div className={c('lr')}>
              <div className={c('db')}>
                <i>DEC</i>
                <b>09</b>
              </div>
              <div className={c('g')}>
                <b>Customer visit: Scottsdale</b>
                <span className={c('s')}>Scottsdale, AZ</span>
              </div>
            </div>
            <div className={c('lr')}>
              <div className={c('db')}>
                <i>DEC</i>
                <b>15</b>
              </div>
              <div className={c('g')}>
                <b>Quarterly business review</b>
                <span className={c('s')}>Hayward, CA</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </>
);

export default HomePage;
