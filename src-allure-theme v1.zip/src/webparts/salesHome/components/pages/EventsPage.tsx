import * as React from 'react';

import { Icon, c } from '../ui';
import { img } from '../images';

/** Events page. Layout and styling come from SalesHome.module.scss. */
const EventsPage: React.FC = () => (
  <>
    <div className={c('hero sm')}>
      <img className={c('art')} src={img.hero} alt="" />
      <div className={c('copy')}>
        <div className={c('cr')}>Home &nbsp;/&nbsp; Events</div>
        <h1>Events</h1>
        <p>Trade show calendar, playbooks, lead capture and event recaps, all in one place.</p>
        <a className={c('btn')}>
          View full calendar
          {' '}
          <Icon n="arrowr" s={17} sw={2} />
        </a>
      </div>
      <div className={c('panel')}>
        <div className={c('fac')}>
          <div className={c('ib')}>
            <Icon n="cal" s={28} sw={1.5} />
          </div>
          <div>
            <b>Cosmoprof North America</b>
            <span>Las Vegas &middot; Dec 3</span>
          </div>
          <div className={c('ch')}>
            <Icon n="chev" s={24} sw={2} />
          </div>
        </div>
        <div className={c('fac')}>
          <div className={c('ib')}>
            <Icon n="cal" s={28} sw={1.5} />
          </div>
          <div>
            <b>Beauty Innovation Summit</b>
            <span>New York &middot; Jan 20</span>
          </div>
          <div className={c('ch')}>
            <Icon n="chev" s={24} sw={2} />
          </div>
        </div>
      </div>
    </div>
    <div className={c('tiles')} style={{ '--c': 'repeat(4,1fr)' } as React.CSSProperties}>
      <a className={c('tile sq')} style={{ background: '#e4f3f6', color: '#0a3f52' } as React.CSSProperties}>
        <Icon n="cal" s={44} sw={1.5} />
        <b>Trade Show Calendar</b>
        <span>Upcoming &amp; past shows</span>
      </a>
      <a className={c('tile sq')} style={{ background: '#fff0e8', color: '#b8431c' } as React.CSSProperties}>
        <Icon n="check" s={44} sw={1.5} />
        <b>Playbooks &amp; Checklists</b>
        <span>Before, during &amp; after</span>
      </a>
      <a className={c('tile sq')} style={{ background: '#e4f1f8', color: '#0a5f70' } as React.CSSProperties}>
        <Icon n="users" s={44} sw={1.5} />
        <b>Lead Capture &amp; Follow-Up</b>
        <span>Capture &amp; assign leads</span>
      </a>
      <a className={c('tile sq')} style={{ background: '#e3f4ee', color: '#16785f' } as React.CSSProperties}>
        <Icon n="book" s={44} sw={1.5} />
        <b>Event Recaps</b>
        <span>Results &amp; learnings</span>
      </a>
    </div>
    <div className={c('row r2')} style={{ '--c': '1fr 1.35fr', marginTop: '22px' } as React.CSSProperties}>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="cal" s={22} sw={1.7} />
            Trade Show Calendar
          </h3>
          <a className={c('vl')}>Full calendar</a>
        </div>
        <div style={{ fontSize: '14px', fontWeight: '700', color: 'var(--deep)', marginBottom: '10px' } as React.CSSProperties}>December 2026</div>
        <div className={c('cal')}>
          <div className={c('w')}>S</div>
          <div className={c('w')}>M</div>
          <div className={c('w')}>T</div>
          <div className={c('w')}>W</div>
          <div className={c('w')}>T</div>
          <div className={c('w')}>F</div>
          <div className={c('w')}>S</div>
          <div />
          <div />
          <div>1</div>
          <div>2</div>
          <div className={c('e')}>3</div>
          <div>4</div>
          <div>5</div>
          <div>6</div>
          <div>7</div>
          <div>8</div>
          <div className={c('e')}>9</div>
          <div>10</div>
          <div>11</div>
          <div>12</div>
          <div>13</div>
          <div>14</div>
          <div className={c('e')}>15</div>
          <div>16</div>
          <div>17</div>
          <div>18</div>
          <div>19</div>
          <div>20</div>
          <div>21</div>
          <div>22</div>
          <div>23</div>
          <div>24</div>
          <div>25</div>
          <div>26</div>
          <div>27</div>
          <div>28</div>
          <div>29</div>
          <div>30</div>
          <div>31</div>
        </div>
      </div>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="cal" s={22} sw={1.7} />
            Upcoming Events
          </h3>
          <a className={c('vl')}>View all</a>
        </div>
        <div className={c('lr')}>
          <div className={c('db')}>
            <i>DEC</i>
            <b>03</b>
          </div>
          <div className={c('g')}>
            <b>Cosmoprof North America</b>
            <span className={c('s')}>Las Vegas, NV &middot; Booth B214</span>
          </div>
          <div className={c('ri')}>
            <span className={c('tag')}>Trade show</span>
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('db')}>
            <i>JAN</i>
            <b>20</b>
          </div>
          <div className={c('g')}>
            <b>Beauty Innovation Summit</b>
            <span className={c('s')}>New York, NY</span>
          </div>
          <div className={c('ri')}>
            <span className={c('tag b')}>Conference</span>
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('db')}>
            <i>MAR</i>
            <b>10</b>
          </div>
          <div className={c('g')}>
            <b>Indie Beauty Expo</b>
            <span className={c('s')}>Los Angeles, CA</span>
          </div>
          <div className={c('ri')}>
            <span className={c('tag p')}>Trade show</span>
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('db')}>
            <i>APR</i>
            <b>14</b>
          </div>
          <div className={c('g')}>
            <b>Customer visit: Hayward</b>
            <span className={c('s')}>Hayward, CA</span>
          </div>
          <div className={c('ri')}>
            <span className={c('tag o')}>Visit</span>
          </div>
        </div>
      </div>
    </div>
    <div className={c('row r2')} style={{ '--c': '1fr 1.2fr', marginTop: '22px' } as React.CSSProperties}>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="check" s={22} sw={1.7} />
            Playbooks &amp; Checklists
          </h3>
          <a className={c('vl')}>View all</a>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#e4f3f6', color: '#0a3f52' } as React.CSSProperties}>
            <Icon n="check" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Trade show planning playbook</b>
            <span className={c('s')}>Word &middot; 8 pages</span>
          </div>
          <div className={c('ri')}>
            <span className={c('tag')}>Playbook</span>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#fff0e8', color: '#b8431c' } as React.CSSProperties}>
            <Icon n="check" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Booth day-of checklist</b>
            <span className={c('s')}>PDF &middot; 2 pages</span>
          </div>
          <div className={c('ri')}>
            <span className={c('tag g')}>Checklist</span>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#e4f1f8', color: '#0a5f70' } as React.CSSProperties}>
            <Icon n="check" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Post-show follow-up checklist</b>
            <span className={c('s')}>PDF &middot; 2 pages</span>
          </div>
          <div className={c('ri')}>
            <span className={c('tag g')}>Checklist</span>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
      </div>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="users" s={22} sw={1.7} />
            Lead Capture &amp; Follow-Up
          </h3>
        </div>
        <div className={c('steps')} style={{ '--c': 'repeat(3,1fr)' } as React.CSSProperties}>
          <div className={c('step')}>
            <i>1</i>
            <b>Capture</b>
            <span>Scan or enter the lead at the booth</span>
          </div>
          <div className={c('step')}>
            <i>2</i>
            <b>Assign</b>
            <span>Owner and next step set within 24 hours</span>
          </div>
          <div className={c('step')}>
            <i>3</i>
            <b>Follow up</b>
            <span>Samples, quote or meeting booked</span>
          </div>
        </div>
        <a className={c('btn')} style={{ marginTop: '16px' } as React.CSSProperties}>
          Open lead capture form
          {' '}
          <Icon n="arrowr" s={16} sw={2} />
        </a>
      </div>
    </div>
    <div className={c('row')} style={{ '--c': '1fr', marginTop: '22px' } as React.CSSProperties}>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="book" s={22} sw={1.7} />
            Event Recaps
          </h3>
          <a className={c('vl')}>View all</a>
        </div>
        <div className={c('lr')}>
          <img className={c('th')} src={img.n1} alt="" />
          <div className={c('g')}>
            <b>Cosmoprof 2026 recap</b>
            <span className={c('s')}>Nov 2026 &middot; 42 qualified leads</span>
          </div>
          <div className={c('ri')}>
            <Icon n="chev" s={18} sw={2} />
          </div>
        </div>
        <div className={c('lr')}>
          <img className={c('th')} src={img.n2} alt="" />
          <div className={c('g')}>
            <b>Indie Beauty Expo 2026 recap</b>
            <span className={c('s')}>Mar 2026 &middot; 27 qualified leads</span>
          </div>
          <div className={c('ri')}>
            <Icon n="chev" s={18} sw={2} />
          </div>
        </div>
        <div className={c('lr')}>
          <img className={c('th')} src={img.n3} alt="" />
          <div className={c('g')}>
            <b>Beauty Innovation Summit 2026</b>
            <span className={c('s')}>Jan 2026 &middot; Key learnings</span>
          </div>
          <div className={c('ri')}>
            <Icon n="chev" s={18} sw={2} />
          </div>
        </div>
      </div>
    </div>
  </>
);

export default EventsPage;
