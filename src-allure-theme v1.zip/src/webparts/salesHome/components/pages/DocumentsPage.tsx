import * as React from 'react';

import { Icon, c } from '../ui';
import { img } from '../images';

/** Company Documents page. Layout and styling come from SalesHome.module.scss. */
const DocumentsPage: React.FC = () => (
  <>
    <div className={c('hero sm')}>
      <img className={c('art')} src={img.hero} alt="" />
      <div className={c('copy')}>
        <div className={c('cr')}>Home &nbsp;/&nbsp; Company Documents</div>
        <h1>Company Documents</h1>
        <p>Org chart, key contacts, contract templates, vendor forms and company policies.</p>
        <a className={c('btn')}>
          Browse documents
          {' '}
          <Icon n="arrowr" s={17} sw={2} />
        </a>
      </div>
      <div className={c('panel')}>
        <div className={c('fac')}>
          <div className={c('ib')}>
            <Icon n="file" s={28} sw={1.5} />
          </div>
          <div>
            <b>Contracts</b>
            <span>NDA &amp; MSA templates</span>
          </div>
          <div className={c('ch')}>
            <Icon n="chev" s={24} sw={2} />
          </div>
        </div>
        <div className={c('fac')}>
          <div className={c('ib')}>
            <Icon n="clip" s={28} sw={1.5} />
          </div>
          <div>
            <b>Vendor Forms</b>
            <span>W-9 &amp; COI</span>
          </div>
          <div className={c('ch')}>
            <Icon n="chev" s={24} sw={2} />
          </div>
        </div>
      </div>
    </div>
    <div className={c('tiles')} style={{ '--c': 'repeat(4,1fr)' } as React.CSSProperties}>
      <a className={c('tile sq')} style={{ background: '#e4f3f6', color: '#0a3f52' } as React.CSSProperties}>
        <Icon n="org" s={44} sw={1.5} />
        <b>Org Chart &amp; Contacts</b>
        <span>Who to call</span>
      </a>
      <a className={c('tile sq')} style={{ background: '#fff0e8', color: '#b8431c' } as React.CSSProperties}>
        <Icon n="file" s={44} sw={1.5} />
        <b>NDA / MSA Templates</b>
        <span>Contract templates</span>
      </a>
      <a className={c('tile sq')} style={{ background: '#e4f1f8', color: '#0a5f70' } as React.CSSProperties}>
        <Icon n="clip" s={44} sw={1.5} />
        <b>W-9, COI &amp; Vendor Forms</b>
        <span>Onboarding forms</span>
      </a>
      <a className={c('tile sq')} style={{ background: '#e3f4ee', color: '#16785f' } as React.CSSProperties}>
        <Icon n="book" s={44} sw={1.5} />
        <b>Policies</b>
        <span>Company policies</span>
      </a>
    </div>
    <div className={c('row')} style={{ '--c': '1fr', marginTop: '22px' } as React.CSSProperties}>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="org" s={22} sw={1.7} />
            Org Chart
          </h3>
          <a className={c('vl')}>Full directory</a>
        </div>
        <div className={c('oc')}>
          <div className={c('nd lead')}>
            <b>Leadership</b>
            <span>Executive team</span>
          </div>
          <div className={c('ln')} />
          <div className={c('lv')}>
            <div className={c('nd')}>
              <b>Sales Director</b>
              <span>Sales &amp; accounts</span>
            </div>
            <div className={c('nd')}>
              <b>Operations Lead</b>
              <span>Hayward &amp; Scottsdale</span>
            </div>
            <div className={c('nd')}>
              <b>Regulatory Lead</b>
              <span>Compliance</span>
            </div>
            <div className={c('nd')}>
              <b>Finance Contact</b>
              <span>Quotes &amp; terms</span>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div className={c('row r3')} style={{ '--c': '1fr 1fr 1fr', marginTop: '22px' } as React.CSSProperties}>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="file" s={22} sw={1.7} />
            Contracts &amp; Templates
          </h3>
          <a className={c('vl')}>View all</a>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#e4f3f6', color: '#0a3f52' } as React.CSSProperties}>
            <Icon n="file" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Mutual NDA template</b>
            <span className={c('s')}>Word &middot; Legal approved</span>
          </div>
          <div className={c('ri')}>
            <span className={c('tag g')}>Current</span>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#fff0e8', color: '#b8431c' } as React.CSSProperties}>
            <Icon n="file" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Master services agreement (MSA)</b>
            <span className={c('s')}>Word &middot; Legal approved</span>
          </div>
          <div className={c('ri')}>
            <span className={c('tag g')}>Current</span>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#e4f1f8', color: '#0a5f70' } as React.CSSProperties}>
            <Icon n="file" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Quality agreement template</b>
            <span className={c('s')}>Word &middot; Legal approved</span>
          </div>
          <div className={c('ri')}>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
      </div>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="clip" s={22} sw={1.7} />
            Vendor Forms
          </h3>
          <a className={c('vl')}>View all</a>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#e4f3f6', color: '#0a3f52' } as React.CSSProperties}>
            <Icon n="clip" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>W-9</b>
            <span className={c('s')}>PDF &middot; 1 page</span>
          </div>
          <div className={c('ri')}>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#fff0e8', color: '#b8431c' } as React.CSSProperties}>
            <Icon n="clip" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Certificate of insurance (COI)</b>
            <span className={c('s')}>PDF &middot; 1 page</span>
          </div>
          <div className={c('ri')}>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#e4f1f8', color: '#0a5f70' } as React.CSSProperties}>
            <Icon n="clip" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Vendor onboarding form</b>
            <span className={c('s')}>PDF &middot; 3 pages</span>
          </div>
          <div className={c('ri')}>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
      </div>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="book" s={22} sw={1.7} />
            Policies
          </h3>
          <a className={c('vl')}>View all</a>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#e4f3f6', color: '#0a3f52' } as React.CSSProperties}>
            <Icon n="book" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Code of conduct</b>
            <span className={c('s')}>PDF &middot; Updated Sep 2026</span>
          </div>
          <div className={c('ri')}>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#fff0e8', color: '#b8431c' } as React.CSSProperties}>
            <Icon n="book" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Confidentiality policy</b>
            <span className={c('s')}>PDF &middot; Updated Aug 2026</span>
          </div>
          <div className={c('ri')}>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#e4f1f8', color: '#0a5f70' } as React.CSSProperties}>
            <Icon n="book" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Travel &amp; expense policy</b>
            <span className={c('s')}>PDF &middot; Updated Jul 2026</span>
          </div>
          <div className={c('ri')}>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
      </div>
    </div>
  </>
);

export default DocumentsPage;
