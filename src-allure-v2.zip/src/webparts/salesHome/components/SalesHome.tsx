import * as React from 'react';

import styles from './SalesHome.module.scss';
import type { ISalesHomeProps } from './ISalesHomeProps';
import { Icon, c } from './ui';
import { img } from './images';
import { NAV, type IPageProps, type PageKey } from './nav';
import HomePage from './pages/HomePage';
import CapabilitiesPage from './pages/CapabilitiesPage';
import InnovationPage from './pages/InnovationPage';
import PricingPage from './pages/PricingPage';
import RegulatoryPage from './pages/RegulatoryPage';
import MarketingPage from './pages/MarketingPage';
import EventsPage from './pages/EventsPage';
import PlaybookPage from './pages/PlaybookPage';
import AccountsPage from './pages/AccountsPage';
import DocumentsPage from './pages/DocumentsPage';

const VIEWS: { [key in PageKey]: React.ComponentType<IPageProps> } = {
  'home': HomePage,
  'capabilities': CapabilitiesPage,
  'innovation': InnovationPage,
  'pricing': PricingPage,
  'regulatory': RegulatoryPage,
  'marketing-assets': MarketingPage,
  'events': EventsPage,
  'sales-playbook': PlaybookPage,
  'accounts': AccountsPage,
  'company-documents': DocumentsPage
};

/** First word of the signed-in user's display name (letters only), or '' when unavailable. */
const firstNameOf = (displayName: string): string => {
  const word: string = (displayName || '').trim().split(/[\s,]+/)[0] || '';
  const ch: string = word.charAt(0);
  return ch.toUpperCase() !== ch.toLowerCase() ? word : '';
};

const SalesHome: React.FC<ISalesHomeProps> = (props) => {
  const [page, setPage] = React.useState<PageKey>('home');
  const rootRef = React.useRef<HTMLDivElement>(null);
  const firstRender = React.useRef<boolean>(true);

  // Bring the top of the web part into view when the user switches page.
  React.useEffect(() => {
    if (firstRender.current) {
      firstRender.current = false;
      return;
    }
    if (rootRef.current) {
      rootRef.current.scrollIntoView({ block: 'start' });
    }
  }, [page]);

  // One delegated handler: any element with data-go="<page>" navigates to that page.
  const onClick = React.useCallback((e: React.MouseEvent<HTMLDivElement>): void => {
    const target: Element | null = (e.target as HTMLElement).closest('[data-go]');
    const key: string | null = target ? target.getAttribute('data-go') : null;
    if (key && Object.prototype.hasOwnProperty.call(VIEWS, key)) {
      e.preventDefault();
      setPage(key as PageKey);
    }
  }, []);

  const View: React.ComponentType<IPageProps> = VIEWS[page];
  const firstName: string = firstNameOf(props.userDisplayName);
  const greeting: string = firstName ? `Welcome back, ${firstName}` : 'Welcome back';

  return (
    <div ref={rootRef} className={styles.pg} onClick={onClick}>
      {props.showSiteHeader !== false && (
        <div className={c('hdr')}>
          <img className={c('logo')} src={img.logo} alt="Allure Beauty Concepts" />
          <div className={c('vd')} />
          <div className={c('hm')}>
            <div className={c('st')}>Sales Hub</div>
            <nav className={c('nav')}>
              {NAV.map((item) => (
                <a key={item.key} href="#" data-go={item.key} className={c(item.key === page ? 'on' : '')}>
                  {item.label}
                  {item.dropdown && <Icon n="chevd" s={15} sw={2} />}
                </a>
              ))}
            </nav>
          </div>
        </div>
      )}
      <div className={c('main')}>
        <View greeting={greeting} />
        <div className={c('foot')}>
          <span>Sample content for design review only. Final wording, images and links to be confirmed with the client.</span>
          <span>Allure Sales Hub</span>
        </div>
      </div>
    </div>
  );
};

export default SalesHome;
