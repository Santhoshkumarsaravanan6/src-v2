import type { IResourceItem } from './data/types';
import { img } from './images';
import { useGroup } from './store';

/** The facilities shown on Home and Capabilities. They come from the "Facilities" rows of the Resources list. */
export const useFacilities = (): IResourceItem[] => useGroup('site', 'Facilities');

/** An uploaded photo wins; otherwise the built-in picture that matches the facility. */
export const facilityPic = (r: IResourceItem): string => (r.FileId && !r.FileMissing && r.Link ? r.Link : (r.Tag === 'scottsdale' ? img.fac2 : img.fac1));

/** Name used to scroll to the facility card. */
export const facilityAnchor = (r: IResourceItem): string => r.Tag || `facility-${r.Id}`;

export const facilityLines = (r: IResourceItem): string[] => (r.Extra || '').split(/\r?\n/).map((x: string) => x.trim()).filter((x: string) => !!x);
