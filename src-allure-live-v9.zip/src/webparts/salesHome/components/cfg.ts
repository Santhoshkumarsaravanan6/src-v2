import type { IResCfg } from './blocks';

const R = (cfg: IResCfg): IResCfg => cfg;

export const CFG: { [id: string]: IResCfg } = {
  quickLinks: R({ section: 'home', group: 'Quick links', title: 'Quick Links', icon: 'link', variant: 'qlinks', limit: 8, singular: 'Link', addLabel: 'Add quick link', subLabel: 'Description (optional)' }),

  capDecks: R({ section: 'capabilities', group: 'Decks', title: 'Capabilities decks', icon: 'file', variant: 'docs', singular: 'Deck', addLabel: 'Add deck' }),
  capProfiles: R({ section: 'capabilities', group: 'Facility profiles', title: 'Facility profiles', icon: 'factory', variant: 'docs', singular: 'Profile', addLabel: 'Add facility profile' }),
  capCerts: R({ section: 'capabilities', group: 'Certifications', title: 'Certifications & Audits', icon: 'shieldc', variant: 'docs', anchor: 'certs', singular: 'Certification', titleLabel: 'Certification or audit', subLabel: 'Facility', tagLabel: 'Status', extraLabel: 'Updated (for example Oct 2026)', addLabel: 'Add certification' }),
  capCases: R({ section: 'capabilities', group: 'Case studies', title: 'Case Studies', icon: 'book', variant: 'thumbs', anchor: 'cases', limit: 3, singular: 'Case study', addLabel: 'Add case study' }),
  capHayStats: R({ section: 'capabilities', group: 'Hayward stats', title: 'Hayward stats', icon: 'factory', variant: 'docs' }),
  capScotStats: R({ section: 'capabilities', group: 'Scottsdale stats', title: 'Scottsdale stats', icon: 'factory', variant: 'docs' }),
  catSkin: R({ section: 'capabilities', group: 'Skincare', title: 'Skincare', icon: 'drop', variant: 'docs', singular: 'Document', addLabel: 'Add document' }),
  catHair: R({ section: 'capabilities', group: 'Haircare', title: 'Haircare', icon: 'wind', variant: 'docs', singular: 'Document', addLabel: 'Add document' }),
  catColor: R({ section: 'capabilities', group: 'Color Cosmetics', title: 'Color Cosmetics', icon: 'palette', variant: 'docs', singular: 'Document', addLabel: 'Add document' }),
  catOtc: R({ section: 'capabilities', group: 'OTC', title: 'OTC', icon: 'shieldc', variant: 'docs', singular: 'Document', addLabel: 'Add document' }),

  concepts: R({ section: 'innovation', group: 'Concepts', title: 'Launch-ready concepts', icon: 'flask', variant: 'docs', anchor: 'formulas', singular: 'Concept', addLabel: 'Add concept', subLabel: 'Description', tagLabel: 'Category', extraLabel: 'Status (for example Launch-ready)' }),
  trends: R({ section: 'innovation', group: 'Trend reports', title: 'Trend Reports', icon: 'trend', variant: 'docs', anchor: 'trends', singular: 'Report', addLabel: 'Add trend report' }),
  innDecks: R({ section: 'innovation', group: 'Presentations', title: 'Innovation Presentations', icon: 'bulb', variant: 'docs', anchor: 'decks', singular: 'Presentation', addLabel: 'Add presentation' }),
  library: R({ section: 'innovation', group: 'Ingredient library', title: 'Ingredient & Claims Library', icon: 'list', variant: 'docs', anchor: 'library', singular: 'Ingredient', titleLabel: 'Ingredient', subLabel: 'Function', extraLabel: 'Claims supported', tagLabel: 'Clean status', addLabel: 'Add ingredient' }),

  rates: R({ section: 'pricing', group: 'Rate cards', title: 'Price Lists & Rate Cards', icon: 'coins', variant: 'docs', anchor: 'rates', singular: 'Rate card', addLabel: 'Add rate card' }),
  moq: R({ section: 'pricing', group: 'MOQ and payment terms', title: 'MOQ & Payment Terms', icon: 'clock', variant: 'docs', anchor: 'moq', singular: 'Row', titleLabel: 'Category', subLabel: 'Standard MOQ', extraLabel: 'Payment terms', addLabel: 'Add row' }),

  clean: R({ section: 'regulatory', group: 'Clean standards', title: 'Clean Standards', icon: 'shieldc', variant: 'docs', anchor: 'clean', singular: 'Standard', titleLabel: 'Standard', subLabel: 'Scope', extraLabel: 'Last reviewed (for example Oct 2026)', addLabel: 'Add standard' }),
  rsl: R({ section: 'regulatory', group: 'Restricted substances', title: 'Restricted Substances Lists', icon: 'shield', variant: 'docs', anchor: 'rsl', singular: 'List', addLabel: 'Add list' }),
  mocra: R({ section: 'regulatory', group: 'MoCRA and FDA guidance', title: 'OTC / FDA & MoCRA Guidance', icon: 'file', variant: 'dated', anchor: 'mocra', dated: true, singular: 'Guidance', addLabel: 'Add guidance' }),
  quest: R({ section: 'regulatory', group: 'Questionnaire templates', title: 'Customer Questionnaire Templates', icon: 'clip', variant: 'docs', anchor: 'quest', singular: 'Template', addLabel: 'Add template' }),

  mktDecks: R({ section: 'marketing-assets', group: 'Decks and one-pagers', title: 'Capabilities Decks & One-Pagers', icon: 'file', variant: 'docs', anchor: 'decks', singular: 'Deck', addLabel: 'Add deck' }),
  brandFiles: R({ section: 'marketing-assets', group: 'Brand files', title: 'Logos & Brand Guidelines', icon: 'sparkle', variant: 'docs', singular: 'Brand file', addLabel: 'Add brand file' }),
  trade: R({ section: 'marketing-assets', group: 'Trade show materials', title: 'Trade Show Booth Materials', icon: 'cal', variant: 'docs', anchor: 'trade', singular: 'Material', addLabel: 'Add material' }),

  playbooks: R({ section: 'events', group: 'Playbooks and checklists', title: 'Playbooks & Checklists', icon: 'check', variant: 'docs', anchor: 'playbooks', singular: 'Playbook', addLabel: 'Add playbook' }),
  recaps: R({ section: 'events', group: 'Event recaps', title: 'Event Recaps', icon: 'book', variant: 'thumbs', anchor: 'recaps', singular: 'Recap', addLabel: 'Add recap' }),

  battle: R({ section: 'sales-playbook', group: 'Battle cards', title: 'Battle Cards & Objection Handling', icon: 'swords', variant: 'docs', anchor: 'battle', singular: 'Battle card', titleLabel: 'Objection', subLabel: 'Short response', extraLabel: 'Talk track', addLabel: 'Add battle card' }),
  templates: R({ section: 'sales-playbook', group: 'Templates', title: 'Email & Proposal Templates', icon: 'mail', variant: 'docs', anchor: 'templates', singular: 'Template', addLabel: 'Add template' }),
  onboarding: R({ section: 'sales-playbook', group: 'Onboarding', title: 'New Rep Onboarding', icon: 'grad', variant: 'docs', anchor: 'onboarding', singular: 'Step', titleLabel: 'Step', subLabel: 'Progress text (for example 3 of 5)', extraLabel: 'Percent complete (0 to 100)', addLabel: 'Add step' }),

  qbr: R({ section: 'accounts', group: 'QBR decks', title: 'QBR Decks', icon: 'trend', variant: 'dated', anchor: 'qbr', dated: true, singular: 'QBR deck', addLabel: 'Add QBR deck' }),
  crm: R({ section: 'accounts', group: 'CRM', title: 'Customer CRM', icon: 'link', variant: 'docs', singular: 'CRM link' }),

  org: R({ section: 'company-documents', group: 'Org chart', title: 'Org Chart', icon: 'org', variant: 'docs', anchor: 'org', singular: 'Role', titleLabel: 'Role or person', subLabel: 'Team', tagLabel: 'Type "lead" for the top box', addLabel: 'Add role' }),
  contracts: R({ section: 'company-documents', group: 'Contracts and templates', title: 'Contracts & Templates', icon: 'file', variant: 'docs', anchor: 'contracts', singular: 'Contract', addLabel: 'Add contract' }),
  vendor: R({ section: 'company-documents', group: 'Vendor forms', title: 'Vendor Forms', icon: 'clip', variant: 'docs', anchor: 'vendor', singular: 'Form', addLabel: 'Add form' }),
  policies: R({ section: 'company-documents', group: 'Policies', title: 'Policies', icon: 'book', variant: 'docs', anchor: 'policies', singular: 'Policy', addLabel: 'Add policy' }),
  // Site-wide text, steps, options, colours and media (all stored in SH_Resources)
  siteBanner: R({ section: 'site', group: 'Site banner', title: 'Top banner', icon: 'sparkle', variant: 'plain', singular: 'Banner', titleLabel: 'Banner text', addLabel: 'Add banner text', hide: ['Sub', 'Tag', 'TagTone', 'Link'], noFile: true }),
  siteFooter: R({ section: 'site', group: 'Site footer', title: 'Footer lines', icon: 'list', variant: 'plain', singular: 'Footer line', titleLabel: 'Line of text', subLabel: 'After the divider (optional)', addLabel: 'Add footer line', hide: ['Tag', 'TagTone', 'Link'], noFile: true }),
  facilities: R({ section: 'site', group: 'Facilities', title: 'Facilities', icon: 'factory', variant: 'plain', singular: 'Facility', titleLabel: 'Location', subLabel: 'Type of facility', extraLabel: 'Highlights (one per line)', hide: ['Tag', 'TagTone', 'Link'], fileLabel: 'Upload a photo', fileAccept: 'image/*' }),
  processSteps: R({ section: 'sales-playbook', group: 'Sales process steps', title: 'Sales process steps', icon: 'target', variant: 'plain', singular: 'Step', titleLabel: 'Step name', subLabel: 'What happens', addLabel: 'Add step', hide: ['Tag', 'TagTone', 'Link'], noFile: true }),
  discountSteps: R({ section: 'pricing', group: 'Discount approval steps', title: 'Discount approval steps', icon: 'check', variant: 'plain', singular: 'Step', titleLabel: 'Who approves', subLabel: 'When', addLabel: 'Add step', hide: ['Tag', 'TagTone', 'Link'], noFile: true }),
  brandColors: R({ section: 'marketing-assets', group: 'Brand colours', title: 'Brand colours', icon: 'palette', variant: 'plain', singular: 'Colour', titleLabel: 'Colour name', subLabel: 'Hex code (for example #0A3F52)', addLabel: 'Add colour', hide: ['Tag', 'TagTone', 'Link'], noFile: true }),
  gallery: R({ section: 'marketing-assets', group: 'Photos and videos', title: 'Photos & Videos', icon: 'image', variant: 'plain', singular: 'Photo', titleLabel: 'Photo name', addLabel: 'Add photo', hide: ['Sub', 'Tag', 'TagTone'], fileLabel: 'Upload a photo', fileAccept: 'image/*' }),
  chEventTypes: R({ section: 'choices', group: 'Event types', title: 'Event types', icon: 'cal', variant: 'plain', singular: 'Option', titleLabel: 'Option', addLabel: 'Add event type', hide: ['Sub', 'Tag', 'TagTone', 'Link'], noFile: true }),
  chStages: R({ section: 'choices', group: 'Account stages', title: 'Account stages', icon: 'users', variant: 'plain', singular: 'Option', titleLabel: 'Option', addLabel: 'Add stage', hide: ['Sub', 'Tag', 'TagTone', 'Link'], noFile: true }),
  chCategories: R({ section: 'choices', group: 'Quote categories', title: 'Quote and lead categories', icon: 'coins', variant: 'plain', singular: 'Option', titleLabel: 'Option', addLabel: 'Add category', hide: ['Sub', 'Tag', 'TagTone', 'Link'], noFile: true }),
  chStatuses: R({ section: 'choices', group: 'Quote statuses', title: 'Quote statuses', icon: 'check', variant: 'plain', singular: 'Option', titleLabel: 'Option', addLabel: 'Add status', hide: ['Sub', 'Tag', 'TagTone', 'Link'], noFile: true })
};
