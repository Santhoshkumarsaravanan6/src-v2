import type { FieldValues, ListKey } from './types';

/** Sample content written to the lists the first time the hub is opened. Edit it in the app or in the lists. */
let order: number = 0;
const R = (section: string, group: string, title: string, sub: string = '', tag: string = '', tone: string = '', link: string = '', extra: string = '', date: string = ''): FieldValues => {
  order += 1;
  return { Title: title, Section: section, Group: group, Sub: sub, Extra: extra, Tag: tag, TagTone: tone, Link: link, ItemDate: date, SortOrder: order };
};

/** Dates in the sample content are worked out from the day the site is first set up, so they never look out of date. */
const NOW: Date = new Date();
const DAY_MS: number = 86400000;
const MONTHS: string[] = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const day = (offset: number): string => new Date(NOW.getTime() + offset * DAY_MS).toISOString().slice(0, 10);
const mo = (offset: number): string => { const d: Date = new Date(NOW.getFullYear(), NOW.getMonth() + offset, 1); return `${MONTHS[d.getMonth()]} ${d.getFullYear()}`; };
const q = (offset: number): string => { const k: number = Math.floor(NOW.getMonth() / 3) + offset; return `Q${(((k % 4) + 4) % 4) + 1} ${NOW.getFullYear() + Math.floor(k / 4)}`; };
const yr = (offset: number): string => String(NOW.getFullYear() + offset);

const HOME: string = 'home';
const CAP: string = 'capabilities';
const INN: string = 'innovation';
const PRI: string = 'pricing';
const REG: string = 'regulatory';
const MKT: string = 'marketing-assets';
const EVT: string = 'events';
const PLB: string = 'sales-playbook';
const ACC: string = 'accounts';
const DOC: string = 'company-documents';
const SITE: string = 'site';
const CHO: string = 'choices';

export const SEED: { [key in ListKey]: FieldValues[] } = {
  events: [
    { Title: 'Customer call: Account A sample review', EventDate: day(7), Location: 'Video call', EventType: 'Meeting', Notes: 'Walk through the serum and night cream samples' },
    { Title: 'Cosmoprof North America', EventDate: day(16), Location: 'Las Vegas, NV', EventType: 'Trade show', Notes: 'Booth B214' },
    { Title: 'Customer visit: Scottsdale', EventDate: day(22), Location: 'Scottsdale, AZ', EventType: 'Customer visit', Notes: 'Tour of the innovation labs and pilot line' },
    { Title: 'Quarterly business review', EventDate: day(28), Location: 'Hayward, CA', EventType: 'Meeting', Notes: 'Account reviews for the quarter' },
    { Title: `Webinar: Clean formulation trends for ${yr(1)}`, EventDate: day(56), Location: 'Online', EventType: 'Webinar', Notes: 'Co-hosted with the regulatory team' },
    { Title: 'Beauty Innovation Summit', EventDate: day(64), Location: 'New York, NY', EventType: 'Conference', Notes: 'Panel on private-label growth' },
    { Title: 'Private-label sourcing roundtable', EventDate: day(92), Location: 'Chicago, IL', EventType: 'Conference', Notes: 'Invited speaker slot' },
    { Title: 'Indie Beauty Expo', EventDate: day(113), Location: 'Los Angeles, CA', EventType: 'Trade show', Notes: 'Booth to be confirmed' },
    { Title: 'Cosmetic Ingredient Expo', EventDate: day(155), Location: 'Boston, MA', EventType: 'Trade show', Notes: 'Ingredient library showcase' },
    { Title: 'Supplier audit visit: Hayward', EventDate: day(-61), Location: 'Hayward, CA', EventType: 'Customer visit', Notes: 'Completed, no major findings' },
    { Title: 'Q3 pricing review', EventDate: day(-40), Location: 'Video call', EventType: 'Meeting', Notes: 'Rate cards approved for Q4' },
    { Title: 'MoCRA readiness webinar', EventDate: day(-27), Location: 'Online', EventType: 'Webinar', Notes: 'Recording available in Regulatory' }
  ],
  news: [
    { Title: 'New Skincare Line Now Available', PublishDate: day(-7), Summary: 'Our new skincare line is ready to sample. Ask the innovation team for formulas and pricing.', Link: '' },
    { Title: `Successful Launch at Cosmoprof ${yr(0)}`, PublishDate: day(-12), Summary: 'The team captured qualified leads at the show. See the event recap for details.', Link: 'page:events#recaps' },
    { Title: 'Scottsdale pilot line expansion complete', PublishDate: day(-15), Summary: 'A second pilot line is now running, cutting small-batch lead times for new launches.', Link: 'page:capabilities#facilities' },
    { Title: 'MoCRA Compliance Update', PublishDate: day(-20), Summary: 'Updated guidance on MoCRA facility registration and product listing.', Link: 'page:regulatory#mocra' },
    { Title: 'Q4 rate cards are live', PublishDate: day(-28), Summary: 'Skincare, haircare and OTC rate cards were refreshed. Request access if you cannot see Pricing.', Link: 'page:pricing#rates' },
    { Title: 'New rep onboarding path updated', PublishDate: day(-42), Summary: 'The four-week onboarding path now includes a shadowing week and a first-call review.', Link: 'page:sales-playbook#onboarding' }
  ],
  wins: [
    { Title: 'Won 3-SKU skincare program', Summary: 'Private-label launch for a new retail partner', Category: 'Skincare' },
    { Title: 'Sulfate-free shampoo line', Summary: 'Scottsdale facility, first PO received', Category: 'Haircare' },
    { Title: 'SPF OTC reformulation', Summary: 'Approved by the customer', Category: 'OTC' },
    { Title: 'Tinted lip oil range signed', Summary: 'Four shades, first run planned for Q1', Category: 'Color cosmetics' },
    { Title: 'Repeat order from Account B', Summary: 'Volume up 40% on the previous run', Category: 'Haircare' },
    { Title: 'Retailer clean audit passed', Summary: 'Zero findings on the ingredient disclosure review', Category: 'Skincare' }
  ],
  accounts: [
    { Title: 'Account A', Segment: 'Skincare', Owner: 'Sales rep', Stage: 'Active', PlanLink: '' },
    { Title: 'Account B', Segment: 'Haircare', Owner: 'Sales rep', Stage: 'Active', PlanLink: '' },
    { Title: 'Account C', Segment: 'Color cosmetics', Owner: 'Sales rep', Stage: 'Quoting', PlanLink: '' },
    { Title: 'Account D', Segment: 'OTC', Owner: 'Sales rep', Stage: 'Sampling', PlanLink: '' },
    { Title: 'Account E', Segment: 'Skincare', Owner: 'Sales rep', Stage: 'Sampling', PlanLink: '' },
    { Title: 'Account F', Segment: 'Skincare', Owner: 'Sales rep', Stage: 'Prospect', PlanLink: '' },
    { Title: 'Account G', Segment: 'Haircare', Owner: 'Sales rep', Stage: 'On hold', PlanLink: '' }
  ],
  requests: [
    { RequestType: 'Quote', Title: 'Account A', Category: 'Skincare', Quantity: '25,000 units', TargetDate: day(90), Contact: '', Notes: 'Night cream, 50 ml airless jar', Status: 'In review' },
    { RequestType: 'Quote', Title: 'Account B', Category: 'Haircare', Quantity: '40,000 units', TargetDate: day(74), Contact: '', Notes: 'Repeat run, new 300 ml bottle', Status: 'Quoted' },
    { RequestType: 'Quote', Title: 'Account C', Category: 'Color cosmetics', Quantity: '15,000 units', TargetDate: day(123), Contact: '', Notes: 'Four-shade lip oil, tube packaging', Status: 'New' },
    { RequestType: 'Quote', Title: 'Account D', Category: 'OTC', Quantity: '30,000 units', TargetDate: day(144), Contact: '', Notes: 'Mineral SPF 30, FDA monograph', Status: 'Won' },
    { RequestType: 'Lead', Title: 'Sample lead 1', Category: 'Skincare', Quantity: '', TargetDate: '', Contact: 'Company name, contact email', Notes: 'Event: Cosmoprof North America. Wants barrier-repair samples.', Status: 'New' },
    { RequestType: 'Lead', Title: 'Sample lead 2', Category: 'Haircare', Quantity: '', TargetDate: '', Contact: 'Company name, contact email', Notes: 'Event: Indie Beauty Expo. Scalp-care range, follow up next week.', Status: 'Contacted' },
    { RequestType: 'Lead', Title: 'Sample lead 3', Category: 'OTC', Quantity: '', TargetDate: '', Contact: 'Company name, contact email', Notes: 'Event: Beauty Innovation Summit. Interested in tinted SPF.', Status: 'Sample sent' }
  ],
  resources: [
    // Home
    R(HOME, 'Quick links', 'Sales Playbook', '', '', '', 'page:sales-playbook'),
    R(HOME, 'Quick links', 'Customer Accounts (CRM)', '', '', '', 'page:accounts#crm'),
    R(HOME, 'Quick links', 'Company Documents', '', '', '', 'page:company-documents'),
    R(HOME, 'Quick links', 'R&D Resources', '', '', '', 'page:innovation'),
    R(HOME, 'Quick links', 'Sales Templates', '', '', '', 'page:sales-playbook#templates'),
    R(HOME, 'Quick links', 'Request a Quote', '', '', '', 'page:pricing#quote'),
    R(HOME, 'Quick links', 'Trade Show Calendar', '', '', '', 'page:events#calendar'),
    R(HOME, 'Quick links', 'Brand Assets', '', '', '', 'page:marketing-assets#brand'),
    // Capabilities
    R(CAP, 'Decks', 'Allure capabilities deck', 'PowerPoint · 32 slides', 'Current', 'g'),
    R(CAP, 'Decks', 'Private-label programs overview', 'PowerPoint · 18 slides', 'Current', 'g'),
    R(CAP, 'Decks', 'Contract manufacturing at a glance', 'PowerPoint · 10 slides'),
    R(CAP, 'Facility profiles', 'Hayward, CA facility profile', 'PDF · 4 pages', 'Current', 'g'),
    R(CAP, 'Facility profiles', 'Scottsdale, AZ facility profile', 'PDF · 4 pages', 'Current', 'g'),
    R(CAP, 'Hayward stats', '65,000', 'Facility size (sq ft)'), R(CAP, 'Hayward stats', '12', 'Filling lines'), R(CAP, 'Hayward stats', '8 to 10 wks', 'Typical lead time'),
    R(CAP, 'Scottsdale stats', '48,000', 'Facility size (sq ft)'), R(CAP, 'Scottsdale stats', '6', 'R&D labs'), R(CAP, 'Scottsdale stats', '6 to 8 wks', 'Typical lead time'),
    R(CAP, 'Certifications', 'cGMP', 'Hayward & Scottsdale', 'Current', 'g', '', `${mo(-1)}`),
    R(CAP, 'Certifications', 'ISO 22716', 'Hayward', 'Current', 'g', '', `${mo(-2)}`),
    R(CAP, 'Certifications', 'FDA registration', 'Hayward & Scottsdale', 'Current', 'g', '', `${mo(-3)}`),
    R(CAP, 'Certifications', 'MoCRA facility registration', 'Hayward & Scottsdale', 'Current', 'g', '', `${mo(-1)}`),
    R(CAP, 'Certifications', 'Customer audits', 'Both', 'Reports available', '', '', `${mo(0)}`),
    R(CAP, 'Case studies', 'Private-label skincare launch', 'From concept to shelf in 14 weeks'),
    R(CAP, 'Case studies', 'Sulfate-free haircare range', 'Scottsdale pilot to full production'),
    R(CAP, 'Case studies', 'SPF OTC reformulation', 'Meeting FDA monograph requirements'),
    R(CAP, 'Case studies', 'Clean color cosmetics refresh', 'Reformulated 12 shades to a retailer clean list'),
    R(CAP, 'Skincare', 'Skincare capabilities overview', 'Creams, serums, lotions & cleansers', 'Overview'),
    R(CAP, 'Skincare', 'Skincare sample request form', 'Word · ready to complete', 'Template', 'b'),
    R(CAP, 'Skincare', 'Stability and compatibility testing', 'PDF · 3 pages'),
    R(CAP, 'Haircare', 'Haircare capabilities overview', 'Shampoo, conditioner & treatments', 'Overview'),
    R(CAP, 'Haircare', 'Haircare sample request form', 'Word · ready to complete', 'Template', 'b'),
    R(CAP, 'Haircare', 'Sulfate-free formulation guide', 'PDF · 5 pages'),
    R(CAP, 'Color Cosmetics', 'Color cosmetics capabilities overview', 'Face, lip & eye products', 'Overview'),
    R(CAP, 'Color Cosmetics', 'Shade-matching process', 'PDF · 2 pages'),
    R(CAP, 'Color Cosmetics', 'Pigment and filler options', 'PDF · 4 pages'),
    R(CAP, 'OTC', 'OTC capabilities overview', 'SPF, acne & drug-regulated products', 'Overview'),
    R(CAP, 'OTC', 'OTC monograph guide', 'PDF · 6 pages'),
    R(CAP, 'OTC', 'SPF testing and labeling checklist', 'PDF · 2 pages', 'Checklist', 'g'),
    // Innovation
    R(INN, 'Concepts', 'Barrier-repair night cream', 'Ceramide complex, fragrance-free, ready for sampling', 'Skincare', '', '', 'Launch-ready'),
    R(INN, 'Concepts', 'Brightening vitamin C serum', 'Stable 15% format with airless pack option', 'Skincare', '', '', 'Launch-ready'),
    R(INN, 'Concepts', 'Tinted mineral SPF 30', 'Sheer finish, reef-safe filters', 'OTC', 'b', '', 'In development'),
    R(INN, 'Concepts', 'Scalp-care treatment', 'Sulfate-free, peptide and niacinamide blend', 'Haircare', 'o', '', 'Launch-ready'),
    R(INN, 'Concepts', 'Hydrating lip oil', 'Non-sticky gloss with squalane and vitamin E', 'Color cosmetics', 'p', '', 'Launch-ready'),
    R(INN, 'Concepts', 'Overnight bond-repair mask', 'Rinse-off treatment for damaged hair', 'Haircare', 'o', '', 'In development'),
    R(INN, 'Trend reports', `Clean & skin-first beauty ${yr(1)}`, `Quarterly report · ${mo(0)}`),
    R(INN, 'Trend reports', 'Scalp care goes mainstream', `Haircare insight · ${mo(-1)}`),
    R(INN, 'Trend reports', 'Multifunctional color cosmetics', `Color insight · ${mo(-2)}`),
    R(INN, 'Trend reports', 'Sunscreen innovation outlook', `OTC insight · ${mo(-3)}`),
    R(INN, 'Presentations', 'Q4 launch-ready concepts', 'Customer-ready deck · 24 slides'),
    R(INN, 'Presentations', 'Hayward innovation lab overview', 'Capabilities deck · 12 slides'),
    R(INN, 'Presentations', 'Clean formulation roadmap', 'Strategy deck · 18 slides'),
    R(INN, 'Presentations', 'Packaging and sustainability options', 'Customer-ready deck · 15 slides'),
    R(INN, 'Ingredient library', 'Niacinamide', 'Skin conditioning', 'Credo & Sephora', 'g', '', 'Visibly refines pores, evens tone'),
    R(INN, 'Ingredient library', 'Ceramide NP', 'Barrier support', 'Credo & Sephora', 'g', '', 'Helps restore moisture barrier'),
    R(INN, 'Ingredient library', 'Peptide complex', 'Scalp conditioning', 'Credo & Sephora', 'g', '', 'Supports a healthy-looking scalp'),
    R(INN, 'Ingredient library', 'Zinc oxide', 'UV filter', 'FDA monograph', 'b', '', 'Broad-spectrum protection'),
    R(INN, 'Ingredient library', 'Squalane', 'Emollient', 'Credo & Sephora', 'g', '', 'Lightweight, non-greasy moisture'),
    R(INN, 'Ingredient library', 'Hyaluronic acid', 'Humectant', 'Credo & Sephora', 'g', '', 'Plumps and hydrates the skin surface'),
    R(INN, 'Ingredient library', 'Panthenol', 'Hair and skin conditioning', 'Credo & Sephora', 'g', '', 'Smooths and softens, supports shine'),
    R(INN, 'Ingredient library', 'Bakuchiol', 'Retinol alternative', 'Credo & Sephora', 'g', '', 'Visibly smooths fine lines'),
    // Pricing
    R(PRI, 'Rate cards', `Skincare rate card ${q(0)}`, `Updated ${mo(0)} · PDF`, 'Current', 'g'),
    R(PRI, 'Rate cards', `Haircare rate card ${q(0)}`, `Updated ${mo(0)} · PDF`, 'Current', 'g'),
    R(PRI, 'Rate cards', 'Color cosmetics rate card', `Updated ${mo(-1)} · XLSX`),
    R(PRI, 'Rate cards', `OTC rate card ${q(0)}`, `Updated ${mo(-1)} · PDF`),
    R(PRI, 'Rate cards', 'Packaging price list', `Updated ${mo(-1)} · XLSX`),
    R(PRI, 'MOQ and payment terms', 'Skincare', '5,000 units', '', '', '', 'Net 30'),
    R(PRI, 'MOQ and payment terms', 'Haircare', '10,000 units', '', '', '', 'Net 30'),
    R(PRI, 'MOQ and payment terms', 'Color cosmetics', '3,000 units per shade', '', '', '', 'Net 45'),
    R(PRI, 'MOQ and payment terms', 'OTC', '10,000 units', '', '', '', 'Net 30'),
    R(PRI, 'MOQ and payment terms', 'Pilot batches', '500 units', '', '', '', '50% deposit'),
    // Regulatory
    R(REG, 'Clean standards', 'Credo Clean Standard', 'Skincare, haircare, color', '', '', '', `${mo(-1)}`),
    R(REG, 'Clean standards', 'Clean at Sephora', 'All categories', '', '', '', `${mo(-1)}`),
    R(REG, 'Clean standards', 'Retailer-specific lists', 'Per customer', '', '', '', `${mo(-2)}`),
    R(REG, 'Clean standards', 'Vegan and cruelty-free claims', 'Claims substantiation', '', '', '', `${mo(-3)}`),
    R(REG, 'Restricted substances', 'Master restricted substances list', `Updated ${mo(-1)} · PDF`, 'Current', 'g'),
    R(REG, 'Restricted substances', 'EU & UK cosmetics annexes', `Updated ${mo(-2)} · PDF`),
    R(REG, 'Restricted substances', 'California & state-level lists', `Updated ${mo(-2)} · PDF`),
    R(REG, 'Restricted substances', 'PFAS declaration guide', `Updated ${mo(-1)} · PDF`, 'New', 'o'),
    R(REG, 'MoCRA and FDA guidance', 'MoCRA facility registration renewal checklist', 'Guidance note', '', '', '', '', day(-7)),
    R(REG, 'MoCRA and FDA guidance', 'MoCRA compliance update', 'Regulatory update', '', '', '', '', day(-20)),
    R(REG, 'MoCRA and FDA guidance', 'OTC monograph labeling quick guide', 'Guidance note', '', '', '', '', day(-36)),
    R(REG, 'MoCRA and FDA guidance', 'Adverse event reporting procedure', 'Guidance note', '', '', '', '', day(-48)),
    R(REG, 'Questionnaire templates', 'Standard supplier questionnaire', 'Word · ready to complete', 'Template'),
    R(REG, 'Questionnaire templates', 'Retailer compliance questionnaire', 'Word · ready to complete', 'Template', 'o'),
    R(REG, 'Questionnaire templates', 'Ingredient disclosure form', 'Excel · ready to complete', 'Template', 'b'),
    R(REG, 'Questionnaire templates', 'Sustainability and sourcing questionnaire', 'Word · ready to complete', 'Template', 'g'),
    // Marketing assets
    R(MKT, 'Decks and one-pagers', 'Allure capabilities deck', 'PowerPoint · 32 slides', 'Current', 'g'),
    R(MKT, 'Decks and one-pagers', 'Hayward facility one-pager', 'PDF · 2 pages'),
    R(MKT, 'Decks and one-pagers', 'Scottsdale facility one-pager', 'PDF · 2 pages'),
    R(MKT, 'Decks and one-pagers', 'Innovation capabilities overview', 'PowerPoint · 14 slides'),
    R(MKT, 'Decks and one-pagers', 'Private-label starter guide', 'PDF · 6 pages', 'New', 'o'),
    R(MKT, 'Brand files', 'Logo pack (SVG, PNG)', 'Zip · approved logos'),
    R(MKT, 'Brand files', 'Brand guidelines', 'PDF · usage rules'),
    R(MKT, 'Brand files', 'Email signature and letterhead', 'Zip · Word and PNG'),
    R(MKT, 'Brand files', 'Presentation template', 'PowerPoint · 20 layouts'),
    R(MKT, 'Trade show materials', 'Booth graphics, print-ready', 'Zip · 180 MB'),
    R(MKT, 'Trade show materials', 'Brochure and handout set', 'PDF · 6 files'),
    R(MKT, 'Trade show materials', 'Booth setup guide', 'PDF · 4 pages'),
    R(MKT, 'Trade show materials', 'Sample kit packing list', 'PDF · 1 page'),
    // Events
    R(EVT, 'Playbooks and checklists', 'Trade show planning playbook', 'Word · 8 pages', 'Playbook'),
    R(EVT, 'Playbooks and checklists', 'Booth day-of checklist', 'PDF · 2 pages', 'Checklist', 'g'),
    R(EVT, 'Playbooks and checklists', 'Post-show follow-up checklist', 'PDF · 2 pages', 'Checklist', 'g'),
    R(EVT, 'Playbooks and checklists', 'Lead scoring guide', 'PDF · 1 page', 'Guide', 'b'),
    R(EVT, 'Event recaps', `Cosmoprof ${yr(0)} recap`, `${mo(0)} · 42 qualified leads`),
    R(EVT, 'Event recaps', `Indie Beauty Expo ${yr(0)} recap`, `${mo(-8)} · 27 qualified leads`),
    R(EVT, 'Event recaps', `Beauty Innovation Summit ${yr(0)}`, `${mo(-10)} · Key learnings`),
    R(EVT, 'Event recaps', `Cosmetic Ingredient Expo ${yr(0)}`, `${mo(-7)} · 19 qualified leads`),
    // Sales playbook
    R(PLB, 'Battle cards', 'We are concerned about minimum order quantities', 'Lead with pilot runs and scalable batches', '', '', '', 'Offer pilot batches first, then scale to full production as volume grows.'),
    R(PLB, 'Battle cards', 'Can you meet clean-beauty standards?', 'Credo and Sephora compliance, documented', '', '', '', 'Share the clean standards pages and the ingredient library.'),
    R(PLB, 'Battle cards', 'How fast can you get samples to us?', 'Sampling timelines by category', '', '', '', 'Confirm the category, then quote the typical sampling lead time.'),
    R(PLB, 'Battle cards', 'Your price is higher than another supplier', 'Position total value, not unit price', '', '', '', 'Compare yield, quality records and speed to market, then offer a tiered quote.'),
    R(PLB, 'Battle cards', 'Can you handle our own formula?', 'Yes, with tech transfer support', '', '', '', 'Explain the tech transfer steps and request the formula and specifications under NDA.'),
    R(PLB, 'Templates', 'Introduction email', 'Word · ready to send', 'Template'),
    R(PLB, 'Templates', 'Follow-up after sample', 'Word · ready to send', 'Template', 'o'),
    R(PLB, 'Templates', 'Proposal template', 'PowerPoint · 12 slides', 'Template', 'b'),
    R(PLB, 'Templates', 'Meeting recap email', 'Word · ready to send', 'Template', 'g'),
    R(PLB, 'Onboarding', 'Week 1: Company & products', '5 of 5', '', '', '', '100'),
    R(PLB, 'Onboarding', 'Week 2: Capabilities & facilities', '3 of 5', '', '', '', '60'),
    R(PLB, 'Onboarding', 'Week 3: Pricing & regulatory', '1 of 5', '', '', '', '20'),
    R(PLB, 'Onboarding', 'Week 4: Shadowing & first call', '0 of 5', '', '', '', '0'),
    // Accounts
    R(ACC, 'QBR decks', `${q(0)} QBR: Account A`, 'Hayward, CA', '', '', '', '', day(28)),
    R(ACC, 'QBR decks', `${q(0)} QBR: Account B`, 'Video call', '', '', '', '', day(30)),
    R(ACC, 'QBR decks', `${q(-1)} QBR: Account C`, 'Video call', '', '', '', '', day(-56)),
    R(ACC, 'QBR decks', `${q(-2)} QBR: Account D`, 'Scottsdale, AZ', '', '', '', '', day(-152)),
    R(ACC, 'CRM', 'Customer CRM', 'Pipeline, contacts and activity for every account'),
    // Company documents
    R(DOC, 'Org chart', 'Leadership', 'Executive team', 'lead'),
    R(DOC, 'Org chart', 'Sales Director', 'Sales & accounts'),
    R(DOC, 'Org chart', 'Operations Lead', 'Hayward & Scottsdale'),
    R(DOC, 'Org chart', 'Regulatory Lead', 'Compliance'),
    R(DOC, 'Org chart', 'Finance Lead', 'Finance & contracts'),
    R(DOC, 'Org chart', 'Innovation Lead', 'R&D and formulation'),
    R(DOC, 'Contracts and templates', 'Mutual NDA template', 'Word · Legal approved', 'Current', 'g'),
    R(DOC, 'Contracts and templates', 'Master services agreement (MSA)', 'Word · Legal approved', 'Current', 'g'),
    R(DOC, 'Contracts and templates', 'Quality agreement template', 'Word · Legal approved'),
    R(DOC, 'Contracts and templates', 'Supply agreement template', 'Word · Legal approved'),
    R(DOC, 'Vendor forms', 'W-9', 'PDF · 1 page'),
    R(DOC, 'Vendor forms', 'Certificate of insurance (COI)', 'PDF · 1 page'),
    R(DOC, 'Vendor forms', 'Vendor onboarding form', 'PDF · 3 pages'),
    R(DOC, 'Vendor forms', 'Banking details change form', 'PDF · 1 page'),
    R(DOC, 'Policies', 'Code of conduct', `PDF · Updated ${mo(-2)}`),
    R(DOC, 'Policies', 'Confidentiality policy', `PDF · Updated ${mo(-3)}`),
    R(DOC, 'Policies', 'Travel & expense policy', `PDF · Updated ${mo(-4)}`),
    R(DOC, 'Policies', 'Information security policy', `PDF · Updated ${mo(-5)}`),
    // Site-wide text, steps, choices and media (added in v3)
    R(SITE, 'Site banner', 'Two industry trailblazers — Allure Labs and Kleen Concepts — are now Allure Beauty Concepts.'),
    R(SITE, 'Site footer', '30901 Wiegman Rd, Hayward, CA 94544', '(510) 489-8896'),
    R(SITE, 'Site footer', '8388 E Hartford Dr #105, Scottsdale, AZ 85255', '(480) 515-5576'),
    R(SITE, 'Site footer', 'Partner with us', 'info@allurebeautyconcepts.com'),
    R(SITE, 'Site footer', 'Allure Beauty Concepts · Internal use only', '', 'small'),
    R(SITE, 'Facilities', 'Hayward, CA', 'Manufacturing Facility', 'hayward', '', '', 'Contract manufacturing\nFilling & assembly\nMass & pilot production'),
    R(SITE, 'Facilities', 'Scottsdale, AZ', 'Manufacturing Facility', 'scottsdale', '', '', 'Specialized formulations\nInnovation & development\nScalable manufacturing'),
    R(PLB, 'Sales process steps', 'Prospect', 'Identify brands that fit our categories'),
    R(PLB, 'Sales process steps', 'Qualify', 'Budget, volume, timeline and fit'),
    R(PLB, 'Sales process steps', 'Develop', 'Samples, formula and pricing'),
    R(PLB, 'Sales process steps', 'Quote', 'Costing and approval'),
    R(PLB, 'Sales process steps', 'Launch', 'Production and first shipment'),
    R(PRI, 'Discount approval steps', 'Sales rep', 'Up to the standard threshold'),
    R(PRI, 'Discount approval steps', 'Sales Director', 'Above standard threshold'),
    R(PRI, 'Discount approval steps', 'Finance & leadership', 'Exceptions and strategic deals'),
    R(MKT, 'Brand colours', 'Navy', '#0A3F52'),
    R(MKT, 'Brand colours', 'Teal', '#159BAC'),
    R(MKT, 'Brand colours', 'Cyan', '#70CFDB'),
    R(MKT, 'Brand colours', 'Orange', '#FC6337'),
    R(MKT, 'Brand colours', 'Tint', '#E9F5F8'),
    R(MKT, 'Photos and videos', 'Hayward facility', '', 'fac1'),
    R(MKT, 'Photos and videos', 'Scottsdale facility', '', 'fac2'),
    R(MKT, 'Photos and videos', 'Skincare hero', '', 'jar'),
    R(MKT, 'Photos and videos', 'Serum close-up', '', 'dropper'),
    R(MKT, 'Photos and videos', 'Tube & packaging', '', 'tube'),
    R(MKT, 'Photos and videos', 'Botanical lifestyle', '', 'flower'),
    ...['Trade show', 'Conference', 'Customer visit', 'Meeting', 'Webinar', 'Other'].map((t: string) => R(CHO, 'Event types', t)),
    ...['Prospect', 'Sampling', 'Quoting', 'Active', 'On hold'].map((t: string) => R(CHO, 'Account stages', t)),
    ...['Skincare', 'Haircare', 'Color cosmetics', 'OTC', 'Other'].map((t: string) => R(CHO, 'Quote categories', t)),
    ...['New', 'In review', 'Quoted', 'Won', 'Lost'].map((t: string) => R(CHO, 'Quote statuses', t))
  ]
};

/** Groups added after the first release. A list from an earlier version only receives these, never a full refill. */
export const NEW_GROUPS: string[] = ['Site banner', 'Site footer', 'Facilities', 'Sales process steps', 'Discount approval steps', 'Brand colours', 'Photos and videos', 'Event types', 'Account stages', 'Quote categories', 'Quote statuses'];

/** Identifies a sample row, so rows that already exist are not written twice. */
export const seedKey = (key: ListKey, r: FieldValues): string => (key === 'resources' ? `${r.Section}|${r.Group}|${r.Title}` : String(r.Title));
