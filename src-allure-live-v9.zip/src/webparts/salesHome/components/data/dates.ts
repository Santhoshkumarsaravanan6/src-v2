const MONTHS: string[] = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const FULL: string[] = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

const pad = (v: number): string => (v < 10 ? '0' + v : String(v));

export const keyOf = (y: number, m: number, d: number): string => `${y}-${pad(m + 1)}-${pad(d)}`;

export const todayKey = (): string => {
  const n: Date = new Date();
  return keyOf(n.getFullYear(), n.getMonth(), n.getDate());
};

export interface IDateParts { y: number; m: number; d: number; valid: boolean }

/** Splits "YYYY-MM-DD" (extra time text is ignored). m is zero-based. */
export const parts = (key: string): IDateParts => {
  const mt: RegExpMatchArray | null = (key || '').match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (!mt) {
    return { y: 0, m: 0, d: 0, valid: false };
  }
  return { y: Number(mt[1]), m: Number(mt[2]) - 1, d: Number(mt[3]), valid: true };
};

export const monShort = (key: string): string => (parts(key).valid ? MONTHS[parts(key).m].toUpperCase() : '');
export const dayNum = (key: string): string => (parts(key).valid ? pad(parts(key).d) : '');
export const monthName = (m: number): string => FULL[m];
export const fmtLong = (key: string): string => {
  const p: IDateParts = parts(key);
  return p.valid ? `${MONTHS[p.m]} ${p.d}, ${p.y}` : '';
};
export const daysIn = (y: number, m: number): number => new Date(y, m + 1, 0).getDate();
export const firstWeekday = (y: number, m: number): number => new Date(y, m, 1).getDay();
