import type { ListKey } from './types';

export type FieldKind = 'Text' | 'Note' | 'Number';

export interface IFieldDef {
  name: string;
  kind: FieldKind;
}

export interface IListDef {
  key: ListKey;
  title: string;
  description: string;
  fields: IFieldDef[];
}

const t = (name: string): IFieldDef => ({ name, kind: 'Text' });
const n = (name: string): IFieldDef => ({ name, kind: 'Note' });

/** Lists created automatically in the site that hosts the Sales Hub. "Title" always exists. */
export const LISTS: IListDef[] = [
  { key: 'events', title: 'SH_Events', description: 'Sales Hub: events and trade shows', fields: [t('EventDate'), t('Location'), t('EventType'), n('Notes')] },
  { key: 'news', title: 'SH_News', description: 'Sales Hub: latest updates', fields: [t('PublishDate'), n('Summary'), n('Link')] },
  { key: 'wins', title: 'SH_Wins', description: 'Sales Hub: recent wins', fields: [n('Summary'), t('Category')] },
  {
    key: 'resources', title: 'SH_Resources', description: 'Sales Hub: documents, links, tables and lists shown on every page',
    fields: [t('Section'), t('Group'), t('Sub'), n('Extra'), t('Tag'), t('TagTone'), n('Link'), t('ItemDate'), { name: 'SortOrder', kind: 'Number' }, { name: 'FileId', kind: 'Number' }, t('FileName')]
  },
  { key: 'accounts', title: 'SH_Accounts', description: 'Sales Hub: account plans', fields: [t('Segment'), t('Owner'), t('Stage'), n('PlanLink')] },
  { key: 'requests', title: 'SH_Requests', description: 'Sales Hub: quote requests and captured leads', fields: [t('RequestType'), t('Category'), t('Quantity'), t('TargetDate'), t('Contact'), n('Notes'), t('Status')] }
];

export const listDef = (key: ListKey): IListDef => LISTS.filter((l: IListDef) => l.key === key)[0];

/** Document library that holds uploaded files. HubSection/HubGroup record where in the hub a file was added. */
export const LIBRARY: { title: string; description: string; fields: IFieldDef[] } = {
  title: 'SH_Documents',
  description: 'Sales Hub: files uploaded from the hub',
  fields: [t('HubSection'), t('HubGroup')]
};
