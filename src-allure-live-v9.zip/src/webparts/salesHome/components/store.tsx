import * as React from 'react';
import { createPortal } from 'react-dom';

import { c, Icon } from './ui';
import type { PageKey } from './nav';
import type { FieldValues, IAccountItem, IDataService, IEventItem, IItem, IListData, ILibFile, INewsItem, IRequestItem, IResourceItem, IWinItem, ListKey } from './data/types';

export interface IModal {
  id: number;
  title: string;
  body: React.ReactNode;
  wide?: boolean;
}

export interface IToast {
  id: number;
  text: string;
  error: boolean;
}

export interface IStore {
  data: IListData;
  status: 'loading' | 'ready';
  persistent: boolean;
  /** Files in the SH_Documents library (empty when files are not supported). */
  files: ILibFile[];
  supportsFiles: boolean;
  libraryUrl: string;
  notice: string;
  /** True when the Pricing page is limited to a SharePoint group and the signed-in user is not in it. */
  pricingLocked: boolean;
  firstName: string;
  userName: string;
  add(key: ListKey, values: FieldValues, success?: string): Promise<boolean>;
  update(key: ListKey, id: number, values: FieldValues, success?: string): Promise<boolean>;
  remove(key: ListKey, id: number, success?: string): Promise<boolean>;
  /** Uploads a file to the library; throws with a readable message when it fails. */
  uploadFile(file: File, section: string, group: string): Promise<ILibFile>;
  renameFile(id: number, newName: string): Promise<void>;
  /** Moves a library file to the Recycle Bin and reloads. */
  removeFile(id: number): Promise<boolean>;
  /** Moves a file the hub uploaded to the Recycle Bin when no other row still uses it. */
  releaseFile(fileId: number, exceptRowId?: number): Promise<void>;
  /** Uploads straight to the library without attaching it to a row. */
  addToLibrary(file: File): Promise<boolean>;
  toast(text: string, error?: boolean): void;
  openModal(title: string, body: React.ReactNode, options?: { wide?: boolean; replace?: boolean }): void;
  closeModal(): void;
  navigate(page: PageKey, anchor?: string): void;
  /** Opens a link: "page:key#anchor" moves inside the hub, anything else opens in a new tab. */
  openLink(link: string): boolean;
}

const Ctx: React.Context<IStore | undefined> = React.createContext<IStore | undefined>(undefined);

export const useStore = (): IStore => {
  const s: IStore | undefined = React.useContext(Ctx);
  if (!s) {
    throw new Error('StoreProvider is missing');
  }
  return s;
};

const EMPTY: IListData = { events: [], news: [], wins: [], resources: [], accounts: [], requests: [] };
const KEYS: ListKey[] = ['events', 'news', 'wins', 'resources', 'accounts', 'requests'];

export interface IStoreProviderProps {
  service: IDataService;
  /** Used when the SharePoint lists cannot be created, so the hub still works for this visit. */
  fallback: IDataService;
  firstName: string;
  userName: string;
  /** SharePoint group allowed to open Pricing; empty means everyone. */
  pricingGroup?: string;
  navigate(page: PageKey, anchor?: string): void;
  children?: React.ReactNode;
}

export const StoreProvider: React.FC<IStoreProviderProps> = (props) => {
  const [data, setData] = React.useState<IListData>(EMPTY);
  const [files, setFiles] = React.useState<ILibFile[]>([]);
  const dataRef: React.MutableRefObject<IListData> = React.useRef<IListData>(EMPTY);
  const filesRef: React.MutableRefObject<ILibFile[]> = React.useRef<ILibFile[]>([]);
  const [status, setStatus] = React.useState<'loading' | 'ready'>('loading');
  const [notice, setNotice] = React.useState<string>('');
  const [pricingLocked, setPricingLocked] = React.useState<boolean>(!!props.pricingGroup);
  const [service, setService] = React.useState<IDataService>(props.service);
  const [modals, setModals] = React.useState<IModal[]>([]);
  const [toasts, setToasts] = React.useState<IToast[]>([]);
  const seq: React.MutableRefObject<number> = React.useRef<number>(1);

  const loadAll = React.useCallback(async (svc: IDataService): Promise<void> => {
    const [results, libFiles]: [IItem[][], ILibFile[]] = await Promise.all([
      Promise.all(KEYS.map((k: ListKey) => svc.getAll(k))),
      svc.supportsFiles
        ? svc.listFiles().catch((e: Error) => { setNotice(`The document library could not be read (${e.message}). Documents with uploaded files will not open until this is fixed.`); return [] as ILibFile[]; })
        : Promise.resolve([] as ILibFile[])
    ]);
    const next: { [key: string]: IItem[] } = {};
    KEYS.forEach((k: ListKey, i: number) => { next[k] = results[i]; });
    // A row with an attached file always follows that file, so renames and moves in SharePoint keep the link working.
    next.resources = (next.resources as IResourceItem[]).filter((r: IResourceItem) => r.Section !== 'meta').map((r: IResourceItem) => {
      const fid: number = Number(r.FileId) || 0;
      if (!fid) {
        return { ...r, FileId: 0, FileName: r.FileName || '' };
      }
      const f: ILibFile | undefined = libFiles.filter((x: ILibFile) => x.Id === fid)[0];
      return f ? { ...r, FileId: fid, Link: f.Url, FileName: f.Name, FileMissing: false } : { ...r, FileId: fid, Link: '', FileMissing: true };
    });
    dataRef.current = next as unknown as IListData;
    filesRef.current = libFiles;
    setFiles(libFiles);
    setData(next as unknown as IListData);
  }, []);

  // Keep the page in step with SharePoint: a light check every few seconds (and when the tab comes back) reloads quietly only if something changed.
  React.useEffect(() => {
    if (status !== 'ready' || !service.stamp) {
      return undefined;
    }
    let alive: boolean = true;
    const sync: { busy: boolean; last?: string } = { busy: false };
    const check = async (): Promise<void> => {
      if (!alive || sync.busy || document.hidden) {
        return;
      }
      sync.busy = true;
      try {
        const now: string = await service.stamp!();
        if (now && sync.last !== undefined && now !== sync.last) {
          await loadAll(service);
        }
        if (now) {
          // eslint-disable-next-line require-atomic-updates -- one check runs at a time (guarded by sync.busy)
          sync.last = now;
        }
      } catch {
        // A failed check is simply tried again on the next beat.
      } finally {
        // eslint-disable-next-line require-atomic-updates -- one check runs at a time (guarded by sync.busy)
        sync.busy = false;
      }
    };
    const onShow = (): void => { check().catch(() => undefined); };
    const timer: number = window.setInterval(() => { check().catch(() => undefined); }, 4000);
    document.addEventListener('visibilitychange', onShow);
    window.addEventListener('focus', onShow);
    check().catch(() => undefined);
    return (): void => {
      alive = false;
      window.clearInterval(timer);
      document.removeEventListener('visibilitychange', onShow);
      window.removeEventListener('focus', onShow);
    };
  }, [status, service, loadAll]);

  React.useEffect(() => {
    let alive: boolean = true;
    const start = async (): Promise<void> => {
      let active: IDataService = props.service;
      try {
        await active.init();
        await loadAll(active);
        if (alive && active.warnings && active.warnings.length) {
          setNotice(active.warnings.join(' '));
        }
      } catch (e) {
        active = props.fallback;
        await active.init();
        await loadAll(active);
        if (alive) {
          setNotice(`The SharePoint lists could not be opened (${e instanceof Error ? e.message : 'unknown error'}). Changes are kept in this browser only until a site owner opens the hub once.`);
        }
      }
      if (props.pricingGroup && active.isMemberOf) {
        const allowed: boolean = await active.isMemberOf(props.pricingGroup).catch(() => false);
        if (alive) { setPricingLocked(!allowed); }
      } else if (alive) {
        setPricingLocked(false);
      }
      if (alive) {
        setService(active);
        setStatus('ready');
      }
    };
    start().catch(() => { if (alive) { setStatus('ready'); } });
    return () => { alive = false; };
  }, [props.service, props.fallback, props.pricingGroup, loadAll]);

  const toast = React.useCallback((text: string, error: boolean = false): void => {
    const id: number = seq.current++;
    setToasts((t: IToast[]) => t.concat([{ id, text, error }]));
    window.setTimeout(() => setToasts((t: IToast[]) => t.filter((x: IToast) => x.id !== id)), error ? 6000 : 3200);
  }, []);

  const run = React.useCallback(async (job: () => Promise<void>, success?: string): Promise<boolean> => {
    try {
      await job();
      await loadAll(service);
      if (success) {
        toast(success);
      }
      return true;
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Something went wrong. Please try again.', true);
      return false;
    }
  }, [service, loadAll, toast]);

  const add = React.useCallback((key: ListKey, values: FieldValues, success?: string): Promise<boolean> => run(() => service.add(key, values), success), [run, service]);
  const update = React.useCallback((key: ListKey, id: number, values: FieldValues, success?: string): Promise<boolean> => run(() => service.update(key, id, values), success), [run, service]);
  const remove = React.useCallback((key: ListKey, id: number, success?: string): Promise<boolean> => run(() => service.remove(key, id), success), [run, service]);

  const uploadFile = React.useCallback((file: File, section: string, group: string): Promise<ILibFile> => service.uploadFile(file, section, group), [service]);
  const renameFile = React.useCallback(async (id: number, newName: string): Promise<void> => { await service.renameFile(id, newName); await loadAll(service); }, [service, loadAll]);
  const removeFile = React.useCallback((id: number): Promise<boolean> => run(() => service.deleteFile(id), 'File moved to the Recycle Bin'), [run, service]);

  const releaseFile = React.useCallback(async (fileId: number, exceptRowId?: number): Promise<void> => {
    const f: ILibFile | undefined = filesRef.current.filter((x: ILibFile) => x.Id === fileId)[0];
    // Only files the hub uploaded are removed, and only when no other row uses them. They go to the Recycle Bin.
    if (!fileId || !f || !f.Section) {
      return;
    }
    const used: boolean = dataRef.current.resources.some((r: IResourceItem) => r.FileId === fileId && r.Id !== exceptRowId);
    if (!used) {
      try {
        await service.deleteFile(fileId);
        await loadAll(service);
      } catch {
        // The row is already saved; a leftover file can be removed from the library by hand.
      }
    }
  }, [service, loadAll]);

  const addToLibrary = React.useCallback(async (file: File): Promise<boolean> => {
    try {
      await service.uploadFile(file, '', '');
      await loadAll(service);
      toast('File uploaded to the library');
      return true;
    } catch (e) {
      toast(e instanceof Error ? e.message : 'The upload failed. Please try again.', true);
      return false;
    }
  }, [service, loadAll, toast]);

  const openModal = React.useCallback((title: string, body: React.ReactNode, options?: { wide?: boolean; replace?: boolean }): void => {
    const m: IModal = { id: seq.current++, title, body, wide: options && options.wide };
    setModals((list: IModal[]) => (options && options.replace ? list.slice(0, -1) : list).concat([m]));
  }, []);
  const closeModal = React.useCallback((): void => setModals((list: IModal[]) => list.slice(0, -1)), []);

  const { navigate } = props;
  const openLink = React.useCallback((link: string): boolean => {
    const l: string = (link || '').trim();
    if (!l) {
      return false;
    }
    if (l.indexOf('page:') === 0) {
      const [key, anchor] = l.slice(5).split('#');
      setModals([]);
      navigate(key as PageKey, anchor);
      return true;
    }
    if (/^(https?:\/\/|\/|mailto:)/i.test(l)) {
      window.open(l, l.indexOf('mailto:') === 0 ? '_self' : '_blank', 'noopener,noreferrer');
      return true;
    }
    toast('That link is not valid. Use a full web address starting with https://', true);
    return false;
  }, [navigate, toast]);

  const goTo = React.useCallback((page: PageKey, anchor?: string): void => {
    setModals([]);
    navigate(page, anchor);
  }, [navigate]);

  const store: IStore = {
    data, files, supportsFiles: service.supportsFiles, libraryUrl: service.libraryUrl, uploadFile, renameFile, removeFile, releaseFile, addToLibrary,
    status, persistent: service.persistent, notice, pricingLocked, firstName: props.firstName, userName: props.userName,
    add, update, remove, toast, openModal, closeModal, navigate: goTo, openLink
  };

  const top: IModal | undefined = modals[modals.length - 1];
  React.useEffect(() => {
    if (!top) {
      return undefined;
    }
    const onKey = (e: KeyboardEvent): void => { if (e.key === 'Escape') { closeModal(); } };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [top, closeModal]);

  return (
    <Ctx.Provider value={store}>
      {props.children}
      {createPortal(
        <div className={c('mdlRoot')}>
          {top && (
            <div className={c('mdlBack')} onMouseDown={(e: React.MouseEvent<HTMLDivElement>) => { if (e.target === e.currentTarget) { closeModal(); } }}>
              <div className={c(top.wide ? 'mdl wide' : 'mdl')} role="dialog" aria-modal="true" aria-label={top.title}>
                <div className={c('mdlHead')}>
                  <h3>{top.title}</h3>
                  <button type="button" className={c('iconBtn')} aria-label="Close" onClick={closeModal}><Icon n="x" s={20} sw={2} /></button>
                </div>
                <div className={c('mdlBody')}>{top.body}</div>
              </div>
            </div>
          )}
          <div className={c('toasts')} aria-live="polite">
            {toasts.map((t: IToast) => <div key={t.id} className={c(t.error ? 'toast err' : 'toast')}>{t.text}</div>)}
          </div>
        </div>,
        document.body
      )}
    </Ctx.Provider>
  );
};

/** Sorted rows of one document group. */
export const useGroup = (section: string, group: string): IResourceItem[] => {
  const { data } = useStore();
  return data.resources
    .filter((r: IResourceItem) => r.Section === section && r.Group === group)
    .sort((a: IResourceItem, b: IResourceItem) => (a.SortOrder - b.SortOrder) || (a.Id - b.Id));
};

/** Options for a drop-down, read from the Choices rows; falls back to the built-in list when none exist. */
export const useChoices = (group: string, fallback: string[]): string[] => {
  const items: IResourceItem[] = useGroup('choices', group);
  return items.length ? items.map((r: IResourceItem) => r.Title) : fallback;
};

export type { IAccountItem, IEventItem, INewsItem, IRequestItem, IWinItem };
