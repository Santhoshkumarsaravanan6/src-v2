export type PageKey =
  | 'home'
  | 'capabilities'
  | 'innovation'
  | 'pricing'
  | 'regulatory'
  | 'marketing-assets'
  | 'events'
  | 'sales-playbook'
  | 'accounts'
  | 'company-documents';

export interface INavChild {
  label: string;
  /** Section of the page to scroll to. */
  anchor: string;
}

export interface INavItem {
  key: PageKey;
  label: string;
  /** Dropdown entries shown under the item. */
  children?: INavChild[];
}

export const NAV: INavItem[] = [
  { key: 'home', label: 'Home' },
  {
    key: 'capabilities', label: 'Capabilities',
    children: [{ label: 'Facilities', anchor: 'facilities' }, { label: 'Product categories', anchor: 'categories' }, { label: 'Certifications & audits', anchor: 'certs' }, { label: 'Case studies', anchor: 'cases' }]
  },
  {
    key: 'innovation', label: 'Innovation',
    children: [{ label: 'New formulas', anchor: 'formulas' }, { label: 'Trend reports', anchor: 'trends' }, { label: 'Presentations', anchor: 'decks' }, { label: 'Ingredient & claims library', anchor: 'library' }]
  },
  { key: 'pricing', label: 'Pricing' },
  {
    key: 'regulatory', label: 'Regulatory',
    children: [{ label: 'Clean standards', anchor: 'clean' }, { label: 'Restricted substances', anchor: 'rsl' }, { label: 'OTC / FDA & MoCRA', anchor: 'mocra' }, { label: 'Questionnaire templates', anchor: 'quest' }]
  },
  {
    key: 'marketing-assets', label: 'Marketing Assets',
    children: [{ label: 'Decks & one-pagers', anchor: 'decks' }, { label: 'Logos & brand', anchor: 'brand' }, { label: 'Photos & videos', anchor: 'gallery' }, { label: 'Trade show materials', anchor: 'trade' }]
  },
  { key: 'events', label: 'Events' },
  { key: 'sales-playbook', label: 'Sales Playbook' },
  { key: 'accounts', label: 'Accounts' },
  { key: 'company-documents', label: 'Company Documents' }
];
