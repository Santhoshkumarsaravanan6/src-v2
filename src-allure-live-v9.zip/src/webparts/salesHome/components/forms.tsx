import * as React from 'react';

import { c } from './ui';
import { useStore } from './store';

export interface IFieldCfg {
  name: string;
  label: string;
  type?: 'text' | 'textarea' | 'date' | 'select' | 'number' | 'file';
  options?: Array<string | { value: string; label: string }>;
  required?: boolean;
  placeholder?: string;
  /** Small helper text under the field. */
  hint?: string;
  /** For file fields: accepted types, for example image/*. */
  accept?: string;
}

export type FormValues = { [name: string]: string };
export type FormFiles = { [name: string]: File | undefined };

export interface IFormProps {
  fields: IFieldCfg[];
  initial?: FormValues;
  submitLabel?: string;
  /** Return true when the data was saved. */
  onSubmit(values: FormValues, files: FormFiles): Promise<boolean>;
  onDelete?(): Promise<boolean>;
  /** Inline forms stay on the page and clear after saving; dialog forms close. */
  inline?: boolean;
  /** Extra text shown above the buttons. */
  footnote?: string;
}

let uid: number = 0;

export const Form: React.FC<IFormProps> = (props) => {
  const { closeModal } = useStore();
  const [values, setValues] = React.useState<FormValues>(() => {
    const v: FormValues = {};
    props.fields.forEach((f: IFieldCfg) => { v[f.name] = (props.initial && props.initial[f.name]) || ''; });
    return v;
  });
  const [errors, setErrors] = React.useState<FormValues>({});
  const [files, setFiles] = React.useState<FormFiles>({});
  const [busy, setBusy] = React.useState<boolean>(false);
  const [confirm, setConfirm] = React.useState<boolean>(false);
  const prefix: React.MutableRefObject<string> = React.useRef<string>('f' + (uid++));

  const set = (name: string, value: string): void => {
    setValues((v: FormValues) => ({ ...v, [name]: value }));
    setErrors((e: FormValues) => ({ ...e, [name]: '' }));
  };

  const submit = async (e: React.FormEvent): Promise<void> => {
    e.preventDefault();
    const errs: FormValues = {};
    props.fields.forEach((f: IFieldCfg) => {
      if (f.required && f.type !== 'file' && !values[f.name].trim()) {
        errs[f.name] = `${f.label} is required`;
      }
    });
    setErrors(errs);
    if (Object.keys(errs).some((k: string) => !!errs[k])) {
      return;
    }
    setBusy(true);
    const ok: boolean = await props.onSubmit(values, files);
    setBusy(false);
    if (ok) {
      if (props.inline) {
        setValues(() => {
          const v: FormValues = {};
          props.fields.forEach((f: IFieldCfg) => { v[f.name] = ''; });
          return v;
        });
        setFiles({});
      } else {
        closeModal();
      }
    }
  };

  const del = async (): Promise<void> => {
    if (!props.onDelete) {
      return;
    }
    if (!confirm) {
      setConfirm(true);
      return;
    }
    setBusy(true);
    const ok: boolean = await props.onDelete();
    setBusy(false);
    if (ok) {
      closeModal();
    }
  };

  return (
    <form className={c('form')} onSubmit={(e: React.FormEvent) => { submit(e).catch(() => undefined); }} noValidate>
      {props.fields.map((f: IFieldCfg) => {
        const id: string = `${prefix.current}-${f.name}`;
        const common = { id, value: values[f.name], 'aria-invalid': !!errors[f.name] };
        return (
          <div key={f.name} className={c('fld')}>
            <label htmlFor={id}>{f.label}{f.required ? ' *' : ''}</label>
            {f.type === 'textarea' ? (
              <textarea {...common} rows={3} placeholder={f.placeholder} onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => set(f.name, e.target.value)} />
            ) : f.type === 'select' ? (
              <select {...common} onChange={(e: React.ChangeEvent<HTMLSelectElement>) => set(f.name, e.target.value)}>
                <option value="">{f.placeholder || 'Select'}</option>
                {(f.options || []).map((o: string | { value: string; label: string }) => {
                  const v: string = typeof o === 'string' ? o : o.value;
                  return <option key={v} value={v}>{typeof o === 'string' ? o : o.label}</option>;
                })}
              </select>
            ) : f.type === 'file' ? (
              <input id={id} type="file" accept={f.accept} aria-invalid={!!errors[f.name]}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => { const file: File | undefined = e.target.files ? e.target.files[0] : undefined; setFiles((x: FormFiles) => ({ ...x, [f.name]: file })); }} />
            ) : (
              <input {...common} type={f.type === 'date' ? 'date' : f.type === 'number' ? 'number' : 'text'} placeholder={f.placeholder}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => set(f.name, e.target.value)} />
            )}
            {f.hint && <span className={c('hint')}>{f.hint}</span>}
            {errors[f.name] && <span className={c('err')} role="alert">{errors[f.name]}</span>}
          </div>
        );
      })}
      {props.footnote && <p className={c('footnote')}>{props.footnote}</p>}
      <div className={c('formBtns')}>
        {props.onDelete && (
          <button type="button" className={c('btn danger')} disabled={busy} onClick={() => { del().catch(() => undefined); }}>
            {confirm ? 'Click again to delete' : 'Delete'}
          </button>
        )}
        <span className={c('grow')} />
        {!props.inline && <button type="button" className={c('btn line')} disabled={busy} onClick={closeModal}>Cancel</button>}
        <button type="submit" className={c('btn')} disabled={busy}>{busy ? 'Saving…' : props.submitLabel || 'Save'}</button>
      </div>
    </form>
  );
};
