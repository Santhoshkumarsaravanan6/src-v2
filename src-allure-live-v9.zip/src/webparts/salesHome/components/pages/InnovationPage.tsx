import * as React from 'react';

import { c } from '../ui';
import { useStore } from '../store';
import { Hero, ResCard, ResTable, Row, SectionHead, Tiles } from '../blocks';
import { Concepts } from '../live';
import { CFG } from '../cfg';

const TABS: Array<{ label: string; anchor: string }> = [
  { label: 'New Formulas', anchor: 'formulas' }, { label: 'Trend Reports', anchor: 'trends' }, { label: 'Presentations', anchor: 'decks' }, { label: 'Ingredient & Claims Library', anchor: 'library' }
];

const InnovationPage: React.FC = () => {
  const s = useStore();
  const [tab, setTab] = React.useState<string>('formulas');
  const go = (anchor: string): (() => void) => (): void => { setTab(anchor); s.navigate('innovation', anchor); };
  return (
    <>
      <Hero crumb="Innovation" title="Innovation" sub="Launch-ready concepts, trend intelligence and a searchable ingredient and claims library."
        btn={{ label: 'Browse launch-ready concepts', onClick: go('formulas') }}
        facts={[
          { icon: 'flask', title: 'New Formulas', sub: 'Launch-ready concepts', onClick: go('formulas') },
          { icon: 'trend', title: 'Trend Reports', sub: 'Quarterly insights', onClick: go('trends') }
        ]} />
      <Tiles sq items={[
        { icon: 'flask', title: 'New Formulas', desc: 'Launch-ready concepts', onClick: go('formulas') },
        { icon: 'trend', title: 'Trend Reports', desc: 'Market & consumer trends', onClick: go('trends') },
        { icon: 'bulb', title: 'Innovation Presentations', desc: 'Customer-ready decks', onClick: go('decks') },
        { icon: 'list', title: 'Ingredient & Claims Library', desc: 'Functions, claims & support', onClick: go('library') }
      ]} />
      <div className={c('tabs')}>
        {TABS.map((t: { label: string; anchor: string }) => (
          <button key={t.anchor} type="button" className={c(tab === t.anchor ? 'tabBtn on' : 'tabBtn')} onClick={go(t.anchor)}>{t.label}</button>
        ))}
      </div>
      <SectionHead title="New Formulas & Launch-Ready Concepts" sub="Ready to sample or customize" />
      <Concepts cfg={CFG.concepts} />
      <Row cols="1fr 1fr">
        <ResCard cfg={CFG.trends} />
        <ResCard cfg={CFG.innDecks} />
      </Row>
      <Row cols="1fr">
        <ResTable cfg={CFG.library} cols={[{ head: 'Ingredient', field: 'Title' }, { head: 'Function', field: 'Sub' }, { head: 'Claims supported', field: 'Extra' }, { head: 'Clean status', field: 'Tag' }]} />
      </Row>
    </>
  );
};

export default InnovationPage;
