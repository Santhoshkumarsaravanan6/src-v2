import * as React from 'react';

import { useStore } from '../store';
import { Hero, ResCard, Row, Tiles, type IFact } from '../blocks';
import { CalendarCard, EventsCard, LeadsCard, useEventActions } from '../live';
import { todayKey } from '../data/dates';
import type { IEventItem } from '../data/types';
import { CFG } from '../cfg';

const EventsPage: React.FC = () => {
  const s = useStore();
  const act = useEventActions();
  const go = (anchor: string): (() => void) => (): void => s.navigate('events', anchor);
  const today: string = todayKey();
  const next: IEventItem[] = s.data.events.filter((e: IEventItem) => e.EventDate >= today).sort((a: IEventItem, b: IEventItem) => (a.EventDate < b.EventDate ? -1 : 1)).slice(0, 2);
  const facts: IFact[] = next.length
    ? next.map((e: IEventItem): IFact => ({ icon: 'cal', title: e.Title, sub: [e.Location, e.EventDate].filter((x: string) => !!x).join(' · '), onClick: () => act.detail(e) }))
    : [{ icon: 'cal', title: 'No upcoming events', sub: 'Select to add the first one', onClick: () => act.addNew() }];
  return (
    <>
      <Hero crumb="Events" title="Events" sub="Trade show calendar, playbooks, lead capture and event recaps, all in one place."
        btn={{ label: 'View full calendar', onClick: go('calendar') }} facts={facts} />
      <Tiles sq items={[
        { icon: 'cal', title: 'Trade Show Calendar', desc: 'Upcoming & past shows', onClick: go('calendar') },
        { icon: 'check', title: 'Playbooks & Checklists', desc: 'Before, during & after', onClick: go('playbooks') },
        { icon: 'users', title: 'Lead Capture & Follow-Up', desc: 'Capture & assign leads', onClick: go('leads') },
        { icon: 'book', title: 'Event Recaps', desc: 'Results & learnings', onClick: go('recaps') }
      ]} />
      <Row cols="1fr 1.35fr">
        <CalendarCard title="Trade Show Calendar" anchor="calendar" />
        <EventsCard anchor="upcoming" />
      </Row>
      <Row cols="1fr 1.2fr">
        <ResCard cfg={CFG.playbooks} />
        <LeadsCard />
      </Row>
      <Row cols="1fr">
        <ResCard cfg={CFG.recaps} />
      </Row>
    </>
  );
};

export default EventsPage;
