import * as React from 'react';

import { useStore } from '../store';
import { Hero, ResCard, ResTable, Row, Tiles } from '../blocks';
import { CFG } from '../cfg';

const RegulatoryPage: React.FC = () => {
  const s = useStore();
  const go = (anchor: string): (() => void) => (): void => s.navigate('regulatory', anchor);
  return (
    <>
      <Hero crumb="Regulatory" title="Regulatory" sub="Clean standards, restricted substances, OTC/FDA and MoCRA guidance, and customer questionnaire templates."
        btn={{ label: 'View clean standards', onClick: go('clean') }}
        facts={[
          { icon: 'shieldc', title: 'Clean Standards', sub: 'Credo & Sephora', onClick: go('clean') },
          { icon: 'file', title: 'MoCRA & FDA', sub: 'Guidance & updates', onClick: go('mocra') }
        ]} />
      <Tiles sq items={[
        { icon: 'shieldc', title: 'Clean Standards', desc: 'Credo, Sephora & retailer lists', onClick: go('clean') },
        { icon: 'shield', title: 'Restricted Substances', desc: 'RSL by market & retailer', onClick: go('rsl') },
        { icon: 'file', title: 'OTC / FDA & MoCRA', desc: 'Guidance & checklists', onClick: go('mocra') },
        { icon: 'clip', title: 'Questionnaire Templates', desc: 'Customer compliance forms', onClick: go('quest') }
      ]} />
      <Row cols="1fr 1fr">
        <ResTable cfg={CFG.clean} cols={[{ head: 'Standard', field: 'Title' }, { head: 'Scope', field: 'Sub' }, { head: 'Last reviewed', field: 'Extra' }, { head: '', field: 'link' }]} />
        <ResCard cfg={CFG.rsl} />
      </Row>
      <Row cols="1fr 1fr">
        <ResCard cfg={CFG.mocra} />
        <ResCard cfg={CFG.quest} />
      </Row>
    </>
  );
};

export default RegulatoryPage;
