import * as React from 'react';

import { useStore } from '../store';
import { Hero, ResCard, Row, Tiles } from '../blocks';
import { OrgChart } from '../live';
import { LibraryCard } from '../library';
import { CFG } from '../cfg';

const DocumentsPage: React.FC = () => {
  const s = useStore();
  const go = (anchor: string): (() => void) => (): void => s.navigate('company-documents', anchor);
  return (
    <>
      <Hero crumb="Company Documents" title="Company Documents" sub="Org chart, key contacts, contract templates, vendor forms and company policies."
        btn={{ label: 'Browse documents', onClick: go('contracts') }}
        facts={[
          { icon: 'file', title: 'Contracts', sub: 'NDA & MSA templates', onClick: go('contracts') },
          { icon: 'clip', title: 'Vendor Forms', sub: 'W-9 & COI', onClick: go('vendor') }
        ]} />
      <Tiles sq items={[
        { icon: 'org', title: 'Org Chart & Contacts', desc: 'Who to call', onClick: go('org') },
        { icon: 'file', title: 'NDA / MSA Templates', desc: 'Contract templates', onClick: go('contracts') },
        { icon: 'clip', title: 'W-9, COI & Vendor Forms', desc: 'Onboarding forms', onClick: go('vendor') },
        { icon: 'book', title: 'Policies', desc: 'Company policies', onClick: go('policies') },
        { icon: 'dl', title: 'Document Library', desc: 'All uploaded files', onClick: go('library') }
      ]} />
      <Row cols="1fr">
        <OrgChart cfg={CFG.org} />
      </Row>
      <Row cols="1fr 1fr 1fr">
        <ResCard cfg={CFG.contracts} />
        <ResCard cfg={CFG.vendor} />
        <ResCard cfg={CFG.policies} />
      </Row>
      <Row cols="1fr">
        <LibraryCard />
      </Row>
    </>
  );
};

export default DocumentsPage;
