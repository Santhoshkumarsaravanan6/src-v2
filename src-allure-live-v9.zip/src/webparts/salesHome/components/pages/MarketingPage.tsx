import * as React from 'react';

import { c, Icon } from '../ui';
import { img } from '../images';
import { useGroup, useStore } from '../store';
import { Card, Empty, GroupPanel, Hero, LinkBtn, ResCard, Row, SectionHead, Tiles, useResourceActions } from '../blocks';
import type { IResourceItem } from '../data/types';
import { CFG } from '../cfg';

/** Dark text on light colours and white text on dark ones. */
const textOn = (hex: string): string => {
  const m: RegExpExecArray | null = /^#?([0-9a-f]{6})$/i.exec(hex.trim());
  if (!m) { return '#0a3f52'; }
  const n: number = parseInt(m[1], 16);
  return (0.299 * (n >> 16) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255)) > 150 ? '#0a3f52' : '#fff';
};
const validHex = (hex: string): boolean => /^#?[0-9a-f]{6}$/i.test(hex.trim());

const MarketingPage: React.FC = () => {
  const s = useStore();
  const go = (anchor: string): (() => void) => (): void => s.navigate('marketing-assets', anchor);
  const brand = (): void => s.openModal(CFG.brandFiles.title, <GroupPanel cfg={CFG.brandFiles} />, { wide: true });
  const photos: IResourceItem[] = useGroup('marketing-assets', 'Photos and videos');
  const colours: IResourceItem[] = useGroup('marketing-assets', 'Brand colours');
  const photoAct = useResourceActions(CFG.gallery);
  const colourAct = useResourceActions(CFG.brandColors);
  const look = (name: string, src: string): void => s.openModal(name, <img src={src} alt={name} className={c('lightbox')} />, { wide: true });
  return (
    <>
      <Hero crumb="Marketing Assets" title="Marketing Assets" sub="Approved decks, brand guidelines, photos, videos and trade show materials, always current."
        btn={{ label: 'Download brand kit', icon: 'dl', onClick: brand }}
        facts={[
          { icon: 'image', title: 'Brand Assets', sub: 'Logos & guidelines', onClick: go('brand') },
          { icon: 'video', title: 'Photos & Videos', sub: 'Approved library', onClick: go('gallery') }
        ]} />
      <Tiles sq items={[
        { icon: 'file', title: 'Decks & One-Pagers', desc: 'Capabilities presentations', onClick: go('decks') },
        { icon: 'sparkle', title: 'Logos & Brand Guidelines', desc: 'Logo files & usage rules', onClick: go('brand') },
        { icon: 'image', title: 'Photos & Videos', desc: 'Facility & product media', onClick: go('gallery') },
        { icon: 'cal', title: 'Trade Show Materials', desc: 'Booth & print assets', onClick: go('trade') }
      ]} />
      <SectionHead title="Photos & Videos" sub="Approved for customer use. Select a photo to enlarge it." anchor="gallery" />
      <div className={c('panelBar')}><LinkBtn label="Add photo" icon="plus" strong onClick={photoAct.addNew} /></div>
      {!photos.length ? <Empty text="No photos yet. Use Add photo to upload the first one." /> : (
        <div className={c('gal')}>
          {photos.map((p: IResourceItem) => {
            const src: string = p.Link || img[p.Tag] || '';
            return (
              <div key={p.Id} className={c('shotWrap')}>
                <button type="button" className={c('shot')} onClick={() => (src ? look(p.Title, src) : photoAct.edit(p))}>
                  {src ? <img className={c(p.Tag.indexOf('fac') === 0 ? '' : 'ct')} src={src} alt={p.Title} /> : <Icon n="image" s={40} sw={1.4} />}<span>{p.Title}</span>
                </button>
                <button type="button" className={c('iconBtn sm ed')} aria-label={`Edit ${p.Title}`} onClick={() => photoAct.edit(p)}><Icon n="edit" s={16} sw={1.8} /></button>
              </div>
            );
          })}
        </div>
      )}
      <Row cols="1.3fr 1fr">
        <ResCard cfg={CFG.mktDecks} />
        <Card title="Logos & Brand Guidelines" icon="sparkle" anchor="brand">
          <img src={img.logo} alt="Allure Beauty Concepts" style={{ height: 54, width: 'auto', margin: '2px 0 16px' }} />
          <div style={{ fontSize: 13, color: '#5b6b73', marginBottom: 8 }}>Brand colors</div>
          <div className={c('sw')}>
            {colours.map((w: IResourceItem) => {
              const hex: string = w.Sub.trim().toUpperCase();
              return (
                <button key={w.Id} type="button" className={c('swb')} style={{ background: validHex(hex) ? (hex.charAt(0) === '#' ? hex : `#${hex}`) : '#e9f5f8', color: textOn(hex) }}
                  onClick={() => { navigator.clipboard?.writeText(hex).catch(() => undefined); s.toast(`Copied ${hex}`); }}>{w.Title.toUpperCase()} {hex}</button>
              );
            })}
          </div>
          <div style={{ display: 'flex', gap: 10, marginTop: 14, flexWrap: 'wrap' }}>
            <button type="button" className={c('btn line')} style={{ margin: 0 }} onClick={brand}>Logo pack and brand files</button>
            <button type="button" className={c('btn line')} style={{ margin: 0 }} onClick={colourAct.viewAll}>Edit colours</button>
          </div>
        </Card>
      </Row>
      <Row cols="1fr">
        <ResCard cfg={CFG.trade} />
      </Row>
    </>
  );
};

export default MarketingPage;
