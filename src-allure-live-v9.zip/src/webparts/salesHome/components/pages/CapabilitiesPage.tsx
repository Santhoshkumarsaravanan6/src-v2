import * as React from 'react';

import { c, Icon } from '../ui';
import { useStore } from '../store';
import { Card, GroupPanel, Hero, ResCard, ResTable, Row, Tiles, useResourceActions, type IResCfg } from '../blocks';
import { Stats } from '../live';
import { CFG } from '../cfg';
import { facilityAnchor, facilityLines, facilityPic, useFacilities } from '../facilities';
import type { IResourceItem } from '../data/types';

const CapabilitiesPage: React.FC = () => {
  const s = useStore();
  const group = (cfg: IResCfg): (() => void) => (): void => s.openModal(cfg.title, <GroupPanel cfg={cfg} />, { wide: true });
  const facilities: IResourceItem[] = useFacilities();
  const facAct = useResourceActions(CFG.facilities);
  const statsFor = (f: IResourceItem): IResCfg | undefined => (f.Tag === 'hayward' ? CFG.capHayStats : f.Tag === 'scottsdale' ? CFG.capScotStats : undefined);
  const facility = (f: IResourceItem): React.ReactNode => {
    const stats: IResCfg | undefined = statsFor(f);
    return (
      <Card key={f.Id} title={`${f.Title} Facility`} icon="factory" anchor={facilityAnchor(f)}
        actions={<button type="button" className={c('iconBtn sm ed')} aria-label={`Edit ${f.Title}`} onClick={() => facAct.edit(f)}><Icon n="edit" s={16} sw={1.8} /></button>}>
        <div className={c('fac2')}>
          <img src={facilityPic(f)} alt="" />
          <ul>{facilityLines(f).map((p: string) => <li key={p}>{p}</li>)}</ul>
        </div>
        {stats && <Stats cfg={stats} />}
        <button type="button" className={c('btn')} style={{ marginTop: 2 }} onClick={group(CFG.capProfiles)}>Download facility profile <Icon n="dl" s={17} sw={2} /></button>
      </Card>
    );
  };
  return (
    <>
      <Hero crumb="Capabilities" title="Capabilities" sub="Facility profiles, category capabilities, certifications and the case studies that prove them."
        btn={{ label: 'Download capabilities deck', icon: 'dl', onClick: group(CFG.capDecks) }}
        facts={facilities.slice(0, 2).map((f: IResourceItem) => ({ icon: 'factory', title: f.Title, sub: f.Sub, onClick: () => s.navigate('capabilities', facilityAnchor(f)) }))} />
      <Tiles sq anchor="categories" items={[
        { icon: 'drop', title: 'Skincare', desc: 'Creams, serums, lotions & cleansers', onClick: group(CFG.catSkin) },
        { icon: 'wind', title: 'Haircare', desc: 'Shampoo, conditioner & treatments', onClick: group(CFG.catHair) },
        { icon: 'palette', title: 'Color Cosmetics', desc: 'Face, lip & eye products', onClick: group(CFG.catColor) },
        { icon: 'shieldc', title: 'OTC', desc: 'SPF, acne & drug-regulated products', onClick: group(CFG.catOtc) }
      ]} />
      <Row cols={facilities.length > 1 ? '1fr 1fr' : '1fr'} anchor="facilities">
        {facilities.map((f: IResourceItem) => facility(f))}
      </Row>
      <Row cols="1.35fr 1fr">
        <ResTable cfg={CFG.capCerts} cols={[{ head: 'Certification / audit', field: 'Title' }, { head: 'Facility', field: 'Sub' }, { head: 'Status', field: 'Tag' }, { head: 'Updated', field: 'Extra' }]} />
        <ResCard cfg={CFG.capCases} />
      </Row>
    </>
  );
};

export default CapabilitiesPage;
