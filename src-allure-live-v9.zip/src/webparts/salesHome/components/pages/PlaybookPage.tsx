import * as React from 'react';

import { useStore } from '../store';
import { Hero, ResCard, Row, Tiles } from '../blocks';
import { Onboarding } from '../live';
import { StepsCard } from '../steps';
import { CFG } from '../cfg';

const PlaybookPage: React.FC = () => {
  const s = useStore();
  const go = (anchor: string): (() => void) => (): void => s.navigate('sales-playbook', anchor);
  return (
    <>
      <Hero crumb="Sales Playbook" title="Sales Playbook" sub="The sales process, qualification, battle cards, templates and onboarding for every new rep."
        btn={{ label: 'Start onboarding', onClick: go('onboarding') }}
        facts={[
          { icon: 'target', title: 'Sales Process', sub: 'Qualify to launch', onClick: go('process') },
          { icon: 'swords', title: 'Battle Cards', sub: 'Objection handling', onClick: go('battle') }
        ]} />
      <Tiles sq items={[
        { icon: 'target', title: 'Sales Process & Qualification', desc: 'Stages & criteria', onClick: go('process') },
        { icon: 'swords', title: 'Battle Cards', desc: 'Objection handling', onClick: go('battle') },
        { icon: 'mail', title: 'Email & Proposal Templates', desc: 'Ready-to-send', onClick: go('templates') },
        { icon: 'grad', title: 'New Rep Onboarding', desc: 'Training path', onClick: go('onboarding') }
      ]} />
      <Row cols="1fr">
        <StepsCard cfg={CFG.processSteps} icon="target" title="Sales Process & Qualification" anchor="process" />
      </Row>
      <Row cols="1.35fr 1fr">
        <ResCard cfg={CFG.battle} />
        <ResCard cfg={CFG.templates} />
      </Row>
      <Row cols="1fr">
        <Onboarding cfg={CFG.onboarding} />
      </Row>
    </>
  );
};

export default PlaybookPage;
