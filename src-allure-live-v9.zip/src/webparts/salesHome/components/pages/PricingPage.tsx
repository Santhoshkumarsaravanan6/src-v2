import * as React from 'react';

import { c, Icon } from '../ui';
import { useStore } from '../store';
import { Card, Empty, Hero, ResCard, ResTable, Row, Tiles } from '../blocks';
import { QuoteCard } from '../live';
import { StepsCard } from '../steps';
import { CFG } from '../cfg';

const PricingPage: React.FC = () => {
  const s = useStore();
  const go = (anchor: string): (() => void) => (): void => s.navigate('pricing', anchor);
  if (s.pricingLocked) {
    return (
      <Card title="Pricing is restricted" icon="lock" anchor="rates">
        <Empty text="Pricing is limited to an approved SharePoint group. If you need access, ask a site owner to add you to that group." />
      </Card>
    );
  }
  return (
    <>
      <Hero crumb="Pricing" title="Pricing" sub="Rate cards, quotation requests, minimums and discount approval rules for approved users."
        btn={{ label: 'Request a quote', onClick: go('quote') }}
        facts={[
          { icon: 'lock', title: 'Restricted Access', sub: 'Approved users only', onClick: go('rates') },
          { icon: 'coins', title: 'Quote Requests', sub: 'Submit for costing', onClick: go('quote') }
        ]} />
      <div className={c('note')}><Icon n="lock" s={22} sw={1.8} /><span><b>Restricted section.</b> Visible to Sales leadership and approved reps only. Do not share pricing outside the approved group.</span></div>
      <Tiles sq items={[
        { icon: 'coins', title: 'Price Lists & Rate Cards', desc: 'Current rates by category', onClick: go('rates') },
        { icon: 'send', title: 'Quote & Costing Requests', desc: 'Submit a request', onClick: go('quote') },
        { icon: 'clock', title: 'MOQ & Payment Terms', desc: 'Minimums & terms', onClick: go('moq') },
        { icon: 'check', title: 'Discount Approval Rules', desc: 'Who approves what', onClick: go('discount') }
      ]} />
      <Row cols="1fr 1fr">
        <ResCard cfg={CFG.rates} />
        <div><QuoteCard /></div>
      </Row>
      <Row cols="1.2fr 1fr">
        <ResTable cfg={CFG.moq} cols={[{ head: 'Category', field: 'Title' }, { head: 'Standard MOQ', field: 'Sub' }, { head: 'Payment terms', field: 'Extra' }]} />
        <StepsCard cfg={CFG.discountSteps} icon="check" title="Discount Approval Rules" anchor="discount" />
      </Row>
    </>
  );
};

export default PricingPage;
