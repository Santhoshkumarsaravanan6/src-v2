import * as React from 'react';

import { c, Icon } from '../ui';
import { useStore, useGroup } from '../store';
import { Card, Hero, ResCard, Row, Tiles, useResourceActions } from '../blocks';
import { AccountsCard } from '../live';
import type { IResourceItem } from '../data/types';
import { CFG } from '../cfg';

const AccountsPage: React.FC = () => {
  const s = useStore();
  const go = (anchor: string): (() => void) => (): void => s.navigate('accounts', anchor);
  const crm: IResourceItem | undefined = useGroup('accounts', 'CRM')[0];
  const act = useResourceActions(CFG.crm);
  const openCrm = (): void => {
    if (crm && crm.Link) {
      s.openLink(crm.Link);
    } else if (crm) {
      s.toast('Add the web address of your CRM first.');
      act.edit(crm);
    } else {
      act.addNew();
    }
  };
  return (
    <>
      <Hero crumb="Accounts" title="Accounts" sub="Account plans, quarterly business review decks and one-click access to the CRM."
        btn={{ label: 'Open CRM', icon: 'ext', onClick: openCrm }}
        facts={[
          { icon: 'users', title: 'Account Plans', sub: 'Strategic accounts', onClick: go('plans') },
          { icon: 'file', title: 'CRM', sub: 'Open customer records', onClick: go('crm') }
        ]} />
      <Tiles sq items={[
        { icon: 'users', title: 'Account Plans', desc: 'Plan per strategic account', onClick: go('plans') },
        { icon: 'trend', title: 'QBR Decks', desc: 'Quarterly business reviews', onClick: go('qbr') },
        { icon: 'link', title: 'CRM', desc: 'Customer records & pipeline', onClick: go('crm') }
      ]} />
      <Row cols="1.4fr 1fr">
        <AccountsCard anchor="plans" />
        <ResCard cfg={CFG.qbr} />
      </Row>
      <Row cols="1fr">
        <Card anchor="crm">
          <div className={c('crm')}>
            <div className={c('crmIcon')}><Icon n="link" s={36} sw={1.5} /></div>
            <div className={c('crmTitle')}>Customer Accounts (CRM)</div>
            <div className={c('crmSub')}>{crm && crm.Link ? 'Pipeline, contacts and activity for every account.' : 'Add the web address of your CRM to open it from here.'}</div>
            <div className={c('crmBtns')}>
              <button type="button" className={c('btn')} onClick={openCrm}>Open CRM <Icon n="ext" s={17} sw={1.8} /></button>
              {crm && <button type="button" className={c('btn line')} onClick={() => act.edit(crm)}>Change CRM link</button>}
            </div>
          </div>
        </Card>
      </Row>
    </>
  );
};

export default AccountsPage;
