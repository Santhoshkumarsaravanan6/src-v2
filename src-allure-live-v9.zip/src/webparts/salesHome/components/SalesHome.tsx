import * as React from 'react';

import styles from './SalesHome.module.scss';
import type { ISalesHomeProps } from './ISalesHomeProps';
import { Icon, c } from './ui';
import { img } from './images';
import { NAV, type INavItem, type PageKey } from './nav';
import { StoreProvider, useGroup, useStore } from './store';
import { GroupPanel } from './blocks';
import { CFG } from './cfg';
import type { IResourceItem } from './data/types';
import { MemDataService } from './data/memService';
import { SpDataService } from './data/spService';
import type { IDataService } from './data/types';
import HomePage from './pages/HomePage';
import CapabilitiesPage from './pages/CapabilitiesPage';
import InnovationPage from './pages/InnovationPage';
import PricingPage from './pages/PricingPage';
import RegulatoryPage from './pages/RegulatoryPage';
import MarketingPage from './pages/MarketingPage';
import EventsPage from './pages/EventsPage';
import PlaybookPage from './pages/PlaybookPage';
import AccountsPage from './pages/AccountsPage';
import DocumentsPage from './pages/DocumentsPage';

const VIEWS: { [key in PageKey]: React.ComponentType } = {
  'home': HomePage,
  'capabilities': CapabilitiesPage,
  'innovation': InnovationPage,
  'pricing': PricingPage,
  'regulatory': RegulatoryPage,
  'marketing-assets': MarketingPage,
  'events': EventsPage,
  'sales-playbook': PlaybookPage,
  'accounts': AccountsPage,
  'company-documents': DocumentsPage
};

/** First word of the signed-in user's display name (letters only), or '' when unavailable. */
const firstNameOf = (displayName: string): string => {
  const word: string = (displayName || '').trim().split(/[\s,]+/)[0] || '';
  const ch: string = word.charAt(0);
  return ch.toUpperCase() !== ch.toLowerCase() ? word : '';
};

interface INavState {
  page: PageKey;
  anchor: string;
  /** Changes on every navigation so repeated clicks on the same target scroll again. */
  n: number;
}

interface IShellProps {
  nav: INavState;
  showSiteHeader: boolean;
  navigate(page: PageKey, anchor?: string): void;
}

const Shell: React.FC<IShellProps> = ({ nav, showSiteHeader, navigate }) => {
  const { status, notice, persistent, openModal } = useStore();
  const banner: IResourceItem[] = useGroup('site', 'Site banner');
  const footer: IResourceItem[] = useGroup('site', 'Site footer');
  const settings = (): void => openModal('Site settings', (
    <div>
      {[CFG.siteBanner, CFG.siteFooter, CFG.chEventTypes, CFG.chStages, CFG.chCategories, CFG.chStatuses].map((cfg) => (
        <div key={cfg.group} style={{ marginBottom: 22 }}>
          <div style={{ fontWeight: 700, fontSize: 15, margin: '4px 0 6px' }}>{cfg.title}</div>
          <GroupPanel cfg={cfg} />
        </div>
      ))}
    </div>
  ), { wide: true });
  const [menu, setMenu] = React.useState<string>('');
  const navRef = React.useRef<HTMLElement>(null);

  // Close an open dropdown on outside click or Escape, and drop focus so :focus-within lets go too.
  React.useEffect(() => {
    if (!menu) { return undefined; }
    const close = (): void => {
      setMenu('');
      const active = document.activeElement as HTMLElement | null;
      if (active && navRef.current && navRef.current.contains(active)) { active.blur(); }
    };
    const onDown = (e: MouseEvent): void => {
      if (navRef.current && e.target instanceof Node && !navRef.current.contains(e.target)) { close(); }
    };
    const onKey = (e: KeyboardEvent): void => { if (e.key === 'Escape') { close(); } };
    document.addEventListener('mousedown', onDown);
    document.addEventListener('keydown', onKey);
    return (): void => { document.removeEventListener('mousedown', onDown); document.removeEventListener('keydown', onKey); };
  }, [menu]);
  const View: React.ComponentType = VIEWS[nav.page];

  return (
    <>
      {showSiteHeader && (
        <>
          {banner.length > 0 && <div className={c('ban')}>{banner[0].Title}</div>}
          <div className={c('hdr')}>
            <button type="button" className={c('logoBtn')} aria-label="Sales Hub home" onClick={() => navigate('home')}>
              <img className={c('logo')} src={img.logo} alt="Allure Beauty Concepts" />
            </button>
            <div className={c('vd')} />
            <div className={c('hm')}>
              <div className={c('st')}>Sales Hub</div>
              <nav ref={navRef} className={c('nav')} aria-label="Sales Hub">
                {NAV.map((item: INavItem) => (
                  <div key={item.key} className={c('ni')} onMouseLeave={(e) => { setMenu(''); const a = document.activeElement as HTMLElement | null; if (a && e.currentTarget.contains(a) && a.tagName === 'BUTTON' && a.getAttribute('aria-haspopup')) { a.blur(); } }}>
                    <button type="button" className={c(item.key === nav.page ? 'nb on' : 'nb')} onClick={(e) => { e.currentTarget.blur(); setMenu(''); navigate(item.key); }}>{item.label}</button>
                    {item.children && (
                      <>
                        <button type="button" className={c('cv')} aria-label={`${item.label} menu`} aria-haspopup="true" aria-expanded={menu === item.key}
                          onClick={() => setMenu(menu === item.key ? '' : item.key)}><Icon n="chevd" s={15} sw={2} /></button>
                        <div className={c(menu === item.key ? 'dd open' : 'dd')}>
                          {item.children.map((ch: { label: string; anchor: string }) => (
                            <button key={ch.anchor} type="button" onClick={(e) => { e.currentTarget.blur(); setMenu(''); navigate(item.key, ch.anchor); }}>{ch.label}</button>
                          ))}
                        </div>
                      </>
                    )}
                  </div>
                ))}
              </nav>
            </div>
          </div>
        </>
      )}
      <div className={c('main')}>
        {notice && <div className={c('notice')} role="status">{notice}</div>}
        {status === 'loading' ? (
          <div className={c('loading')} role="status">
            <div className={c('spin')} />
            <b>Loading the Sales Hub…</b>
            <span>The first visit also creates the lists that store your events, documents and accounts, so it can take a minute.</span>
          </div>
        ) : (
          <>
            <View />
            <div className={c('foot')}>
              <span>{persistent ? 'Everything you add here is saved in this site’s SH_ lists.' : 'Preview mode: changes are kept in this browser only.'}</span>
              <span><button type="button" className={c('vl')} onClick={settings}>Site settings</button> · Allure Sales Hub</span>
            </div>
          </>
        )}
      </div>
      <div className={c('ftr')}>
        <img src={img.logowhite} alt="Allure Beauty Concepts" />
        {footer.map((r: IResourceItem) => (
          <p key={r.Id} className={r.Tag === 'small' ? c('sm') : undefined}>{r.Title}{r.Sub && <><i>|</i>{r.Sub}</>}</p>
        ))}
      </div>
    </>
  );
};

const SalesHome: React.FC<ISalesHomeProps> = (props) => {
  const [nav, setNav] = React.useState<INavState>({ page: 'home', anchor: '', n: 0 });
  const rootRef = React.useRef<HTMLDivElement>(null);

  const navigate = React.useCallback((page: PageKey, anchor?: string): void => {
    setNav((s: INavState) => ({ page, anchor: anchor || '', n: s.n + 1 }));
  }, []);

  const { spHttpClient, siteUrl } = props;
  const service: IDataService = React.useMemo(
    () => (spHttpClient && siteUrl ? new SpDataService(spHttpClient, siteUrl) : new MemDataService()),
    [spHttpClient, siteUrl]
  );
  const fallback: IDataService = React.useMemo(() => new MemDataService(), []);

  // After every navigation: scroll to the requested section, or to the top of the hub.
  React.useEffect(() => {
    const root: HTMLDivElement | null = rootRef.current;
    if (!root || nav.n === 0) {
      return undefined;
    }
    const timer: number = window.setTimeout(() => {
      const target: Element | null = nav.anchor ? root.querySelector(`[data-anchor="${nav.anchor}"]`) : null;
      (target || root).scrollIntoView({ block: 'start', behavior: 'smooth' });
      if (target) {
        const flash: string = c('flash');
        target.classList.add(flash);
        window.setTimeout(() => target.classList.remove(flash), 1800);
      }
    }, 40);
    return () => window.clearTimeout(timer);
  }, [nav]);

  return (
    <div ref={rootRef} className={styles.pg}>
      <StoreProvider service={service} fallback={fallback} firstName={firstNameOf(props.userDisplayName)} userName={props.userDisplayName} pricingGroup={props.pricingGroup} navigate={navigate}>
        <Shell nav={nav} showSiteHeader={props.showSiteHeader !== false} navigate={navigate} />
      </StoreProvider>
    </div>
  );
};

export default SalesHome;
