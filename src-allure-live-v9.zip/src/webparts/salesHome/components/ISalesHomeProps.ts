import type { SPHttpClient } from '@microsoft/sp-http';

export interface ISalesHomeProps {
  description: string;
  isDarkTheme: boolean;
  environmentMessage: string;
  userDisplayName: string;
  /** Show the Allure logo, "Sales Hub" title and navigation inside the web part. */
  showSiteHeader: boolean;
  /** SharePoint REST client and the address of the site that stores the Sales Hub lists. */
  spHttpClient?: SPHttpClient;
  siteUrl?: string;
  /** SharePoint group allowed to open the Pricing page. Empty means everyone who can open the hub. */
  pricingGroup?: string;
}
