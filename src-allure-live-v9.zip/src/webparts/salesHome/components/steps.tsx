import * as React from 'react';

import { c, Icon } from './ui';
import { useGroup } from './store';
import { Card, Empty, LinkBtn, useResourceActions, type IResCfg } from './blocks';
import type { IResourceItem } from './data/types';

/** A row of numbered steps whose names and descriptions come from one group of the Resources list. */
export const StepsCard: React.FC<{ cfg: IResCfg; icon: string; title: string; anchor: string }> = ({ cfg, icon, title, anchor }) => {
  const items: IResourceItem[] = useGroup(cfg.section, cfg.group);
  const act = useResourceActions(cfg);
  return (
    <Card title={title} icon={icon} anchor={anchor} actions={<LinkBtn label={cfg.addLabel || 'Add step'} icon="plus" strong onClick={act.addNew} />}>
      {!items.length ? <Empty text="No steps yet. Use Add step to create the first one." /> : (
        <div className={c('steps')} style={{ '--c': `repeat(${Math.min(items.length, 5)},1fr)` } as React.CSSProperties}>
          {items.map((it: IResourceItem, i: number) => (
            <div key={it.Id} className={c('step')}>
              <i>{i + 1}</i><b>{it.Title}</b><span>{it.Sub}</span>
              <button type="button" className={c('iconBtn sm ed stepEd')} aria-label={`Edit ${it.Title}`} onClick={() => act.edit(it)}><Icon n="edit" s={16} sw={1.8} /></button>
            </div>
          ))}
        </div>
      )}
    </Card>
  );
};
