import * as React from 'react';

import { c, Icon, press, TONES } from './ui';
import { useStore } from './store';
import { Card, Empty, LinkBtn } from './blocks';
import { Form, type FormValues } from './forms';
import { fmtLong } from './data/dates';
import type { ILibFile, IResourceItem } from './data/types';

const size = (n: number): string => (n >= 1048576 ? `${(n / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1024))} KB`);

/** Every file in the SH_Documents library, with upload, rename and delete. */
export const LibraryCard: React.FC = () => {
  const s = useStore();
  const input: React.RefObject<HTMLInputElement> = React.useRef<HTMLInputElement>(null);
  const [busy, setBusy] = React.useState<boolean>(false);

  const upload = (e: React.ChangeEvent<HTMLInputElement>): void => {
    const file: File | undefined = e.target.files ? e.target.files[0] : undefined;
    e.target.value = '';
    if (!file) { return; }
    setBusy(true);
    s.addToLibrary(file).then(() => setBusy(false)).catch(() => setBusy(false));
  };

  const edit = (f: ILibFile): void => {
    const uses: number = s.data.resources.filter((r: IResourceItem) => r.FileId === f.Id).length;
    s.openModal('Edit file', (
      <Form
        fields={[{ name: 'Name', label: 'File name', required: true }]}
        initial={{ Name: f.Name }}
        submitLabel="Rename"
        footnote={uses ? `${uses} item${uses === 1 ? '' : 's'} in the hub use this file. They keep working after a rename. Deleting the file leaves them without a file.` : 'No item in the hub uses this file yet.'}
        onSubmit={async (v: FormValues): Promise<boolean> => {
          try { await s.renameFile(f.Id, v.Name); s.toast('File renamed'); return true; } catch (err) { s.toast(err instanceof Error ? err.message : 'Could not rename the file', true); return false; }
        }}
        onDelete={() => s.removeFile(f.Id)}
      />
    ));
  };

  return (
    <Card title="Document library" icon="file" anchor="library"
      actions={s.supportsFiles ? <>
        <LinkBtn label={busy ? 'Uploading…' : 'Upload file'} icon="plus" strong onClick={() => { if (input.current && !busy) { input.current.click(); } }} />
        <LinkBtn label="Open in SharePoint" onClick={() => s.openLink(s.libraryUrl)} />
      </> : undefined}>
      <input ref={input} type="file" hidden onChange={upload} aria-label="Choose a file to upload" />
      {!s.supportsFiles ? <Empty text="The document library is available once the hub runs inside SharePoint. Files you upload are stored in the SH_Documents library of your site." />
        : !s.files.length ? <Empty text="No files yet. Use Upload file, or attach a file when you add a document anywhere in the hub." />
          : s.files.map((f: ILibFile, i: number) => (
            <div key={f.Id} className={c('lr')} {...press(() => s.openLink(f.Url))}>
              <div className={c('th ph')} style={{ background: TONES[i % 6][0], color: TONES[i % 6][1] }}><Icon n="file" s={26} sw={1.5} /></div>
              <div className={c('g')}><b>{f.Name}</b><span className={c('s')}>{size(f.Size)} · Updated {fmtLong(f.Modified.slice(0, 10))}{f.Group ? ` · ${f.Group}` : ''}</span></div>
              <div className={c('ri')}>
                <button type="button" className={c('iconBtn sm ed')} aria-label={`Edit ${f.Name}`} onClick={(e: React.MouseEvent) => { e.stopPropagation(); edit(f); }}><Icon n="edit" s={16} sw={1.8} /></button>
                <Icon n="dl" s={18} sw={1.7} />
              </div>
            </div>
          ))}
    </Card>
  );
};
