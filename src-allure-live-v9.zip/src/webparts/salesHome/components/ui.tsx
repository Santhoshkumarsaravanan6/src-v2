import * as React from 'react';

import styles from './SalesHome.module.scss';
import { ICON_PATHS } from './icons';

const classMap: { [name: string]: string } = styles as unknown as { [name: string]: string };

/** Maps space-separated design class names to their CSS-module equivalents. */
export const c = (names: string): string =>
  names
    .split(' ')
    .map((n: string) => classMap[n])
    .filter((n: string | undefined) => !!n)
    .join(' ');

export interface IIconProps {
  /** Icon name from icons.ts */
  n: string;
  /** Size in px */
  s?: number;
  /** Stroke width */
  sw?: number;
}

/** Inline stroke icon. Colour follows the surrounding text colour (currentColor). */
export const Icon: React.FC<IIconProps> = ({ n, s = 22, sw = 1.7 }) => (
  <svg
    width={s}
    height={s}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth={sw}
    strokeLinecap="round"
    strokeLinejoin="round"
    aria-hidden="true"
    dangerouslySetInnerHTML={{ __html: ICON_PATHS[n] || '' }}
  />
);

/** Makes a non-button element behave like a button (mouse, Enter and Space). */
export const press = (fn: () => void): {
  role: 'button';
  tabIndex: number;
  onClick: (e: React.MouseEvent) => void;
  onKeyDown: (e: React.KeyboardEvent) => void;
} => ({
  role: 'button',
  tabIndex: 0,
  onClick: (e: React.MouseEvent): void => { e.stopPropagation(); fn(); },
  onKeyDown: (e: React.KeyboardEvent): void => {
    if (e.target === e.currentTarget && (e.key === 'Enter' || e.key === ' ')) {
      e.preventDefault();
      fn();
    }
  }
});

/** Soft background and text colours used for icon tiles in lists. */
export const TONES: Array<[string, string]> = [
  ['#e4f3f6', '#0a3f52'], ['#fff0e8', '#b8431c'], ['#e4f1f8', '#0a5f70'], ['#e3f4ee', '#16785f'], ['#fff0ea', '#0a3f52'], ['#e8eff4', '#0e7c8c']
];

/** Converts a stored label colour (g, o, b, p or its name) to the CSS class of the tag. */
export const toneClass = (tone: string): string => {
  const t: string = (tone || '').toLowerCase();
  const map: { [k: string]: string } = { g: 'g', green: 'g', o: 'o', orange: 'o', b: 'b', blue: 'b', p: 'p', navy: 'p' };
  return map[t] || '';
};
