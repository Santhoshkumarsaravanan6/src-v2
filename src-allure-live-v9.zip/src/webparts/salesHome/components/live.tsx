import * as React from 'react';

import { c, Icon, press, toneClass } from './ui';
import { img } from './images';
import { useChoices, useGroup, useStore } from './store';
import { Form, type FormValues, type IFieldCfg } from './forms';
import { Card, Empty, LinkBtn, Tag, useResourceActions, type IResCfg } from './blocks';
import { daysIn, dayNum, firstWeekday, fmtLong, keyOf, monShort, monthName, todayKey } from './data/dates';
import type { IAccountItem, IEventItem, INewsItem, IRequestItem, IResourceItem, IWinItem } from './data/types';

const DEFAULT_EVENT_TYPES: string[] = ['Trade show', 'Conference', 'Customer visit', 'Meeting', 'Webinar', 'Other'];
/** Options plus the item's current value, so editing never blanks a value whose option was removed. */
const withCurrent = (options: string[], current?: string): string[] => (current && options.indexOf(current) < 0 ? options.concat(current) : options);
const typeTone = (t: string): string => (t === 'Trade show' ? '' : t === 'Conference' ? 'b' : t === 'Customer visit' ? 'g' : t === 'Meeting' ? 'o' : 'p');

/* ---------- events ---------- */

const eventFields = (types: string[]): IFieldCfg[] => [
  { name: 'Title', label: 'Event name', required: true, placeholder: 'For example: Cosmoprof North America' },
  { name: 'EventDate', label: 'Date', type: 'date', required: true },
  { name: 'Location', label: 'Location', placeholder: 'City, state' },
  { name: 'EventType', label: 'Type', type: 'select', options: types, placeholder: 'Select a type' },
  { name: 'Notes', label: 'Booth or notes', type: 'textarea' }
];

export const useEventActions = (): {
  addNew(date?: string): void;
  edit(e: IEventItem): void;
  detail(e: IEventItem): void;
} => {
  const store = useStore();
  const { openModal, closeModal } = store;
  const types: string[] = useChoices('Event types', DEFAULT_EVENT_TYPES);
  const form = (ev?: IEventItem, date?: string): React.ReactNode => (
    <Form
      fields={eventFields(withCurrent(types, ev && ev.EventType))}
      initial={ev ? { Title: ev.Title, EventDate: ev.EventDate, Location: ev.Location, EventType: ev.EventType, Notes: ev.Notes } : { EventDate: date || todayKey() }}
      submitLabel={ev ? 'Save changes' : 'Add event'}
      onSubmit={(v: FormValues) => {
        const values: { [k: string]: string } = { Title: v.Title.trim(), EventDate: v.EventDate, Location: v.Location, EventType: v.EventType, Notes: v.Notes };
        return ev ? store.update('events', ev.Id, values, 'Event updated') : store.add('events', values, 'Event added. It now shows in Upcoming Events and on the calendar.');
      }}
      onDelete={ev ? () => store.remove('events', ev.Id, 'Event deleted') : undefined}
    />
  );
  const edit = (ev: IEventItem): void => openModal('Edit event', form(ev));
  return {
    addNew: (date?: string): void => openModal('Add event', form(undefined, date)),
    edit,
    detail: (ev: IEventItem): void => openModal(ev.Title, (
      <div>
        <dl className={c('dl')}>
          <dt>Date</dt><dd>{fmtLong(ev.EventDate)}</dd>
          {ev.Location && <><dt>Location</dt><dd>{ev.Location}</dd></>}
          {ev.EventType && <><dt>Type</dt><dd>{ev.EventType}</dd></>}
          {ev.Notes && <><dt>Notes</dt><dd>{ev.Notes}</dd></>}
        </dl>
        <div className={c('formBtns')}>
          <span className={c('grow')} />
          <button type="button" className={c('btn line')} onClick={closeModal}>Close</button>
          <button type="button" className={c('btn')} onClick={() => openModal('Edit event', form(ev), { replace: true })}>Edit</button>
        </div>
      </div>
    ))
  };
};

const sortEvents = (list: IEventItem[]): IEventItem[] => list.slice().sort((a: IEventItem, b: IEventItem) => (a.EventDate < b.EventDate ? -1 : a.EventDate > b.EventDate ? 1 : a.Id - b.Id));

const EventRows: React.FC<{ events: IEventItem[] }> = ({ events }) => {
  const act = useEventActions();
  if (!events.length) {
    return <Empty text='No events yet. Use "Add event" to create one.' />;
  }
  return (
    <>
      {events.map((ev: IEventItem) => (
        <div key={ev.Id} className={c('lr')} {...press(() => act.detail(ev))}>
          <div className={c('db')}><i>{monShort(ev.EventDate)}</i><b>{dayNum(ev.EventDate)}</b></div>
          <div className={c('g')}>
            <b>{ev.Title}</b>
            <span className={c('s')}>{[ev.Location, ev.Notes].filter((x: string) => !!x).join(' · ')}</span>
            {ev.EventType && <span className={c('tagrow')}><Tag text={ev.EventType} tone={typeTone(ev.EventType)} /></span>}
          </div>
          <div className={c('ri')}>
            <button type="button" className={c('iconBtn sm ed')} aria-label={`Edit ${ev.Title}`} onClick={(e: React.MouseEvent) => { e.stopPropagation(); act.edit(ev); }}><Icon n="edit" s={16} sw={1.8} /></button>
            <Icon n="chev" s={18} sw={2} />
          </div>
        </div>
      ))}
    </>
  );
};

export const EventsCard: React.FC<{ limit?: number; anchor?: string; title?: string }> = ({ limit, anchor, title }) => {
  const store = useStore();
  const act = useEventActions();
  const today: string = todayKey();
  const [showPast, setShowPast] = React.useState<boolean>(false);
  const all: IEventItem[] = sortEvents(store.data.events);
  const upcoming: IEventItem[] = all.filter((e: IEventItem) => e.EventDate >= today);
  const past: IEventItem[] = all.filter((e: IEventItem) => e.EventDate < today).reverse();
  const shown: IEventItem[] = limit ? upcoming.slice(0, limit) : upcoming;
  return (
    <Card title={title || 'Upcoming Events'} icon="cal" anchor={anchor}
      actions={<>
        <LinkBtn label="Add event" icon="plus" strong onClick={() => act.addNew()} />
        {limit ? <LinkBtn label="View Calendar" onClick={() => store.navigate('events', 'calendar')} /> : null}
      </>}>
      <EventRows events={shown} />
      {!limit && past.length > 0 && (
        <>
          <button type="button" className={c('toggle')} onClick={() => setShowPast(!showPast)}>{showPast ? 'Hide' : 'Show'} past events ({past.length})</button>
          {showPast && <EventRows events={past} />}
        </>
      )}
    </Card>
  );
};

export const CalendarCard: React.FC<{ withList?: boolean; anchor?: string; title: string }> = ({ withList, anchor, title }) => {
  const store = useStore();
  const act = useEventActions();
  const now: Date = new Date();
  const [cursor, setCursor] = React.useState<{ y: number; m: number }>({ y: now.getFullYear(), m: now.getMonth() });
  const today: string = todayKey();
  const step = (d: number): void => {
    const t: Date = new Date(cursor.y, cursor.m + d, 1);
    setCursor({ y: t.getFullYear(), m: t.getMonth() });
  };
  const byDay: { [key: string]: IEventItem[] } = {};
  store.data.events.forEach((e: IEventItem) => { (byDay[e.EventDate] = byDay[e.EventDate] || []).push(e); });
  const cells: React.ReactNode[] = [];
  for (let i: number = 0; i < firstWeekday(cursor.y, cursor.m); i++) {
    cells.push(<div key={'b' + i} />);
  }
  for (let d: number = 1; d <= daysIn(cursor.y, cursor.m); d++) {
    const key: string = keyOf(cursor.y, cursor.m, d);
    const list: IEventItem[] = byDay[key] || [];
    const click = (): void => {
      if (list.length === 1) {
        act.detail(list[0]);
      } else if (list.length > 1) {
        store.openModal(fmtLong(key), <div><EventRows events={list} /><div className={c('panelBar')}><LinkBtn label="Add event on this day" icon="plus" strong onClick={() => act.addNew(key)} /></div></div>);
      } else {
        act.addNew(key);
      }
    };
    cells.push(
      <button key={key} type="button" className={c(`${list.length ? 'e' : ''} ${key === today ? 'td' : ''}`.trim())}
        aria-label={`${fmtLong(key)}${list.length ? ', ' + list.map((e: IEventItem) => e.Title).join(', ') : ', add an event'}`} onClick={click}>{d}</button>
    );
  }
  const calendar: React.ReactNode = (
    <div>
      <div className={c('calHead')}>
        <button type="button" className={c('iconBtn sm')} aria-label="Previous month" onClick={() => step(-1)}><Icon n="chevl" s={18} sw={2} /></button>
        <b>{monthName(cursor.m)} {cursor.y}</b>
        <button type="button" className={c('iconBtn sm')} aria-label="Next month" onClick={() => step(1)}><Icon n="chev" s={18} sw={2} /></button>
      </div>
      <div className={c('cal')}>
        {'SMTWTFS'.split('').map((l: string, i: number) => <div key={i} className={c('w')}>{l}</div>)}
        {cells}
      </div>
    </div>
  );
  const upcoming: IEventItem[] = sortEvents(store.data.events).filter((e: IEventItem) => e.EventDate >= today).slice(0, 3);
  return (
    <Card title={title} icon="cal" anchor={anchor}
      actions={<>
        <LinkBtn label="Add event" icon="plus" strong onClick={() => act.addNew()} />
        {withList ? <LinkBtn label="Full Calendar" onClick={() => store.navigate('events', 'calendar')} /> : null}
      </>}>
      {withList ? <div className={c('two')}>{calendar}<div><EventRows events={upcoming} /></div></div> : calendar}
    </Card>
  );
};

/* ---------- news and wins ---------- */

export const NewsCard: React.FC = () => {
  const store = useStore();
  const [all, setAll] = React.useState<boolean>(false);
  const fields: IFieldCfg[] = [
    { name: 'Title', label: 'Headline', required: true },
    { name: 'PublishDate', label: 'Date', type: 'date', required: true },
    { name: 'Summary', label: 'Summary', type: 'textarea' },
    { name: 'Link', label: 'Link (optional)', placeholder: 'Paste a web address or page link' }
  ];
  const form = (n?: INewsItem): React.ReactNode => (
    <Form fields={fields} submitLabel={n ? 'Save changes' : 'Publish update'}
      initial={n ? { Title: n.Title, PublishDate: n.PublishDate, Summary: n.Summary, Link: n.Link } : { PublishDate: todayKey() }}
      onSubmit={(v: FormValues) => {
        const values: { [k: string]: string } = { Title: v.Title.trim(), PublishDate: v.PublishDate, Summary: v.Summary, Link: v.Link.trim() };
        return n ? store.update('news', n.Id, values, 'Update saved') : store.add('news', values, 'Update published');
      }}
      onDelete={n ? () => store.remove('news', n.Id, 'Update deleted') : undefined} />
  );
  const items: INewsItem[] = store.data.news.slice().sort((a: INewsItem, b: INewsItem) => (a.PublishDate < b.PublishDate ? 1 : a.PublishDate > b.PublishDate ? -1 : b.Id - a.Id));
  const open = (n: INewsItem): void => {
    store.openModal(n.Title, (
      <div>
        <dl className={c('dl')}>
          <dt>Date</dt><dd>{fmtLong(n.PublishDate)}</dd>
          {n.Summary && <><dt>Summary</dt><dd>{n.Summary}</dd></>}
        </dl>
        <div className={c('formBtns')}>
          <span className={c('grow')} />
          {n.Link && <button type="button" className={c('btn line')} onClick={() => store.openLink(n.Link)}>Open link</button>}
          <button type="button" className={c('btn')} onClick={() => store.openModal('Edit update', form(n), { replace: true })}>Edit</button>
        </div>
      </div>
    ));
  };
  const rows = (list: INewsItem[]): React.ReactNode => (list.length ? list.map((n: INewsItem, i: number) => (
    <div key={n.Id} className={c('lr')} {...press(() => open(n))}>
      <img className={c('th')} src={[img.n1, img.n2, img.n3][i % 3]} alt="" />
      <div className={c('g')}><b>{n.Title}</b><span className={c('s')}>{fmtLong(n.PublishDate)}</span></div>
      <div className={c('ri')}><Icon n="chev" s={18} sw={2} /></div>
    </div>
  )) : <Empty text='No updates yet. Use "Add" to publish the first one.' />);
  return (
    <Card title="Latest Updates" icon="megaphone"
      actions={<>
        <LinkBtn label="Add" icon="plus" strong onClick={() => store.openModal('Add update', form())} />
        {items.length > 3 && <LinkBtn label={all ? 'Show less' : 'View All'} onClick={() => setAll(!all)} />}
      </>}>
      {rows(all ? items : items.slice(0, 3))}
    </Card>
  );
};

const WIN_CATS: string[] = ['Skincare', 'Haircare', 'Color cosmetics', 'OTC', 'Other'];

export const WinsCard: React.FC = () => {
  const store = useStore();
  const [all, setAll] = React.useState<boolean>(false);
  const fields: IFieldCfg[] = [
    { name: 'Title', label: 'Win', required: true, placeholder: 'For example: Won 3-SKU skincare program' },
    { name: 'Summary', label: 'Details', type: 'textarea' },
    { name: 'Category', label: 'Category', type: 'select', options: WIN_CATS, placeholder: 'Select a category' }
  ];
  const form = (w?: IWinItem): React.ReactNode => (
    <Form fields={fields} submitLabel={w ? 'Save changes' : 'Add win'}
      initial={w ? { Title: w.Title, Summary: w.Summary, Category: w.Category } : undefined}
      onSubmit={(v: FormValues) => {
        const values: { [k: string]: string } = { Title: v.Title.trim(), Summary: v.Summary, Category: v.Category };
        return w ? store.update('wins', w.Id, values, 'Win saved') : store.add('wins', values, 'Win added');
      }}
      onDelete={w ? () => store.remove('wins', w.Id, 'Win deleted') : undefined} />
  );
  const items: IWinItem[] = store.data.wins.slice().sort((a: IWinItem, b: IWinItem) => b.Id - a.Id);
  const shown: IWinItem[] = all ? items : items.slice(0, 3);
  return (
    <Card title="Recent Wins" icon="trophy"
      actions={<>
        <LinkBtn label="Add" icon="plus" strong onClick={() => store.openModal('Add win', form())} />
        {items.length > 3 && <LinkBtn label={all ? 'Show less' : 'View All'} onClick={() => setAll(!all)} />}
      </>}>
      {shown.length ? shown.map((w: IWinItem) => (
        <div key={w.Id} className={c('lr')} {...press(() => store.openModal(w.Title, form(w)))}>
          <div className={c('th ph')} style={{ background: '#e3f4ee', color: '#16785f' }}><Icon n="check" s={26} sw={1.8} /></div>
          <div className={c('g')}><b>{w.Title}</b><span className={c('s')}>{w.Summary}</span></div>
          <div className={c('ri')}><Tag text={w.Category} tone={w.Category === 'Haircare' ? 'o' : w.Category === 'OTC' ? 'b' : ''} /><Icon n="edit" s={16} sw={1.8} /></div>
        </div>
      )) : <Empty text='No wins yet. Use "Add" to record the first one.' />}
    </Card>
  );
};

/* ---------- accounts ---------- */

const DEFAULT_CATEGORIES: string[] = ['Skincare', 'Haircare', 'Color cosmetics', 'OTC', 'Other'];
const DEFAULT_STAGES: string[] = ['Prospect', 'Sampling', 'Quoting', 'Active', 'On hold'];
const stageTone = (s: string): string => (s === 'Active' ? 'g' : s === 'Sampling' ? 'b' : s === 'Quoting' ? 'o' : '');

export const AccountsCard: React.FC<{ anchor?: string }> = ({ anchor }) => {
  const store = useStore();
  const stages: string[] = useChoices('Account stages', DEFAULT_STAGES);
  const segments: string[] = useChoices('Quote categories', DEFAULT_CATEGORIES);
  const fieldsFor = (a?: IAccountItem): IFieldCfg[] => [
    { name: 'Title', label: 'Account name', required: true },
    { name: 'Segment', label: 'Segment', type: 'select', options: withCurrent(segments, a && a.Segment), placeholder: 'Select a segment' },
    { name: 'Owner', label: 'Owner' },
    { name: 'Stage', label: 'Stage', type: 'select', options: withCurrent(stages, a && a.Stage), placeholder: 'Select a stage' },
    { name: 'PlanLink', label: 'Account plan link (optional)', placeholder: 'Paste a SharePoint file link' }
  ];
  const form = (a?: IAccountItem): React.ReactNode => (
    <Form fields={fieldsFor(a)} submitLabel={a ? 'Save changes' : 'Add account'}
      initial={a ? { Title: a.Title, Segment: a.Segment, Owner: a.Owner, Stage: a.Stage, PlanLink: a.PlanLink } : { Owner: store.userName }}
      onSubmit={(v: FormValues) => {
        const values: { [k: string]: string } = { Title: v.Title.trim(), Segment: v.Segment, Owner: v.Owner, Stage: v.Stage, PlanLink: v.PlanLink.trim() };
        return a ? store.update('accounts', a.Id, values, 'Account saved') : store.add('accounts', values, 'Account added');
      }}
      onDelete={a ? () => store.remove('accounts', a.Id, 'Account deleted') : undefined} />
  );
  return (
    <Card title="Account Plans" icon="users" anchor={anchor} actions={<LinkBtn label="Add account" icon="plus" strong onClick={() => store.openModal('Add account', form())} />}>
      {!store.data.accounts.length ? <Empty text='No accounts yet. Use "Add account" to create one.' /> : (
        <table>
          <tbody>
            <tr className={c('hd')}><th>Account</th><th>Segment</th><th>Owner</th><th>Stage</th><th>Plan</th></tr>
            {store.data.accounts.map((a: IAccountItem) => (
              <tr key={a.Id} className={c('clk')} {...press(() => store.openModal(a.Title, form(a)))}>
                <td data-label="Account"><b>{a.Title}</b></td>
                <td data-label="Segment">{a.Segment}</td>
                <td data-label="Owner">{a.Owner}</td>
                <td data-label="Stage"><Tag text={a.Stage} tone={stageTone(a.Stage)} /></td>
                <td data-label="Plan">
                  {a.PlanLink ? (
                    <button type="button" className={c('iconBtn sm')} aria-label={`Open plan for ${a.Title}`} onClick={(e: React.MouseEvent) => { e.stopPropagation(); store.openLink(a.PlanLink); }}><Icon n="ext" s={17} sw={1.6} /></button>
                  ) : <span className={c('muted')}>Add link</span>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </Card>
  );
};

/* ---------- requests (quotes and leads) ---------- */

const DEFAULT_STATUSES: string[] = ['New', 'In review', 'Quoted', 'Won', 'Lost'];

const RequestList: React.FC<{ type: 'Quote' | 'Lead'; empty: string }> = ({ type, empty }) => {
  const store = useStore();
  const categories: string[] = useChoices('Quote categories', DEFAULT_CATEGORIES);
  const statuses: string[] = useChoices('Quote statuses', DEFAULT_STATUSES);
  const items: IRequestItem[] = store.data.requests.filter((r: IRequestItem) => r.RequestType === type).sort((a: IRequestItem, b: IRequestItem) => b.Id - a.Id).slice(0, 5);
  const fields: IFieldCfg[] = type === 'Quote'
    ? [{ name: 'Title', label: 'Customer', required: true }, { name: 'Category', label: 'Category', type: 'select', options: categories }, { name: 'Quantity', label: 'Estimated quantity' },
      { name: 'TargetDate', label: 'Target launch date', type: 'date' }, { name: 'Notes', label: 'Notes', type: 'textarea' }, { name: 'Status', label: 'Status', type: 'select', options: statuses }]
    : [{ name: 'Title', label: 'Contact name', required: true }, { name: 'Contact', label: 'Company and email' }, { name: 'Category', label: 'Interested in', type: 'select', options: categories },
      { name: 'Notes', label: 'Notes and next step', type: 'textarea' }, { name: 'Status', label: 'Status', type: 'select', options: ['New', 'Contacted', 'Sample sent', 'Quote sent', 'Closed'] }];
  const edit = (r: IRequestItem): void => store.openModal(`${type === 'Quote' ? 'Quote request' : 'Lead'}: ${r.Title}`, (
    <Form fields={fields} submitLabel="Save changes"
      initial={{ Title: r.Title, Category: r.Category, Quantity: r.Quantity, TargetDate: r.TargetDate, Notes: r.Notes, Status: r.Status, Contact: r.Contact }}
      onSubmit={(v: FormValues) => store.update('requests', r.Id, { Title: v.Title.trim(), Category: v.Category || '', Quantity: v.Quantity || '', TargetDate: v.TargetDate || '', Notes: v.Notes || '', Status: v.Status || '', Contact: v.Contact || '' }, 'Saved')}
      onDelete={() => store.remove('requests', r.Id, 'Deleted')} />
  ));
  if (!items.length) {
    return <Empty text={empty} />;
  }
  return (
    <>
      {items.map((r: IRequestItem) => (
        <div key={r.Id} className={c('lr')} {...press(() => edit(r))}>
          <div className={c('th ph')} style={{ background: '#e4f3f6', color: '#0a3f52' }}><Icon n={type === 'Quote' ? 'send' : 'users'} s={24} sw={1.5} /></div>
          <div className={c('g')}><b>{r.Title}</b><span className={c('s')}>{[r.Category, r.Quantity, r.Contact].filter((x: string) => !!x).join(' · ')}</span></div>
          <div className={c('ri')}><Tag text={r.Status} tone={r.Status === 'Won' || r.Status === 'Closed' ? 'g' : r.Status === 'Lost' ? 'p' : 'o'} /><Icon n="chev" s={18} sw={2} /></div>
        </div>
      ))}
    </>
  );
};

export const QuoteCard: React.FC = () => {
  const store = useStore();
  const categories: string[] = useChoices('Quote categories', DEFAULT_CATEGORIES);
  const fields: IFieldCfg[] = [
    { name: 'Title', label: 'Customer name', required: true, placeholder: 'Enter customer' },
    { name: 'Category', label: 'Product category', type: 'select', options: categories, placeholder: 'Select category', required: true },
    { name: 'Quantity', label: 'Estimated quantity', placeholder: 'Units' },
    { name: 'TargetDate', label: 'Target launch date', type: 'date' },
    { name: 'Notes', label: 'Notes', type: 'textarea' }
  ];
  return (
    <>
      <Card title="Quote & Costing Request" icon="send" anchor="quote">
        <Form fields={fields} inline submitLabel="Submit request"
          onSubmit={(v: FormValues) => store.add('requests', {
            RequestType: 'Quote', Title: v.Title.trim(), Category: v.Category, Quantity: v.Quantity, TargetDate: v.TargetDate, Notes: v.Notes, Status: 'New', Contact: store.userName
          }, 'Quote request submitted')} />
      </Card>
      <Card title="Recent requests" icon="clock" anchor="requests" style={{ marginTop: 18 }}>
        <RequestList type="Quote" empty="Submitted requests will appear here." />
      </Card>
    </>
  );
};

export const LeadsCard: React.FC = () => {
  const store = useStore();
  const categories: string[] = useChoices('Quote categories', DEFAULT_CATEGORIES);
  const eventNames: string[] = sortEvents(store.data.events).map((e: IEventItem) => e.Title);
  const fields: IFieldCfg[] = [
    { name: 'Title', label: 'Contact name', required: true },
    { name: 'Contact', label: 'Company and email', placeholder: 'Company, name@company.com' },
    { name: 'Category', label: 'Interested in', type: 'select', options: categories, placeholder: 'Select category' },
    { name: 'Event', label: 'Captured at', type: 'select', options: eventNames, placeholder: 'Select an event (optional)' },
    { name: 'Notes', label: 'Notes and next step', type: 'textarea' }
  ];
  const capture = (): void => store.openModal('Capture a lead', (
    <Form fields={fields} submitLabel="Save lead"
      onSubmit={(v: FormValues) => store.add('requests', {
        RequestType: 'Lead', Title: v.Title.trim(), Contact: v.Contact, Category: v.Category, Notes: (v.Event ? `Event: ${v.Event}. ` : '') + v.Notes, Status: 'New'
      }, 'Lead saved')} />
  ));
  return (
    <Card title="Lead Capture & Follow-Up" icon="users" anchor="leads" actions={<LinkBtn label="Capture lead" icon="plus" strong onClick={capture} />}>
      <div className={c('steps')} style={{ '--c': 'repeat(3,1fr)' } as React.CSSProperties}>
        <div className={c('step')}><i>1</i><b>Capture</b><span>Scan or enter the lead at the booth</span></div>
        <div className={c('step')}><i>2</i><b>Assign</b><span>Owner and next step set within 24 hours</span></div>
        <div className={c('step')}><i>3</i><b>Follow up</b><span>Samples, quote or meeting booked</span></div>
      </div>
      <div style={{ marginTop: 14 }}><RequestList type="Lead" empty="Captured leads will appear here." /></div>
    </Card>
  );
};

/* ---------- other live blocks ---------- */

/** Org chart: the row labelled "lead" is the top box. */
export const OrgChart: React.FC<{ cfg: IResCfg }> = ({ cfg }) => {
  const items: IResourceItem[] = useGroup(cfg.section, cfg.group);
  const act = useResourceActions(cfg);
  const lead: IResourceItem | undefined = items.filter((i: IResourceItem) => i.Tag === 'lead')[0];
  const rest: IResourceItem[] = items.filter((i: IResourceItem) => i !== lead);
  const node = (it: IResourceItem, cls: string): React.ReactNode => (
    <div key={it.Id} className={c(cls)} {...press(() => act.edit(it))}><b>{it.Title}</b><span>{it.Sub}</span></div>
  );
  return (
    <Card title={cfg.title} icon={cfg.icon} anchor={cfg.anchor} actions={<LinkBtn label="Add role" icon="plus" strong onClick={act.addNew} />}>
      <div className={c('oc')}>
        {lead && node(lead, 'nd lead')}
        {lead && rest.length > 0 && <div className={c('ln')} />}
        <div className={c('lv')}>{rest.map((it: IResourceItem) => node(it, 'nd'))}</div>
      </div>
    </Card>
  );
};

export const Onboarding: React.FC<{ cfg: IResCfg }> = ({ cfg }) => {
  const items: IResourceItem[] = useGroup(cfg.section, cfg.group);
  const act = useResourceActions(cfg);
  return (
    <Card title={cfg.title} icon={cfg.icon} anchor={cfg.anchor} actions={<LinkBtn label="Add step" icon="plus" strong onClick={act.addNew} />}>
      {items.length ? items.map((it: IResourceItem) => {
        const pct: number = Math.max(0, Math.min(100, parseInt(it.Extra, 10) || 0));
        return (
          <div key={it.Id} className={c('prog')} {...press(() => act.edit(it))}>
            <div className={c('progTop')}><b>{it.Title}</b><span>{it.Sub}</span></div>
            <div className={c('bar')}><i style={{ width: `${pct}%` }} /></div>
          </div>
        );
      }) : <Empty text='No steps yet. Use "Add step" to create the first one.' />}
    </Card>
  );
};

export const Concepts: React.FC<{ cfg: IResCfg }> = ({ cfg }) => {
  const items: IResourceItem[] = useGroup(cfg.section, cfg.group);
  const act = useResourceActions(cfg);
  const pics: string[] = [img.jar, img.dropper, img.tube, img.bottle];
  return (
    <>
      <div className={c('cgHead')}>
        <LinkBtn label="Add concept" icon="plus" strong onClick={act.addNew} />
      </div>
      <div className={c('cgrid')} data-anchor={cfg.anchor}>
        {items.map((it: IResourceItem, i: number) => (
          <div key={it.Id} className={c('card clk')} {...press(() => act.edit(it))}>
            <img className={c('cimg')} src={pics[i % 4]} alt="" />
            <div className={c('ctitle')}>{it.Title}</div>
            <div className={c('csub')}>{it.Sub}</div>
            <Tag text={it.Tag} tone={it.TagTone} /> {it.Extra && <span className={c(`tag ${toneClass(/launch/i.test(it.Extra) ? 'g' : 'o')}`)}>{it.Extra}</span>}
          </div>
        ))}
        {!items.length && <Empty text='No concepts yet. Use "Add concept" to create the first one.' />}
      </div>
    </>
  );
};

/** Three editable stat boxes (facility size, lines, lead time). */
export const Stats: React.FC<{ cfg: IResCfg }> = ({ cfg }) => {
  const items: IResourceItem[] = useGroup(cfg.section, cfg.group);
  const store = useStore();
  const edit = (it: IResourceItem): void => store.openModal(`Edit: ${it.Sub}`, (
    <Form fields={[{ name: 'Title', label: it.Sub, required: true, placeholder: 'For example: 120,000' }]} initial={{ Title: it.Title }} submitLabel="Save"
      onSubmit={(v: FormValues) => store.update('resources', it.Id, { Title: v.Title.trim() }, 'Saved')} />
  ));
  return (
    <div className={c('stats')}>
      {items.map((it: IResourceItem) => (
        <div key={it.Id} className={c('stat')} {...press(() => edit(it))}><b>{it.Title}</b><span>{it.Sub}</span></div>
      ))}
    </div>
  );
};
