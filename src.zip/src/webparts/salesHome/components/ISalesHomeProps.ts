export interface ISalesHomeProps {
  description: string;
  isDarkTheme: boolean;
  environmentMessage: string;
  userDisplayName: string;
  /** Show the Allure logo, "Sales Hub" title and navigation inside the web part. */
  showSiteHeader: boolean;
}
