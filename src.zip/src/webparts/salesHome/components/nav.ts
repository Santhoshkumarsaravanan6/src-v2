export type PageKey =
  | 'home'
  | 'capabilities'
  | 'innovation'
  | 'pricing'
  | 'regulatory'
  | 'marketing-assets'
  | 'events'
  | 'sales-playbook'
  | 'accounts'
  | 'company-documents';

export interface INavItem {
  key: PageKey;
  label: string;
  /** Shows the dropdown chevron used in the client's navigation design. */
  dropdown: boolean;
}

export const NAV: INavItem[] = [
  { key: 'home', label: 'Home', dropdown: false },
  { key: 'capabilities', label: 'Capabilities', dropdown: true },
  { key: 'innovation', label: 'Innovation', dropdown: true },
  { key: 'pricing', label: 'Pricing', dropdown: false },
  { key: 'regulatory', label: 'Regulatory', dropdown: true },
  { key: 'marketing-assets', label: 'Marketing Assets', dropdown: true },
  { key: 'events', label: 'Events', dropdown: false },
  { key: 'sales-playbook', label: 'Sales Playbook', dropdown: false },
  { key: 'accounts', label: 'Accounts', dropdown: false },
  { key: 'company-documents', label: 'Company Documents', dropdown: false }
];

/** Props shared by page components. */
export interface IPageProps {
  /** First name of the signed-in user, highlighted in the Home hero. Empty when unknown. */
  firstName: string;
}
