import * as React from 'react';

import { Icon, c } from '../ui';
import { img } from '../images';

/** Pricing page. Layout and styling come from SalesHome.module.scss. */
const PricingPage: React.FC = () => (
  <>
    <div className={c('hero sm')}>
      <img className={c('art')} src={img.hero} alt="" />
      <div className={c('copy')}>
        <div className={c('cr')}>Home &nbsp;/&nbsp; Pricing</div>
        <h1>Pricing</h1>
        <p>Rate cards, quotation requests, minimums and discount approval rules for approved users.</p>
        <a className={c('btn')}>
          Request a quote
          {' '}
          <Icon n="arrowr" s={17} sw={2} />
        </a>
      </div>
      <div className={c('panel')}>
        <div className={c('fac')}>
          <div className={c('ib')}>
            <Icon n="lock" s={28} sw={1.5} />
          </div>
          <div>
            <b>Restricted Access</b>
            <span>Approved users only</span>
          </div>
          <div className={c('ch')}>
            <Icon n="chev" s={24} sw={2} />
          </div>
        </div>
        <div className={c('fac')}>
          <div className={c('ib')}>
            <Icon n="coins" s={28} sw={1.5} />
          </div>
          <div>
            <b>Quote Requests</b>
            <span>Submit for costing</span>
          </div>
          <div className={c('ch')}>
            <Icon n="chev" s={24} sw={2} />
          </div>
        </div>
      </div>
    </div>
    <div className={c('note')}>
      <Icon n="lock" s={22} sw={1.8} />
      <span>
        <b>Restricted section.</b>
        {' '}
        Visible to Sales leadership and approved reps only. Do not share pricing outside the approved group.
      </span>
    </div>
    <div className={c('tiles')} style={{ '--c': 'repeat(4,1fr)' } as React.CSSProperties}>
      <a className={c('tile sq')} style={{ background: '#f2eafc', color: '#5b1d72' } as React.CSSProperties}>
        <Icon n="coins" s={44} sw={1.5} />
        <b>Price Lists &amp; Rate Cards</b>
        <span>Current rates by category</span>
      </a>
      <a className={c('tile sq')} style={{ background: '#feeee2', color: '#6a2c60' } as React.CSSProperties}>
        <Icon n="send" s={44} sw={1.5} />
        <b>Quote &amp; Costing Requests</b>
        <span>Submit a request</span>
      </a>
      <a className={c('tile sq')} style={{ background: '#e5f1fe', color: '#3b4c93' } as React.CSSProperties}>
        <Icon n="clock" s={44} sw={1.5} />
        <b>MOQ &amp; Payment Terms</b>
        <span>Minimums &amp; terms</span>
      </a>
      <a className={c('tile sq')} style={{ background: '#e5f7f0', color: '#1a7757' } as React.CSSProperties}>
        <Icon n="check" s={44} sw={1.5} />
        <b>Discount Approval Rules</b>
        <span>Who approves what</span>
      </a>
    </div>
    <div className={c('row r2')} style={{ '--c': '1fr 1fr', marginTop: '22px' } as React.CSSProperties}>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="coins" s={22} sw={1.7} />
            Price Lists &amp; Rate Cards
          </h3>
          <a className={c('vl')}>View all</a>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#f2eafc', color: '#5b1d72' } as React.CSSProperties}>
            <Icon n="coins" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Skincare rate card Q4 2026</b>
            <span className={c('s')}>Updated Nov 2026 &middot; PDF</span>
          </div>
          <div className={c('ri')}>
            <span className={c('tag g')}>Current</span>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#feeee2', color: '#6a2c60' } as React.CSSProperties}>
            <Icon n="coins" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Haircare rate card Q4 2026</b>
            <span className={c('s')}>Updated Nov 2026 &middot; PDF</span>
          </div>
          <div className={c('ri')}>
            <span className={c('tag g')}>Current</span>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#e5f1fe', color: '#3b4c93' } as React.CSSProperties}>
            <Icon n="coins" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Color cosmetics rate card</b>
            <span className={c('s')}>Updated Oct 2026 &middot; XLSX</span>
          </div>
          <div className={c('ri')}>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#e5f7f0', color: '#1a7757' } as React.CSSProperties}>
            <Icon n="coins" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>OTC rate card Q4 2026</b>
            <span className={c('s')}>Updated Oct 2026 &middot; PDF</span>
          </div>
          <div className={c('ri')}>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
      </div>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="send" s={22} sw={1.7} />
            Quote &amp; Costing Request
          </h3>
        </div>
        <div className={c('field')}>
          <label>Customer name</label>
          <div>Enter customer</div>
        </div>
        <div className={c('two')} style={{ gap: '12px' } as React.CSSProperties}>
          <div className={c('field')}>
            <label>Product category</label>
            <div>Select category</div>
          </div>
          <div className={c('field')}>
            <label>Estimated quantity</label>
            <div>Units</div>
          </div>
        </div>
        <div className={c('field')}>
          <label>Target launch date</label>
          <div>Select date</div>
        </div>
        <div className={c('field')}>
          <label>Notes</label>
          <div style={{ height: '64px', alignItems: 'flex-start', paddingTop: '10px' } as React.CSSProperties}>Formula, packaging, claims…</div>
        </div>
        <a className={c('btn')} style={{ marginTop: '2px' } as React.CSSProperties}>
          Submit request
          {' '}
          <Icon n="send" s={16} sw={2} />
        </a>
      </div>
    </div>
    <div className={c('row r2')} style={{ '--c': '1.2fr 1fr', marginTop: '22px' } as React.CSSProperties}>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="clock" s={22} sw={1.7} />
            MOQ &amp; Payment Terms
          </h3>
        </div>
        <table>
          <tbody>
            <tr className={c('hd')}>
              <th>Category</th>
              <th>Standard MOQ</th>
              <th>Payment terms</th>
            </tr>
            <tr>
              <td data-label="Category">
                <b>Skincare</b>
              </td>
              <td data-label="Standard MOQ">Per customer agreement</td>
              <td data-label="Payment terms">Net terms per contract</td>
            </tr>
            <tr>
              <td data-label="Category">
                <b>Haircare</b>
              </td>
              <td data-label="Standard MOQ">Per customer agreement</td>
              <td data-label="Payment terms">Net terms per contract</td>
            </tr>
            <tr>
              <td data-label="Category">
                <b>Color cosmetics</b>
              </td>
              <td data-label="Standard MOQ">Per customer agreement</td>
              <td data-label="Payment terms">Net terms per contract</td>
            </tr>
            <tr>
              <td data-label="Category">
                <b>OTC</b>
              </td>
              <td data-label="Standard MOQ">Per customer agreement</td>
              <td data-label="Payment terms">Net terms per contract</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="check" s={22} sw={1.7} />
            Discount Approval Rules
          </h3>
        </div>
        <div className={c('steps')} style={{ '--c': 'repeat(3,1fr)' } as React.CSSProperties}>
          <div className={c('step')}>
            <i>1</i>
            <b>Sales rep</b>
            <span>Up to the standard threshold</span>
          </div>
          <div className={c('step')}>
            <i>2</i>
            <b>Sales Director</b>
            <span>Above standard threshold</span>
          </div>
          <div className={c('step')}>
            <i>3</i>
            <b>Finance &amp; leadership</b>
            <span>Exceptions and strategic deals</span>
          </div>
        </div>
      </div>
    </div>
  </>
);

export default PricingPage;
