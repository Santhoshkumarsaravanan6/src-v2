import * as React from 'react';

import { Icon, c } from '../ui';
import { img } from '../images';

/** Marketing Assets page. Layout and styling come from SalesHome.module.scss. */
const MarketingPage: React.FC = () => (
  <>
    <div className={c('hero sm')}>
      <img className={c('art')} src={img.hero} alt="" />
      <div className={c('copy')}>
        <div className={c('cr')}>Home &nbsp;/&nbsp; Marketing Assets</div>
        <h1>Marketing Assets</h1>
        <p>Approved decks, brand guidelines, photos, videos and trade show materials, always current.</p>
        <a className={c('btn')}>
          Download brand kit
          {' '}
          <Icon n="arrowr" s={17} sw={2} />
        </a>
      </div>
      <div className={c('panel')}>
        <div className={c('fac')}>
          <div className={c('ib')}>
            <Icon n="image" s={28} sw={1.5} />
          </div>
          <div>
            <b>Brand Assets</b>
            <span>Logos &amp; guidelines</span>
          </div>
          <div className={c('ch')}>
            <Icon n="chev" s={24} sw={2} />
          </div>
        </div>
        <div className={c('fac')}>
          <div className={c('ib')}>
            <Icon n="video" s={28} sw={1.5} />
          </div>
          <div>
            <b>Photos &amp; Videos</b>
            <span>Approved library</span>
          </div>
          <div className={c('ch')}>
            <Icon n="chev" s={24} sw={2} />
          </div>
        </div>
      </div>
    </div>
    <div className={c('tiles')} style={{ '--c': 'repeat(4,1fr)' } as React.CSSProperties}>
      <a className={c('tile sq')} style={{ background: '#f2eafc', color: '#5b1d72' } as React.CSSProperties}>
        <Icon n="file" s={44} sw={1.5} />
        <b>Decks &amp; One-Pagers</b>
        <span>Capabilities presentations</span>
      </a>
      <a className={c('tile sq')} style={{ background: '#feeee2', color: '#6a2c60' } as React.CSSProperties}>
        <Icon n="sparkle" s={44} sw={1.5} />
        <b>Logos &amp; Brand Guidelines</b>
        <span>Logo files &amp; usage rules</span>
      </a>
      <a className={c('tile sq')} style={{ background: '#e5f1fe', color: '#3b4c93' } as React.CSSProperties}>
        <Icon n="image" s={44} sw={1.5} />
        <b>Photos &amp; Videos</b>
        <span>Facility &amp; product media</span>
      </a>
      <a className={c('tile sq')} style={{ background: '#e5f7f0', color: '#1a7757' } as React.CSSProperties}>
        <Icon n="cal" s={44} sw={1.5} />
        <b>Trade Show Materials</b>
        <span>Booth &amp; print assets</span>
      </a>
    </div>
    <div className={c('sh')}>
      <h2>Photos &amp; Videos</h2>
      <span>Approved for customer use</span>
    </div>
    <div className={c('gal')}>
      <div>
        <img src={img.fac1} alt="" />
        <span>Hayward facility</span>
      </div>
      <div>
        <img src={img.fac2} alt="" />
        <span>Scottsdale facility</span>
      </div>
      <div>
        <img className={c('ct')} src={img.jar} alt="" />
        <span>Skincare hero</span>
      </div>
      <div>
        <img className={c('ct')} src={img.dropper} alt="" />
        <span>Serum close-up</span>
      </div>
      <div>
        <img className={c('ct')} src={img.tube} alt="" />
        <span>Tube &amp; packaging</span>
      </div>
      <div>
        <img className={c('ct')} src={img.flower} alt="" />
        <span>Botanical lifestyle</span>
      </div>
    </div>
    <div className={c('row r2')} style={{ '--c': '1.3fr 1fr', marginTop: '22px' } as React.CSSProperties}>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="file" s={22} sw={1.7} />
            Capabilities Decks &amp; One-Pagers
          </h3>
          <a className={c('vl')}>View all</a>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#f2eafc', color: '#5b1d72' } as React.CSSProperties}>
            <Icon n="file" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Allure capabilities deck</b>
            <span className={c('s')}>PowerPoint &middot; 32 slides</span>
          </div>
          <div className={c('ri')}>
            <span className={c('tag g')}>Current</span>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#feeee2', color: '#6a2c60' } as React.CSSProperties}>
            <Icon n="file" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Hayward facility one-pager</b>
            <span className={c('s')}>PDF &middot; 2 pages</span>
          </div>
          <div className={c('ri')}>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#e5f1fe', color: '#3b4c93' } as React.CSSProperties}>
            <Icon n="file" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Scottsdale facility one-pager</b>
            <span className={c('s')}>PDF &middot; 2 pages</span>
          </div>
          <div className={c('ri')}>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#e5f7f0', color: '#1a7757' } as React.CSSProperties}>
            <Icon n="file" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Innovation capabilities overview</b>
            <span className={c('s')}>PowerPoint &middot; 14 slides</span>
          </div>
          <div className={c('ri')}>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
      </div>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="sparkle" s={22} sw={1.7} />
            Logos &amp; Brand Guidelines
          </h3>
          <a className={c('vl')}>View all</a>
        </div>
        <img src={img.logo} style={{ height: '52px', margin: '2px 0 14px' } as React.CSSProperties} alt="" />
        <div style={{ fontSize: '13px', color: 'var(--mut)', marginBottom: '8px' } as React.CSSProperties}>Brand colors</div>
        <div className={c('sw')}>
          <div style={{ background: '#5b2e77' } as React.CSSProperties}>#5B2E77</div>
          <div style={{ background: '#7e4682' } as React.CSSProperties}>#7E4682</div>
          <div style={{ background: '#a26e9e' } as React.CSSProperties}>#A26E9E</div>
          <div style={{ background: '#f2e6ee', color: '#4a1f5c' } as React.CSSProperties}>#F2E6EE</div>
          <div style={{ background: '#fcedf4', color: '#4a1f5c' } as React.CSSProperties}>#FCEDF4</div>
        </div>
        <div style={{ display: 'flex', gap: '10px', marginTop: '14px' } as React.CSSProperties}>
          <a className={c('btn line')} style={{ margin: '0' } as React.CSSProperties}>Logo pack (SVG, PNG)</a>
          <a className={c('btn line')} style={{ margin: '0' } as React.CSSProperties}>Brand guidelines (PDF)</a>
        </div>
      </div>
    </div>
    <div className={c('row')} style={{ '--c': '1fr', marginTop: '22px' } as React.CSSProperties}>
      <div className={c('card')} style={{  } as React.CSSProperties}>
        <div className={c('ch')}>
          <h3>
            <Icon n="cal" s={22} sw={1.7} />
            Trade Show Booth Materials
          </h3>
          <a className={c('vl')}>View all</a>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#f2eafc', color: '#5b1d72' } as React.CSSProperties}>
            <Icon n="image" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Booth graphics, print-ready</b>
            <span className={c('s')}>Zip &middot; 180 MB</span>
          </div>
          <div className={c('ri')}>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#feeee2', color: '#6a2c60' } as React.CSSProperties}>
            <Icon n="file" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Brochure and handout set</b>
            <span className={c('s')}>PDF &middot; 6 files</span>
          </div>
          <div className={c('ri')}>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
        <div className={c('lr')}>
          <div className={c('th ph')} style={{ background: '#e5f1fe', color: '#3b4c93' } as React.CSSProperties}>
            <Icon n="cal" s={26} sw={1.5} />
          </div>
          <div className={c('g')}>
            <b>Booth setup guide</b>
            <span className={c('s')}>PDF &middot; 4 pages</span>
          </div>
          <div className={c('ri')}>
            <Icon n="dl" s={18} sw={1.6} />
          </div>
        </div>
      </div>
    </div>
  </>
);

export default MarketingPage;
