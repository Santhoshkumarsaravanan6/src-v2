import * as React from 'react';

import styles from './SalesHome.module.scss';
import { ICON_PATHS } from './icons';

const classMap: { [name: string]: string } = styles as unknown as { [name: string]: string };

/** Maps space-separated design class names to their CSS-module equivalents. */
export const c = (names: string): string =>
  names
    .split(' ')
    .map((n: string) => classMap[n])
    .filter((n: string | undefined) => !!n)
    .join(' ');

export interface IIconProps {
  /** Icon name from icons.ts */
  n: string;
  /** Size in px */
  s?: number;
  /** Stroke width */
  sw?: number;
}

/** Inline stroke icon. Colour follows the surrounding text colour (currentColor). */
export const Icon: React.FC<IIconProps> = ({ n, s = 22, sw = 1.7 }) => (
  <svg
    width={s}
    height={s}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth={sw}
    strokeLinecap="round"
    strokeLinejoin="round"
    aria-hidden="true"
    dangerouslySetInnerHTML={{ __html: ICON_PATHS[n] || '' }}
  />
);
