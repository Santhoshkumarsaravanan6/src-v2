import * as React from 'react';

import styles from './SalesHome.module.scss';
import { IconName } from './icons';
import {
  ActionTag, Calendar, Card, DateBadge, Grid, Hero, Icon, IconBox, Link, ListRow, SecHead, Tag, Wrap, cx
} from './ui';

/* --------------------------------------------------------------- Events */

const SHOWS: Array<[string, string, string, string, string]> = [
  ['02', 'Dec', 'Cosmoprof North America', 'Las Vegas, NV', 'Booth B214'],
  ['18', 'Jan', 'Premiere Orlando', 'Orlando, FL', 'Booth 920'],
  ['10', 'Mar', 'Cosmoprof Bologna', 'Bologna, Italy', 'Hall 14'],
  ['22', 'Apr', 'In-Cosmetics Global', 'Paris, France', 'Stand 5K40']
];

const PLAYBOOKS = ['Booth setup timeline', 'Staffing and shifts', 'Sample shipping checklist', 'Meeting scheduling guide'];

const LEAD_STEPS: Array<[string, string]> = [
  ['Capture', 'Scan badge or fill the lead form'],
  ['Qualify', 'Score the lead and tag category'],
  ['Assign', 'Route to the account owner'],
  ['Follow up', 'Send email within 48 hours']
];

const RECAPS: Array<[string, string]> = [
  ['Cosmoprof NA 2025 recap', '142 leads · 18 meetings'],
  ['Premiere Orlando 2025 recap', '64 leads · 9 meetings']
];

export const EventsPage: React.FC = () => (
  <Wrap>
    <Hero
      title="Events"
      sub="Trade show calendar, playbooks, lead capture and recaps."
      crumb="Sales  /  Events"
      stats={[['4', 'Upcoming shows']]}
      buttons={[['Capture a lead', 'primary']]}
    />
    <Grid cols="custom" style={{ gridTemplateColumns: '1.6fr 1fr', marginTop: 24, alignItems: 'start' }}>
      <Card>
        <h3 style={{ fontSize: 16, marginBottom: 14 }}>Trade show calendar</h3>
        {SHOWS.map(([d, m, title, place, booth]) => (
          <div className={styles.row} key={title}>
            <DateBadge day={d} month={m} />
            <div className={styles.grow}>
              <b style={{ fontSize: 14.5 }}>{title}</b>
              <span className={styles.s}>{place} &middot; {booth}</span>
            </div>
            <Tag>Confirmed</Tag>
          </div>
        ))}
      </Card>
      <Card>
        <h3 style={{ fontSize: 16, marginBottom: 10 }}>December 2026</h3>
        <Calendar highlight={[2, 3, 4]} />
      </Card>
    </Grid>

    <Grid cols="g2" style={{ marginTop: 8, alignItems: 'start' }}>
      <div>
        <SecHead title="Event playbooks and checklists" link="All playbooks" />
        <Card>
          {PLAYBOOKS.map(p => (
            <div className={styles.row} key={p}>
              <div className={cx(styles.ic, styles.dark)} style={{ width: 28, height: 28, borderRadius: '50%' }}>
                <Icon name="check" size={14} sw={2.4} />
              </div>
              <div className={styles.grow}><b>{p}</b></div>
            </div>
          ))}
        </Card>
      </div>
      <div>
        <SecHead title="Event recaps" link="All recaps" />
        <Card>
          {RECAPS.map(([a, b]) => (
            <ListRow key={a} icon="file" title={a} sub={b} right={<ActionTag label="Open" />} />
          ))}
        </Card>
      </div>
    </Grid>

    <SecHead title="Lead capture and follow-up" sub="From booth to booked meeting" />
    <Grid cols="g4">
      {LEAD_STEPS.map(([a, b], i) => (
        <Card key={a} style={{ textAlign: 'center' }}>
          <div className={styles.num} style={{ margin: '0 auto 10px' }}>{i + 1}</div>
          <b>{a}</b>
          <div className={styles.sub} style={{ marginTop: 4 }}>{b}</div>
        </Card>
      ))}
    </Grid>
  </Wrap>
);

/* ------------------------------------------------------- Sales Playbook */

const STAGES: Array<[string, string]> = [
  ['Discover', 'Identify the need and the buyer'],
  ['Qualify', 'Check volume, timeline and fit'],
  ['Propose', 'Share concepts, pricing and samples'],
  ['Negotiate', 'Agree MOQ, terms and schedule'],
  ['Win', 'Hand over to operations']
];

const BATTLE: Array<[string, string]> = [
  ['Versus offshore contract manufacturers', 'Compare on speed, quality and communication'],
  ['Versus in-house production', 'Cost of capacity and compliance'],
  ['Handling price objections', 'Value-based responses'],
  ['Handling MOQ objections', 'Alternatives and phased orders']
];

const TEMPLATES: Array<[string, string]> = [
  ['Introduction email', 'Email'],
  ['Follow-up after sample', 'Email'],
  ['Proposal template', 'Word'],
  ['Pricing summary slide', 'PPTX']
];

const ONBOARDING: Array<[string, string]> = [
  ['Week 1', 'Company, facilities and products'],
  ['Week 2', 'Sales process and tools'],
  ['Week 3', 'Shadow customer calls'],
  ['Week 4', 'First account plan']
];

export const PlaybookPage: React.FC = () => (
  <Wrap>
    <Hero
      title="Sales Playbook"
      sub="Our sales process, battle cards, templates and training for new reps."
      crumb="Sales  /  Sales Playbook"
    />
    <SecHead title="Sales process and qualification" sub="Five stages from first contact to win" />
    <Grid cols="custom" style={{ gridTemplateColumns: 'repeat(5,1fr)' }}>
      {STAGES.map(([a, b], i) => (
        <Card key={a} style={{ position: 'relative' }}>
          <div className={styles.num}>{i + 1}</div>
          <b style={{ display: 'block', margin: '12px 0 4px', fontSize: 15 }}>{a}</b>
          <div className={styles.sub}>{b}</div>
        </Card>
      ))}
    </Grid>

    <SecHead title="Battle cards and objection handling" link="All battle cards" />
    <Grid cols="g4">
      {BATTLE.map(([a, b]) => (
        <Card key={a}>
          <IconBox name="swords" variant="gold" />
          <b style={{ display: 'block', margin: '12px 0 4px' }}>{a}</b>
          <div className={styles.sub}>{b}</div>
          <Link style={{ display: 'inline-block', marginTop: 10, fontSize: 12, fontWeight: 600, color: '#1b365d' }}>Open battle card &rarr;</Link>
        </Card>
      ))}
    </Grid>

    <Grid cols="g2" style={{ alignItems: 'start' }}>
      <div>
        <SecHead title="Email and proposal templates" link="All templates" />
        <Card>
          {TEMPLATES.map(([a, b]) => (
            <ListRow key={a} icon="mail" title={a} sub={b} right={<ActionTag label="Copy" />} />
          ))}
        </Card>
      </div>
      <div>
        <SecHead title="New rep onboarding and training" sub="First 30 days" link="Training hub" />
        <Card>
          {ONBOARDING.map(([a, b]) => (
            <div className={styles.row} key={a}>
              <div className={styles.date} style={{ width: 64, fontSize: 12 }}>{a}</div>
              <div className={styles.grow}><b>{b}</b></div>
            </div>
          ))}
        </Card>
      </div>
    </Grid>
  </Wrap>
);

/* ------------------------------------------------------------- Accounts */

const ACCOUNTS: Array<{ name: string; cat: string; status: string; value: string; progress: number }> = [
  { name: 'Northwind Beauty', cat: 'Skincare', status: 'Active', value: '$2.4M', progress: 72 },
  { name: 'Bloom & Co', cat: 'Haircare', status: 'Active', value: '$1.8M', progress: 58 },
  { name: 'Aura Naturals', cat: 'OTC', status: 'Growing', value: '$1.2M', progress: 44 },
  { name: 'Lumen Cosmetics', cat: 'Color', status: 'Onboarding', value: '$0.6M', progress: 20 }
];

const QBRS: Array<[string, string]> = [
  ['Northwind Beauty QBR', 'Q3 2026'],
  ['Bloom & Co QBR', 'Q3 2026'],
  ['Aura Naturals QBR', 'Q2 2026']
];

export const AccountsPage: React.FC = () => (
  <Wrap>
    <Hero
      title="Accounts"
      sub="Account plans for key customers, QBR decks and a direct link to the CRM."
      crumb="Sales  /  Accounts"
      stats={[['4', 'Key accounts']]}
      buttons={[['Open the CRM', 'primary']]}
    />
    <SecHead title="Account plans for key customers" link="All accounts" />
    <Card flush>
      <table className={styles.tbl}>
        <thead>
          <tr>
            <th>Customer</th><th>Category</th><th>Status</th><th>Annual value</th><th>Plan progress</th><th />
          </tr>
        </thead>
        <tbody>
          {ACCOUNTS.map(a => (
            <tr key={a.name}>
              <td>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <div className={styles.pav} style={{ width: 34, height: 34, fontSize: 13, background: '#1b365d' }}>{a.name.charAt(0)}</div>
                  <b>{a.name}</b>
                </div>
              </td>
              <td>{a.cat}</td>
              <td><Tag tone={a.status === 'Onboarding' ? 'gold' : ''}>{a.status}</Tag></td>
              <td>{a.value}</td>
              <td style={{ width: 140 }}>
                <div className={styles.prog}><i style={{ width: `${a.progress}%` }} /></div>
              </td>
              <td><ActionTag label="Open plan" /></td>
            </tr>
          ))}
        </tbody>
      </table>
    </Card>

    <Grid cols="g21" style={{ alignItems: 'start' }}>
      <div>
        <SecHead title="QBR decks" link="All QBRs" />
        <Card>
          {QBRS.map(([a, b]) => (
            <ListRow key={a} icon="bar" title={a} sub={b} right={<ActionTag label="Open" />} />
          ))}
        </Card>
      </div>
      <div>
        <SecHead title="CRM" />
        <Card style={{ textAlign: 'center', padding: '28px 20px' }}>
          <IconBox name="users" variant="round" size={26} style={{ margin: '0 auto' }} />
          <b style={{ display: 'block', margin: '14px 0 6px', fontSize: 16 }}>Open the CRM</b>
          <div className={styles.sub}>Opens in a new tab</div>
          <Link className={cx(styles.btn, styles.solid)} style={{ marginTop: 16 }}>
            <Icon name="ext" size={14} /> Go to CRM
          </Link>
        </Card>
      </div>
    </Grid>
  </Wrap>
);

/* ---------------------------------------------------- Company Documents */

const PEOPLE: Array<[string, string, string]> = [
  ['Sales Director', 'Sales', '#1b365d'],
  ['Operations Lead', 'Hayward and Scottsdale', '#00589b'],
  ['Regulatory Lead', 'Compliance', '#3d7ab8'],
  ['Finance Contact', 'Pricing and approvals', '#4a6fa5']
];

const CONTRACTS: Array<[string, string]> = [
  ['NDA template', 'Word'],
  ['Master services agreement', 'Word'],
  ['Supply agreement', 'Word'],
  ['Quality agreement', 'Word']
];

const VENDOR_FORMS: Array<[string, string]> = [
  ['W-9', 'PDF'],
  ['Certificate of insurance', 'PDF'],
  ['Vendor setup form', 'PDF'],
  ['Banking details form', 'PDF']
];

const POLICIES: Array<[string, IconName]> = [
  ['Code of conduct', 'shield'],
  ['Information security', 'lock'],
  ['Travel and expense', 'dollar'],
  ['Confidentiality', 'file']
];

export const DocumentsPage: React.FC = () => (
  <Wrap>
    <Hero
      title="Company Documents"
      sub="Org chart, contracts, vendor forms and policies."
      crumb="Sales  /  Company Documents"
    />
    <Grid cols="custom" style={{ gridTemplateColumns: '1.2fr 1fr', marginTop: 24, alignItems: 'start' }}>
      <Card>
        <h3 style={{ fontSize: 16, marginBottom: 16 }}>Org chart</h3>
        <div className={styles.org}>
          <div className={styles.orgbox}>Leadership<small>Executive team</small></div>
          <div className={styles.vline} />
          <div className={styles.hline} />
          <div style={{ display: 'flex', justifyContent: 'space-between', width: '66%' }}>
            <div className={styles.vline} /><div className={styles.vline} /><div className={styles.vline} />
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', width: '80%', gap: 10 }}>
            <div className={cx(styles.orgbox, styles.l)}>Sales<small>Business development</small></div>
            <div className={cx(styles.orgbox, styles.l)}>Operations<small>Hayward &amp; Scottsdale</small></div>
            <div className={cx(styles.orgbox, styles.l)}>Finance<small>Pricing and approvals</small></div>
          </div>
        </div>
      </Card>
      <Grid cols="g2">
        {PEOPLE.map(([name, role, color]) => (
          <div className={cx(styles.card, styles.person)} key={name}>
            <div className={styles.pav} style={{ background: color }}>{name.charAt(0)}</div>
            <b>{name}</b>
            <div className={styles.sub}>{role}</div>
            <Link className={styles.tag}><Icon name="mail" size={11} sw={2} /> Contact</Link>
          </div>
        ))}
      </Grid>
    </Grid>

    <Grid cols="g2" style={{ alignItems: 'start' }}>
      <div>
        <SecHead title="NDA, MSA and contract templates" link="All templates" />
        <Card>
          {CONTRACTS.map(([a, b]) => (
            <ListRow key={a} icon="file" title={a} sub={b} right={<ActionTag label="Download" />} />
          ))}
        </Card>
      </div>
      <div>
        <SecHead title="W-9, COI and vendor forms" link="All forms" />
        <Card>
          {VENDOR_FORMS.map(([a, b]) => (
            <ListRow key={a} icon="clip" title={a} sub={b} right={<ActionTag label="Download" />} />
          ))}
        </Card>
      </div>
    </Grid>

    <SecHead title="Policies" link="All policies" />
    <Grid cols="g4">
      {POLICIES.map(([name, icon]) => (
        <Card key={name} style={{ textAlign: 'center' }}>
          <IconBox name={icon} variant="round" style={{ margin: '0 auto 10px' }} />
          <b>{name}</b>
        </Card>
      ))}
    </Grid>
  </Wrap>
);
