import * as React from 'react';

import styles from './SalesHome.module.scss';
import { IconName } from './icons';
import {
  ActionTag, Card, Grid, Hero, Icon, IconBox, Link, ListRow, MediaCard, SecHead, Tag, Thumb, Tone, Wrap
} from './ui';

/* -------------------------------------------------------------- Pricing */

const PRICE_LISTS: Array<[string, string]> = [
  ['Skincare price list', 'Updated 02 Nov 2026'],
  ['Haircare price list', 'Updated 28 Oct 2026'],
  ['OTC rate card', 'Updated 20 Oct 2026'],
  ['Color rate card', 'Updated 15 Oct 2026']
];

const TERMS: Array<[string, string, string]> = [
  ['5,000', 'Skincare MOQ (units)', 'Per SKU, per production run'],
  ['10,000', 'Haircare MOQ (units)', 'Per SKU, per production run'],
  ['Net 30', 'Standard payment terms', 'Deposit required on first order']
];

const APPROVALS: Array<[string, string]> = [
  ['Less than 5%', 'Sales rep approves'],
  ['5% to 10%', 'Sales manager approves'],
  ['Above 10%', 'VP Sales and Finance approve']
];

export const PricingPage: React.FC = () => (
  <Wrap>
    <Hero
      title="Pricing"
      sub="Price lists, quote requests, minimums and discount rules."
      crumb="Sales  /  Pricing"
      chip="Restricted: visible to Sales leadership and Finance only"
      buttons={[['Request a quote', 'primary'], ['Costing request', 'ghost']]}
    />
    <div style={{ height: 18 }} />
    <div className={styles.banner}>
      <Icon name="lock" size={20} />
      <div><b>Restricted section.</b> Access is limited to approved groups. Request access from the site owner.</div>
    </div>

    <Grid cols="g21" style={{ marginTop: 22, alignItems: 'start' }}>
      <div>
        <SecHead title="Price lists and rate cards" link="All price lists" />
        <Card>
          {PRICE_LISTS.map(([a, b]) => (
            <ListRow key={a} icon="dollar" title={a} sub={b} right={<ActionTag label="Download" />} />
          ))}
        </Card>
      </div>
      <div>
        <SecHead title="Quote and costing requests" />
        <Card style={{ background: '#1b365d', color: '#fff', border: 0 }}>
          <Icon name="clip" size={30} />
          <h3 style={{ fontSize: 17, margin: '12px 0 6px' }}>Start a new request</h3>
          <div style={{ fontSize: 13, opacity: 0.85, lineHeight: 1.5 }}>
            Submit a quote or costing request. It routes to Finance for approval.
          </div>
          <Link className={styles.btn} style={{ marginTop: 16 }}>Open request form</Link>
          <div style={{ marginTop: 18, paddingTop: 14, borderTop: '1px solid rgba(255,255,255,.2)', fontSize: 12, opacity: 0.85 }}>
            3 requests pending &middot; avg. turnaround 2 days
          </div>
        </Card>
      </div>
    </Grid>

    <SecHead title="MOQ and payment terms guidelines" />
    <Grid cols="g3">
      {TERMS.map(([a, b, c]) => (
        <Card key={b}>
          <div className={styles.stat}>{a}<small>{b}</small></div>
          <div className={styles.sub} style={{ marginTop: 8 }}>{c}</div>
        </Card>
      ))}
    </Grid>

    <SecHead title="Discount approval rules" sub="Who approves what" />
    <Grid cols="g3">
      {APPROVALS.map(([a, b], i) => (
        <Card key={a} style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
          <div className={styles.num}>{i + 1}</div>
          <div><b>{a}</b><div className={styles.sub}>{b}</div></div>
        </Card>
      ))}
    </Grid>
  </Wrap>
);

/* ----------------------------------------------------------- Regulatory */

const STANDARDS: Array<[string, Tone]> = [
  ['Credo Clean Standard', 1],
  ['Sephora Clean', 4],
  ['Target Clean', 3],
  ['Ulta Conscious', 5]
];

const RSL: Array<[string, string, string]> = [
  ['Restricted substances list: EU', 'Version 4.2', 'Mar 2026'],
  ['Restricted substances list: US retailers', 'Version 3.8', 'Oct 2026'],
  ['Prop 65 reference', 'Version 2.1', 'Jul 2026']
];

const GUIDES: Array<{ icon: IconName; title: string; desc: string }> = [
  { icon: 'file', title: 'OTC / FDA guidance', desc: 'Monograph rules, drug facts labels and registration' },
  { icon: 'clip', title: 'MoCRA compliance', desc: 'Facility registration, listing and safety substantiation' },
  { icon: 'edit', title: 'Labeling basics', desc: 'Claims, INCI and net content requirements' }
];

const QUESTIONNAIRES: Array<[string, string]> = [
  ['Standard customer questionnaire', 'Word'],
  ['Ingredient disclosure form', 'Excel'],
  ['Facility compliance statement', 'PDF']
];

export const RegulatoryPage: React.FC = () => (
  <Wrap>
    <Hero
      title="Regulatory"
      sub="Retailer clean standards, restricted substances, FDA and MoCRA guidance and questionnaire templates."
      crumb="Sales  /  Regulatory"
      stats={[['4', 'Retailer standards'], ['3', 'Guides']]}
    />
    <SecHead title="Clean standards" sub="Retailer requirements at a glance" link="All standards" />
    <Grid cols="g4">
      {STANDARDS.map(([name, tone]) => (
        <Card flush key={name}>
          <Thumb tone={tone} icon="shield" size={34} style={{ height: 90 }} />
          <div className={styles.body}>
            <b>{name}</b>
            <div className={styles.sub} style={{ margin: '3px 0 10px' }}>Retailer clean-beauty list</div>
            <Tag>Updated 2026</Tag>
          </div>
        </Card>
      ))}
    </Grid>

    <SecHead title="Restricted substances lists" link="All lists" />
    <Card flush>
      <table className={styles.tbl}>
        <thead>
          <tr><th>List</th><th>Version</th><th>Updated</th><th /></tr>
        </thead>
        <tbody>
          {RSL.map(([a, b, c]) => (
            <tr key={a}>
              <td><b>{a}</b></td><td>{b}</td><td>{c}</td><td><ActionTag label="Download" /></td>
            </tr>
          ))}
        </tbody>
      </table>
    </Card>

    <SecHead title="OTC / FDA and MoCRA guidance" link="All guidance" />
    <Grid cols="g3">
      {GUIDES.map(g => (
        <Card key={g.title}>
          <IconBox name={g.icon} size={24} />
          <b style={{ display: 'block', margin: '14px 0 4px', fontSize: 15 }}>{g.title}</b>
          <div className={styles.sub}>{g.desc}</div>
          <Link style={{ display: 'inline-block', marginTop: 12, fontSize: 12, fontWeight: 600, color: '#1b365d' }}>Read guidance &rarr;</Link>
        </Card>
      ))}
    </Grid>

    <SecHead title="Customer questionnaire templates" sub="Pre-approved answers speed up customer reviews" link="All templates" />
    <Card>
      {QUESTIONNAIRES.map(([a, b]) => (
        <ListRow key={a} icon="clip" title={a} sub={b} right={<ActionTag label="Download" />} />
      ))}
    </Card>
  </Wrap>
);

/* ------------------------------------------------------------ Marketing */

const DECK_CARDS: Array<[string, string, Tone]> = [
  ['Capabilities deck', '24 slides · PPTX', 1],
  ['Skincare one-pager', 'PDF', 2],
  ['Haircare one-pager', 'PDF', 3],
  ['OTC one-pager', 'PDF', 4]
];

const BRAND: Array<{ icon: IconName; title: string; sub: string }> = [
  { icon: 'palette', title: 'Logo pack', sub: 'SVG, PNG · light and dark' },
  { icon: 'book', title: 'Brand guidelines', sub: 'PDF · 32 pages' },
  { icon: 'edit', title: 'Color and type', sub: 'Palette and font files' }
];

const GALLERY: Array<[Tone, IconName]> = [
  [1, 'image'], [2, 'image'], [3, 'video'], [4, 'image'], [5, 'image'], [6, 'video'], [2, 'image'], [1, 'video']
];

const BOOTH: Array<[string, string]> = [
  ['Booth graphics', 'Print-ready files'],
  ['Banner stands', 'Specs and templates'],
  ['Giveaways', 'Approved items list']
];

export const MarketingPage: React.FC = () => (
  <Wrap>
    <Hero
      title="Marketing Assets"
      sub="Approved decks, brand files, photography and trade show materials."
      crumb="Sales  /  Marketing Assets"
      stats={[['48', 'Assets']]}
    />
    <SecHead title="Capabilities decks and one-pagers" link="All decks" />
    <Grid cols="g4">
      {DECK_CARDS.map(([title, sub, tone]) => (
        <MediaCard key={title} tone={tone} icon="file" title={title} sub={sub} />
      ))}
    </Grid>

    <SecHead title="Logos and brand guidelines" />
    <Grid cols="g3">
      {BRAND.map(b => (
        <Card key={b.title} style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
          <IconBox name={b.icon} variant="gold" size={24} />
          <div className={styles.grow}><b>{b.title}</b><div className={styles.sub}>{b.sub}</div></div>
          <ActionTag label="Download" />
        </Card>
      ))}
    </Grid>

    <SecHead title="Photos and videos" sub="Facility, product and process imagery" link="Open gallery" />
    <Grid cols="custom" style={{ gridTemplateColumns: 'repeat(4,1fr)', gap: 12 }}>
      {GALLERY.map(([tone, icon], i) => (
        <Thumb key={i} tone={tone} icon={icon} size={30} style={{ height: 110, borderRadius: 10 }} />
      ))}
    </Grid>

    <SecHead title="Trade show booth materials" link="All materials" />
    <Card>
      {BOOTH.map(([a, b]) => (
        <ListRow key={a} icon="box" title={a} sub={b} right={<ActionTag label="Open" />} />
      ))}
    </Card>
  </Wrap>
);
