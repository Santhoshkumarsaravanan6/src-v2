import * as React from 'react';

import styles from './SalesHome.module.scss';
import { ISalesHomeProps } from './ISalesHomeProps';
import { Icon, Link, cx } from './ui';
import { PageKey, CapabilitiesPage, HomePage, InnovationPage } from './pagesA';
import { MarketingPage, PricingPage, RegulatoryPage } from './pagesB';
import { AccountsPage, DocumentsPage, EventsPage, PlaybookPage } from './pagesC';

interface INavItem {
  key: PageKey;
  label: string;
  restricted?: boolean;
}

const NAV: INavItem[] = [
  { key: 'home', label: 'Home' },
  { key: 'capabilities', label: 'Capabilities' },
  { key: 'innovation', label: 'Innovation' },
  { key: 'pricing', label: 'Pricing', restricted: true },
  { key: 'regulatory', label: 'Regulatory' },
  { key: 'marketing', label: 'Marketing Assets' },
  { key: 'events', label: 'Events' },
  { key: 'playbook', label: 'Sales Playbook' },
  { key: 'accounts', label: 'Accounts' },
  { key: 'documents', label: 'Company Documents' }
];

const initialsOf = (name: string): string => {
  const parts: string[] = name.split(' ').filter(p => p.length > 0);
  if (parts.length === 0) {
    return 'S';
  }
  return (parts[0].charAt(0) + (parts.length > 1 ? parts[parts.length - 1].charAt(0) : '')).toUpperCase();
};

const SalesHome: React.FC<ISalesHomeProps> = ({ userDisplayName }) => {
  const [page, setPage] = React.useState<PageKey>('home');
  const rootRef = React.useRef<HTMLDivElement>(null);

  const go = React.useCallback((next: PageKey): void => {
    setPage(next);
    if (rootRef.current) {
      rootRef.current.scrollIntoView({ block: 'start' });
    }
  }, []);

  const firstName: string = userDisplayName ? userDisplayName.split(' ')[0] : 'Sales Team';

  let content: React.ReactNode;
  switch (page) {
    case 'capabilities': content = <CapabilitiesPage />; break;
    case 'innovation': content = <InnovationPage />; break;
    case 'pricing': content = <PricingPage />; break;
    case 'regulatory': content = <RegulatoryPage />; break;
    case 'marketing': content = <MarketingPage />; break;
    case 'events': content = <EventsPage />; break;
    case 'playbook': content = <PlaybookPage />; break;
    case 'accounts': content = <AccountsPage />; break;
    case 'documents': content = <DocumentsPage />; break;
    default: content = <HomePage firstName={firstName} go={go} />;
  }

  return (
    <div className={styles.root} ref={rootRef}>
      <div className={styles.top}>
        <div className={styles.topIn}>
          <div className={styles.brand}>
            <div className={styles.logo}>S</div>
            <div>
              <b>Sales</b>
              <span>Allure Labs</span>
            </div>
          </div>
          <div className={styles.tools}>
            <div className={styles.search}>
              <Icon name="search" size={15} /> Search this site
            </div>
            <div className={styles.avatar}><Icon name="bell" size={16} /></div>
            <div className={styles.avatar}>{initialsOf(userDisplayName)}</div>
          </div>
        </div>
      </div>

      <nav className={styles.nav} aria-label="Sales sections">
        <div className={styles.navIn}>
          {NAV.map(item => (
            <Link
              key={item.key}
              className={cx(page === item.key && styles.on)}
              onClick={(): void => go(item.key)}
            >
              {item.label}
              {item.restricted && <Icon name="lock" size={12} sw={2} />}
            </Link>
          ))}
        </div>
      </nav>

      {content}

      <div className={styles.foot}>
        <span>Sample content for design review only. Final wording, images and links to be confirmed with the client.</span>
        <span>Sales Hub &middot; Allure Labs</span>
      </div>
    </div>
  );
};

export default SalesHome;
