import { SPHttpClient, type SPHttpClientResponse } from '@microsoft/sp-http';

import { LIBRARY, LISTS, listDef, type IFieldDef, type IListDef } from './lists';
import { NEW_GROUPS, SEED, seedKey } from './seed';
import type { FieldValues, IDataService, IItem, ILibFile, ListKey } from './types';

const VERBOSE: { [name: string]: string } = {
  'Accept': 'application/json;odata=verbose',
  'Content-Type': 'application/json;odata=verbose',
  'odata-version': ''
};

interface IVerboseList { d: { results?: IItem[]; ListItemEntityTypeFullName?: string } }
interface IVerboseFileItem { Id: number; FileRef: string; FileLeafRef: string; FileSizeDisplay?: string; Modified: string; HubSection?: string; HubGroup?: string }

const MAX_BYTES: number = 100 * 1024 * 1024;
/** Characters SharePoint does not allow in file names. */
const cleanName = (name: string): string => name.replace(/[~"#%&*:<>?/\\{|}]/g, '-').replace(/\s+/g, ' ').replace(/^[. ]+|[. ]+$/g, '').slice(0, 120) || 'file';
/** The few things the hub needs from a response, so both SPHttpClient and the browser's fetch can be checked the same way. */
interface IReply { ok: boolean; status: number; json(): Promise<unknown> }
const odata = (v: string): string => `'${encodeURIComponent(v.replace(/'/g, "''"))}'`;

/** Reads and writes the Sales Hub lists of the current site through the SharePoint REST API. */
export class SpDataService implements IDataService {
  public readonly persistent: boolean = true;
  public readonly supportsFiles: boolean = true;
  public readonly libraryUrl: string;
  /** Problems that did not stop the hub from opening (for example sample content that could not be written). */
  public warnings: string[] = [];

  private _http: SPHttpClient;
  private _fetch: typeof fetch;
  private _web: string;
  private _types: { [key: string]: string } = {};

  public constructor(http: SPHttpClient, webUrl: string, fetchFn?: typeof fetch) {
    this._http = http;
    this._fetch = fetchFn || ((input: RequestInfo | URL, init?: RequestInit): Promise<Response> => window.fetch(input, init));
    this._web = webUrl.replace(/\/$/, '');
    this.libraryUrl = `${this._web}/${LIBRARY.title}`;
  }

  public async init(): Promise<void> {
    const created: boolean[] = await Promise.all(LISTS.map((def: IListDef) => this._ensure(def)));
    // Lists made by an earlier version may lack newer columns.
    await Promise.all(LISTS.map((def: IListDef, i: number) => (created[i] ? Promise.resolve() : this._addMissingFields(this._list(def), def.fields, def.title))));
    await this._ensureLibrary();
    await this._syncSeeds(created);
  }

  /**
   * Writes the sample content. A "seeded:<list>" row in SH_Resources records that a list has been filled, so an
   * interrupted first load carries on where it stopped and a finished one is never filled again.
   */
  private async _syncSeeds(created: boolean[]): Promise<void> {
    const resources: IItem[] = await this.getAll('resources');
    const marks: string[] = resources.filter((r: IItem) => (r as { Section?: string }).Section === 'meta').map((r: IItem) => r.Title);
    for (let i: number = 0; i < LISTS.length; i++) {
      const def: IListDef = LISTS[i];
      const marker: string = `seeded:${def.key}`;
      if (marks.indexOf(marker) >= 0) {
        continue;
      }
      const existing: IItem[] = (def.key === 'resources' ? resources : await this.getAll(def.key))
        .filter((r: IItem) => (r as { Section?: string }).Section !== 'meta');
      let rows: FieldValues[] = SEED[def.key];
      const fullSeed: boolean = created[i] || marks.indexOf(`seeding:${def.key}`) >= 0;
      if (!fullSeed && existing.length > 0) {
        // A list from an earlier version already holds real content: only add what is new, never refill it.
        rows = def.key === 'resources' && existing.length < 40 ? rows : (def.key === 'resources' ? rows.filter((r: FieldValues) => NEW_GROUPS.indexOf(String(r.Group)) >= 0) : []);
      }
      if (fullSeed && marks.indexOf(`seeding:${def.key}`) < 0) {
        // Note that a complete first fill is under way, so an interrupted one is finished next time instead of mistaken for an older site.
        await this.add('resources', { Title: `seeding:${def.key}`, Section: 'meta', Group: 'seed', SortOrder: 0 });
      }
      const have: string[] = existing.map((r: IItem) => seedKey(def.key, r as unknown as FieldValues));
      // Sample rows may share a key (several stats called '—'), so each existing row cancels out only one sample row.
      const todo: FieldValues[] = rows.filter((r: FieldValues) => {
        const at: number = have.indexOf(seedKey(def.key, r));
        if (at >= 0) {
          have.splice(at, 1);
          return false;
        }
        return true;
      });
      let failed: number = 0;
      let firstError: string = '';
      for (let k: number = 0; k < todo.length; k += 6) {
        await Promise.all(todo.slice(k, k + 6).map((row: FieldValues) => this.add(def.key, row).catch((e: Error) => { failed++; firstError = firstError || e.message; })));
      }
      if (failed) {
        // Leave the marker off so the next visit tries the missing rows again.
        this.warnings.push(`${failed} sample item${failed === 1 ? '' : 's'} could not be added to ${def.title}. ${firstError}`);
      } else {
        await this.add('resources', { Title: marker, Section: 'meta', Group: 'seed', SortOrder: 0 });
      }
    }
  }

  public async isMemberOf(groupTitle: string): Promise<boolean> {
    const me: SPHttpClientResponse = await this._http.get(`${this._web}/_api/web/currentuser?$select=IsSiteAdmin`, SPHttpClient.configurations.v1, { headers: VERBOSE });
    await this._check(me, 'read your account');
    if (((await me.json()) as { d: { IsSiteAdmin: boolean } }).d.IsSiteAdmin) {
      return true;
    }
    const res: SPHttpClientResponse = await this._http.get(`${this._web}/_api/web/currentuser/groups?$select=Title`, SPHttpClient.configurations.v1, { headers: VERBOSE });
    await this._check(res, 'read your groups');
    const titles: string[] = (((await res.json()) as { d: { results?: Array<{ Title: string }> } }).d.results || []).map((g: { Title: string }) => g.Title.toLowerCase());
    return titles.indexOf(groupTitle.trim().toLowerCase()) >= 0;
  }

  /* ---------- files in the SH_Documents library ---------- */

  public async listFiles(): Promise<ILibFile[]> {
    const res: SPHttpClientResponse = await this._http.get(
      `${this._lib()}/items?$select=Id,FileRef,FileLeafRef,FileSizeDisplay,Modified,HubSection,HubGroup&$filter=FSObjType eq 0&$top=2000&$orderby=Modified desc`,
      SPHttpClient.configurations.v1, { headers: VERBOSE });
    await this._check(res, 'read the document library');
    const json: { d: { results?: IVerboseFileItem[] } } = (await res.json()) as { d: { results?: IVerboseFileItem[] } };
    return (json.d.results || []).map((r: IVerboseFileItem) => this._toFile(r));
  }

  public async uploadFile(file: File, section: string, group: string): Promise<ILibFile> {
    if (file.size > MAX_BYTES) {
      throw new Error('That file is larger than 100 MB. Add it to the SH_Documents library in SharePoint, then choose it from the list.');
    }
    const root: string = await this._step('find the library folder', () => this._libRoot());
    const taken: string[] = await this._step('check the existing file names', async () => (await this.listFiles()).map((f: ILibFile) => f.Name.toLowerCase()));
    const base: string = cleanName(file.name);
    const dot: number = base.lastIndexOf('.');
    const stem: string = dot > 0 ? base.slice(0, dot) : base;
    const ext: string = dot > 0 ? base.slice(dot) : '';
    let name: string = base;
    for (let n: number = 2; taken.indexOf(name.toLowerCase()) >= 0; n++) {
      name = `${stem} (${n})${ext}`;
    }
    const buffer: ArrayBuffer = await this._step('read the file', () => file.arrayBuffer());
    await this._step('send the file', () => this._sendBinary(root, name, buffer));
    const path: string = `${root}/${name}`;
    // Record where the file was added from; failing here only means the hub will never delete it automatically.
    try {
      await this._http.post(`${this._web}/_api/web/GetFileByServerRelativeUrl(@u)/ListItemAllFields/ValidateUpdateListItem?@u=${odata(path)}`,
        SPHttpClient.configurations.v1, {
          headers: VERBOSE,
          body: JSON.stringify({ formValues: [{ FieldName: 'HubSection', FieldValue: section }, { FieldName: 'HubGroup', FieldValue: group }], bNewDocumentUpdate: true })
        });
    } catch {
      // ignore
    }
    const found: ILibFile | undefined = (await this._step('find the uploaded file', () => this.listFiles())).filter((f: ILibFile) => f.Name === name)[0];
    if (!found) {
      throw new Error('The file was uploaded but could not be found in the library.');
    }
    return found;
  }

  /**
   * Sends the file with the browser's own fetch. SPHttpClient adds JSON handling that a binary body does not
   * fit (it fails with "jsonRequest is enabled ... OData-Version"), so only the security token comes from it.
   */
  private async _sendBinary(root: string, name: string, buffer: ArrayBuffer): Promise<void> {
    const info: SPHttpClientResponse = await this._http.post(`${this._web}/_api/contextinfo`, SPHttpClient.configurations.v1, { headers: VERBOSE });
    await this._check(info, 'get a security token');
    const digest: string = ((await info.json()) as { d: { GetContextWebInformation: { FormDigestValue: string } } }).d.GetContextWebInformation.FormDigestValue;
    const res: Response = await this._fetch(
      `${this._web}/_api/web/GetFolderByServerRelativeUrl(@f)/Files/add(url=@n,overwrite=false)?@f=${odata(root)}&@n=${odata(name)}`,
      { method: 'POST', credentials: 'same-origin', headers: { 'Accept': 'application/json;odata=verbose', 'Content-Type': 'application/octet-stream', 'X-RequestDigest': digest }, body: buffer });
    await this._check(res, 'upload the file');
  }

  private async _step<T>(label: string, run: () => Promise<T>): Promise<T> {
    try {
      return await run();
    } catch (e) {
      throw new Error(`Upload failed while trying to ${label}: ${e instanceof Error ? e.message : String(e)}`);
    }
  }

  public async renameFile(id: number, newName: string): Promise<void> {
    const item: IVerboseFileItem = await this._fileItem(id);
    const dot: number = item.FileLeafRef.lastIndexOf('.');
    let name: string = cleanName(newName);
    if (dot > 0 && name.toLowerCase().indexOf(item.FileLeafRef.slice(dot).toLowerCase()) < 0) {
      name += item.FileLeafRef.slice(dot);
    }
    if (name === item.FileLeafRef) {
      return;
    }
    const folder: string = item.FileRef.slice(0, item.FileRef.lastIndexOf('/'));
    const res: SPHttpClientResponse = await this._http.post(
      `${this._web}/_api/web/GetFileByServerRelativeUrl(@u)/moveto(newurl=@n,flags=0)?@u=${odata(item.FileRef)}&@n=${odata(folder + '/' + name)}`,
      SPHttpClient.configurations.v1, { headers: VERBOSE });
    await this._check(res, 'rename the file (a file with that name may already exist)');
  }

  public async deleteFile(id: number): Promise<void> {
    const item: IVerboseFileItem = await this._fileItem(id);
    const res: SPHttpClientResponse = await this._http.post(
      `${this._web}/_api/web/GetFileByServerRelativeUrl(@u)/recycle()?@u=${odata(item.FileRef)}`, SPHttpClient.configurations.v1, { headers: VERBOSE });
    await this._check(res, 'delete the file');
  }

  private _lib(): string {
    return `${this._web}/_api/web/lists/getbytitle('${LIBRARY.title}')`;
  }

  private _toFile(r: IVerboseFileItem): ILibFile {
    const origin: string = (/^https?:\/\/[^/]+/i.exec(this._web) || [''])[0];
    return { Id: r.Id, Name: r.FileLeafRef, Url: origin + r.FileRef, Size: Number(r.FileSizeDisplay) || 0, Modified: r.Modified, Section: r.HubSection || '', Group: r.HubGroup || '' };
  }

  private async _fileItem(id: number): Promise<IVerboseFileItem> {
    const res: SPHttpClientResponse = await this._http.get(`${this._lib()}/items(${id})?$select=Id,FileRef,FileLeafRef`, SPHttpClient.configurations.v1, { headers: VERBOSE });
    await this._check(res, 'find the file in the library');
    return ((await res.json()) as { d: IVerboseFileItem }).d;
  }

  private _rootCache: string = '';
  private async _libRoot(): Promise<string> {
    if (!this._rootCache) {
      const res: SPHttpClientResponse = await this._http.get(`${this._lib()}/RootFolder?$select=ServerRelativeUrl`, SPHttpClient.configurations.v1, { headers: VERBOSE });
      await this._check(res, 'open the document library');
      this._rootCache = ((await res.json()) as { d: { ServerRelativeUrl: string } }).d.ServerRelativeUrl;
    }
    return this._rootCache;
  }

  private async _ensureLibrary(): Promise<void> {
    const probe: SPHttpClientResponse = await this._http.get(`${this._lib()}?$select=Id`, SPHttpClient.configurations.v1, { headers: VERBOSE });
    if (!probe.ok) {
      if (probe.status !== 404) {
        await this._check(probe, 'open the document library');
      }
      const created: SPHttpClientResponse = await this._http.post(`${this._web}/_api/web/lists`, SPHttpClient.configurations.v1, {
        headers: VERBOSE,
        body: JSON.stringify({ __metadata: { type: 'SP.List' }, AllowContentTypes: true, BaseTemplate: 101, ContentTypesEnabled: false, Description: LIBRARY.description, Title: LIBRARY.title })
      });
      if (!created.ok) {
        const again: SPHttpClientResponse = await this._http.get(`${this._lib()}?$select=Id`, SPHttpClient.configurations.v1, { headers: VERBOSE });
        if (!again.ok) {
          await this._check(created, 'create the document library ' + LIBRARY.title + '. Ask a site owner to open the Sales Hub once');
        }
      }
    }
    await this._addMissingFields(this._lib(), LIBRARY.fields, LIBRARY.title);
  }

  private async _addMissingFields(listUrl: string, fields: IFieldDef[], title: string): Promise<void> {
    const res: SPHttpClientResponse = await this._http.get(`${listUrl}/fields?$select=InternalName`, SPHttpClient.configurations.v1, { headers: VERBOSE });
    await this._check(res, 'read the columns of ' + title);
    const have: string[] = (((await res.json()) as { d: { results?: Array<{ InternalName: string }> } }).d.results || []).map((f: { InternalName: string }) => f.InternalName);
    for (const f of fields) {
      if (have.indexOf(f.name) < 0) {
        await this._createField(listUrl, f, title);
      }
    }
  }

  private async _createField(listUrl: string, f: IFieldDef, title: string): Promise<void> {
    const xml: string = f.kind === 'Note'
      ? `<Field Type="Note" DisplayName="${f.name}" Name="${f.name}" StaticName="${f.name}" NumLines="6" RichText="FALSE" />`
      : f.kind === 'Number'
        ? `<Field Type="Number" DisplayName="${f.name}" Name="${f.name}" StaticName="${f.name}" />`
        : `<Field Type="Text" DisplayName="${f.name}" Name="${f.name}" StaticName="${f.name}" MaxLength="255" />`;
    const res: SPHttpClientResponse = await this._http.post(`${listUrl}/fields/createfieldasxml`, SPHttpClient.configurations.v1, {
      headers: VERBOSE,
      body: JSON.stringify({ parameters: { __metadata: { type: 'SP.XmlSchemaFieldCreationInformation' }, SchemaXml: xml, Options: 24 } })
    });
    await this._check(res, `add the column ${f.name} to ${title}`);
  }

  public async getAll(key: ListKey): Promise<IItem[]> {
    const def: IListDef = listDef(key);
    const select: string = ['Id', 'Title', 'Created'].concat(def.fields.map((f: IFieldDef) => f.name)).join(',');
    const res: SPHttpClientResponse = await this._http.get(
      `${this._list(def)}/items?$select=${select}&$top=2000&$orderby=Id`, SPHttpClient.configurations.v1, { headers: VERBOSE });
    await this._check(res, 'read ' + def.title);
    const json: IVerboseList = (await res.json()) as IVerboseList;
    return (json.d.results || []).map((r: IItem) => this._normalise(def, r));
  }

  public async add(key: ListKey, values: FieldValues): Promise<void> {
    const def: IListDef = listDef(key);
    const type: string = await this._itemType(def);
    const res: SPHttpClientResponse = await this._http.post(`${this._list(def)}/items`, SPHttpClient.configurations.v1, {
      headers: VERBOSE, body: JSON.stringify({ __metadata: { type }, ...values })
    });
    await this._check(res, 'add to ' + def.title);
  }

  public async update(key: ListKey, id: number, values: FieldValues): Promise<void> {
    const def: IListDef = listDef(key);
    const type: string = await this._itemType(def);
    const res: SPHttpClientResponse = await this._http.post(`${this._list(def)}/items(${id})`, SPHttpClient.configurations.v1, {
      headers: { ...VERBOSE, 'IF-MATCH': '*', 'X-HTTP-Method': 'MERGE' }, body: JSON.stringify({ __metadata: { type }, ...values })
    });
    await this._check(res, 'update ' + def.title);
  }

  public async remove(key: ListKey, id: number): Promise<void> {
    const def: IListDef = listDef(key);
    const res: SPHttpClientResponse = await this._http.post(`${this._list(def)}/items(${id})`, SPHttpClient.configurations.v1, {
      headers: { ...VERBOSE, 'IF-MATCH': '*', 'X-HTTP-Method': 'DELETE' }
    });
    await this._check(res, 'delete from ' + def.title);
  }

  private _list(def: IListDef): string {
    return `${this._web}/_api/web/lists/getbytitle('${def.title}')`;
  }

  /** SharePoint returns missing text columns as null; the UI expects strings. */
  private _normalise(def: IListDef, raw: IItem): IItem {
    const src: { [name: string]: unknown } = raw as unknown as { [name: string]: unknown };
    const out: { [name: string]: unknown } = { Id: raw.Id, Title: raw.Title || '', Created: raw.Created };
    for (const f of def.fields) {
      const v: unknown = src[f.name];
      out[f.name] = f.kind === 'Number' ? (typeof v === 'number' ? v : 0) : (v === null || v === undefined ? '' : String(v));
    }
    return out as unknown as IItem;
  }

  private async _check(res: IReply, what: string): Promise<void> {
    if (res.ok) {
      return;
    }
    let detail: string = '';
    try {
      const body: { error?: { message?: { value?: string } } } = (await res.json()) as { error?: { message?: { value?: string } } };
      detail = body.error && body.error.message && body.error.message.value ? body.error.message.value : '';
    } catch {
      detail = '';
    }
    const denied: boolean = res.status === 401 || res.status === 403;
    throw new Error(denied ? `You do not have permission to ${what}.` : `Could not ${what} (${res.status}). ${detail}`.trim());
  }

  private async _itemType(def: IListDef): Promise<string> {
    if (!this._types[def.key]) {
      const res: SPHttpClientResponse = await this._http.get(
        `${this._list(def)}?$select=ListItemEntityTypeFullName`, SPHttpClient.configurations.v1, { headers: VERBOSE });
      await this._check(res, 'read ' + def.title);
      const json: IVerboseList = (await res.json()) as IVerboseList;
      this._types[def.key] = json.d.ListItemEntityTypeFullName || '';
    }
    return this._types[def.key];
  }

  /** Returns true when the list had to be created. */
  private async _ensure(def: IListDef): Promise<boolean> {
    const probe: SPHttpClientResponse = await this._http.get(`${this._list(def)}?$select=Id`, SPHttpClient.configurations.v1, { headers: VERBOSE });
    if (probe.ok) {
      return false;
    }
    if (probe.status !== 404) {
      await this._check(probe, 'open ' + def.title);
    }
    const created: SPHttpClientResponse = await this._http.post(`${this._web}/_api/web/lists`, SPHttpClient.configurations.v1, {
      headers: VERBOSE,
      body: JSON.stringify({ __metadata: { type: 'SP.List' }, AllowContentTypes: true, BaseTemplate: 100, ContentTypesEnabled: false, Description: def.description, Title: def.title })
    });
    if (!created.ok) {
      // Another visitor may have created it at the same moment.
      const again: SPHttpClientResponse = await this._http.get(`${this._list(def)}?$select=Id`, SPHttpClient.configurations.v1, { headers: VERBOSE });
      if (again.ok) {
        return false;
      }
      await this._check(created, 'create the list ' + def.title + '. Ask a site owner to open the Sales Hub once');
    }
    for (const f of def.fields) {
      await this._createField(this._list(def), f, def.title);
    }
    return true;
  }
}
