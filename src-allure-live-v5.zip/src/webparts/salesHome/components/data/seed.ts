import type { FieldValues, ListKey } from './types';

/** Sample content written to the lists the first time the hub is opened. Edit it in the app or in the lists. */
let order: number = 0;
const R = (section: string, group: string, title: string, sub: string = '', tag: string = '', tone: string = '', link: string = '', extra: string = '', date: string = ''): FieldValues => {
  order += 1;
  return { Title: title, Section: section, Group: group, Sub: sub, Extra: extra, Tag: tag, TagTone: tone, Link: link, ItemDate: date, SortOrder: order };
};

const HOME: string = 'home';
const CAP: string = 'capabilities';
const INN: string = 'innovation';
const PRI: string = 'pricing';
const REG: string = 'regulatory';
const MKT: string = 'marketing-assets';
const EVT: string = 'events';
const PLB: string = 'sales-playbook';
const ACC: string = 'accounts';
const DOC: string = 'company-documents';
const SITE: string = 'site';
const CHO: string = 'choices';

export const SEED: { [key in ListKey]: FieldValues[] } = {
  events: [
    { Title: 'Cosmoprof North America', EventDate: '2026-12-03', Location: 'Las Vegas, NV', EventType: 'Trade show', Notes: 'Booth B214' },
    { Title: 'Customer visit: Scottsdale', EventDate: '2026-12-09', Location: 'Scottsdale, AZ', EventType: 'Customer visit', Notes: '' },
    { Title: 'Quarterly business review', EventDate: '2026-12-15', Location: 'Hayward, CA', EventType: 'Meeting', Notes: '' },
    { Title: 'Beauty Innovation Summit', EventDate: '2027-01-20', Location: 'New York, NY', EventType: 'Conference', Notes: '' },
    { Title: 'Indie Beauty Expo', EventDate: '2027-03-10', Location: 'Los Angeles, CA', EventType: 'Trade show', Notes: '' }
  ],
  news: [
    { Title: 'New Skincare Line Now Available', PublishDate: '2026-11-10', Summary: 'Our new skincare line is ready to sample. Ask the innovation team for formulas and pricing.', Link: '' },
    { Title: 'Successful Launch at Cosmoprof 2026', PublishDate: '2026-11-05', Summary: 'The team captured qualified leads at the show. See the event recap for details.', Link: 'page:events#recaps' },
    { Title: 'MoCRA Compliance Update', PublishDate: '2026-10-28', Summary: 'Updated guidance on MoCRA facility registration and product listing.', Link: 'page:regulatory#mocra' }
  ],
  wins: [
    { Title: 'Won 3-SKU skincare program', Summary: 'Private-label launch for a new retail partner', Category: 'Skincare' },
    { Title: 'Sulfate-free shampoo line', Summary: 'Scottsdale facility, first PO received', Category: 'Haircare' },
    { Title: 'SPF OTC reformulation', Summary: 'Approved by the customer', Category: 'OTC' }
  ],
  accounts: [
    { Title: 'Account A', Segment: 'Skincare', Owner: 'Sales rep', Stage: 'Active', PlanLink: '' },
    { Title: 'Account B', Segment: 'Haircare', Owner: 'Sales rep', Stage: 'Sampling', PlanLink: '' },
    { Title: 'Account C', Segment: 'Color cosmetics', Owner: 'Sales rep', Stage: 'Quoting', PlanLink: '' },
    { Title: 'Account D', Segment: 'OTC', Owner: 'Sales rep', Stage: 'Active', PlanLink: '' }
  ],
  requests: [],
  resources: [
    // Home
    R(HOME, 'Quick links', 'Sales Playbook', '', '', '', 'page:sales-playbook'),
    R(HOME, 'Quick links', 'Customer Accounts (CRM)', '', '', '', 'page:accounts#crm'),
    R(HOME, 'Quick links', 'Company Documents', '', '', '', 'page:company-documents'),
    R(HOME, 'Quick links', 'R&D Resources', '', '', '', 'page:innovation'),
    R(HOME, 'Quick links', 'Sales Templates', '', '', '', 'page:sales-playbook#templates'),
    // Capabilities
    R(CAP, 'Decks', 'Allure capabilities deck', 'PowerPoint · 32 slides', 'Current', 'g'),
    R(CAP, 'Facility profiles', 'Hayward, CA facility profile', 'PDF · 4 pages', 'Current', 'g'),
    R(CAP, 'Facility profiles', 'Scottsdale, AZ facility profile', 'PDF · 4 pages', 'Current', 'g'),
    R(CAP, 'Hayward stats', '—', 'Facility size (sq ft)'), R(CAP, 'Hayward stats', '—', 'Filling lines'), R(CAP, 'Hayward stats', '—', 'Typical lead time'),
    R(CAP, 'Scottsdale stats', '—', 'Facility size (sq ft)'), R(CAP, 'Scottsdale stats', '—', 'R&D labs'), R(CAP, 'Scottsdale stats', '—', 'Typical lead time'),
    R(CAP, 'Certifications', 'cGMP', 'Hayward & Scottsdale', 'Current', 'g', '', 'Oct 2026'),
    R(CAP, 'Certifications', 'ISO 22716', 'Hayward', 'Current', 'g', '', 'Sep 2026'),
    R(CAP, 'Certifications', 'FDA registration', 'Hayward & Scottsdale', 'Current', 'g', '', 'Aug 2026'),
    R(CAP, 'Certifications', 'Customer audits', 'Both', 'Reports available', '', '', 'Nov 2026'),
    R(CAP, 'Case studies', 'Private-label skincare launch', 'From concept to shelf in 14 weeks'),
    R(CAP, 'Case studies', 'Sulfate-free haircare range', 'Scottsdale pilot to full production'),
    R(CAP, 'Case studies', 'SPF OTC reformulation', 'Meeting FDA monograph requirements'),
    R(CAP, 'Skincare', 'Skincare capabilities overview', 'Creams, serums, lotions & cleansers', 'Overview'),
    R(CAP, 'Skincare', 'Skincare sample request form', 'Word · ready to complete', 'Template', 'b'),
    R(CAP, 'Haircare', 'Haircare capabilities overview', 'Shampoo, conditioner & treatments', 'Overview'),
    R(CAP, 'Haircare', 'Haircare sample request form', 'Word · ready to complete', 'Template', 'b'),
    R(CAP, 'Color Cosmetics', 'Color cosmetics capabilities overview', 'Face, lip & eye products', 'Overview'),
    R(CAP, 'Color Cosmetics', 'Shade-matching process', 'PDF · 2 pages'),
    R(CAP, 'OTC', 'OTC capabilities overview', 'SPF, acne & drug-regulated products', 'Overview'),
    R(CAP, 'OTC', 'OTC monograph guide', 'PDF · 6 pages'),
    // Innovation
    R(INN, 'Concepts', 'Barrier-repair night cream', 'Ceramide complex, fragrance-free, ready for sampling', 'Skincare', '', '', 'Launch-ready'),
    R(INN, 'Concepts', 'Brightening vitamin C serum', 'Stable 15% format with airless pack option', 'Skincare', '', '', 'Launch-ready'),
    R(INN, 'Concepts', 'Tinted mineral SPF 30', 'Sheer finish, reef-safe filters', 'OTC', 'b', '', 'In development'),
    R(INN, 'Concepts', 'Scalp-care treatment', 'Sulfate-free, peptide and niacinamide blend', 'Haircare', 'o', '', 'Launch-ready'),
    R(INN, 'Trend reports', 'Clean & skin-first beauty 2027', 'Quarterly report · Nov 2026'),
    R(INN, 'Trend reports', 'Scalp care goes mainstream', 'Haircare insight · Oct 2026'),
    R(INN, 'Trend reports', 'Multifunctional color cosmetics', 'Color insight · Sep 2026'),
    R(INN, 'Presentations', 'Q4 launch-ready concepts', 'Customer-ready deck · 24 slides'),
    R(INN, 'Presentations', 'Hayward innovation lab overview', 'Capabilities deck · 12 slides'),
    R(INN, 'Presentations', 'Clean formulation roadmap', 'Strategy deck · 18 slides'),
    R(INN, 'Ingredient library', 'Niacinamide', 'Skin conditioning', 'Credo & Sephora', 'g', '', 'Visibly refines pores, evens tone'),
    R(INN, 'Ingredient library', 'Ceramide NP', 'Barrier support', 'Credo & Sephora', 'g', '', 'Helps restore moisture barrier'),
    R(INN, 'Ingredient library', 'Peptide complex', 'Scalp conditioning', 'Credo & Sephora', 'g', '', 'Supports a healthy-looking scalp'),
    R(INN, 'Ingredient library', 'Zinc oxide', 'UV filter', 'FDA monograph', 'b', '', 'Broad-spectrum protection'),
    // Pricing
    R(PRI, 'Rate cards', 'Skincare rate card Q4 2026', 'Updated Nov 2026 · PDF', 'Current', 'g'),
    R(PRI, 'Rate cards', 'Haircare rate card Q4 2026', 'Updated Nov 2026 · PDF', 'Current', 'g'),
    R(PRI, 'Rate cards', 'Color cosmetics rate card', 'Updated Oct 2026 · XLSX'),
    R(PRI, 'Rate cards', 'OTC rate card Q4 2026', 'Updated Oct 2026 · PDF'),
    R(PRI, 'MOQ and payment terms', 'Skincare', 'Per customer agreement', '', '', '', 'Net terms per contract'),
    R(PRI, 'MOQ and payment terms', 'Haircare', 'Per customer agreement', '', '', '', 'Net terms per contract'),
    R(PRI, 'MOQ and payment terms', 'Color cosmetics', 'Per customer agreement', '', '', '', 'Net terms per contract'),
    R(PRI, 'MOQ and payment terms', 'OTC', 'Per customer agreement', '', '', '', 'Net terms per contract'),
    // Regulatory
    R(REG, 'Clean standards', 'Credo Clean Standard', 'Skincare, haircare, color', '', '', '', 'Oct 2026'),
    R(REG, 'Clean standards', 'Clean at Sephora', 'All categories', '', '', '', 'Oct 2026'),
    R(REG, 'Clean standards', 'Retailer-specific lists', 'Per customer', '', '', '', 'Sep 2026'),
    R(REG, 'Restricted substances', 'Master restricted substances list', 'Updated Oct 2026 · PDF', 'Current', 'g'),
    R(REG, 'Restricted substances', 'EU & UK cosmetics annexes', 'Updated Sep 2026 · PDF'),
    R(REG, 'Restricted substances', 'California & state-level lists', 'Updated Sep 2026 · PDF'),
    R(REG, 'MoCRA and FDA guidance', 'MoCRA facility registration renewal checklist', 'Guidance note', '', '', '', '', '2026-11-10'),
    R(REG, 'MoCRA and FDA guidance', 'MoCRA compliance update', 'Regulatory update', '', '', '', '', '2026-10-28'),
    R(REG, 'MoCRA and FDA guidance', 'OTC monograph labeling quick guide', 'Guidance note', '', '', '', '', '2026-10-12'),
    R(REG, 'Questionnaire templates', 'Standard supplier questionnaire', 'Word · ready to complete', 'Template'),
    R(REG, 'Questionnaire templates', 'Retailer compliance questionnaire', 'Word · ready to complete', 'Template', 'o'),
    R(REG, 'Questionnaire templates', 'Ingredient disclosure form', 'Excel · ready to complete', 'Template', 'b'),
    // Marketing assets
    R(MKT, 'Decks and one-pagers', 'Allure capabilities deck', 'PowerPoint · 32 slides', 'Current', 'g'),
    R(MKT, 'Decks and one-pagers', 'Hayward facility one-pager', 'PDF · 2 pages'),
    R(MKT, 'Decks and one-pagers', 'Scottsdale facility one-pager', 'PDF · 2 pages'),
    R(MKT, 'Decks and one-pagers', 'Innovation capabilities overview', 'PowerPoint · 14 slides'),
    R(MKT, 'Brand files', 'Logo pack (SVG, PNG)', 'Zip · approved logos'),
    R(MKT, 'Brand files', 'Brand guidelines', 'PDF · usage rules'),
    R(MKT, 'Trade show materials', 'Booth graphics, print-ready', 'Zip · 180 MB'),
    R(MKT, 'Trade show materials', 'Brochure and handout set', 'PDF · 6 files'),
    R(MKT, 'Trade show materials', 'Booth setup guide', 'PDF · 4 pages'),
    // Events
    R(EVT, 'Playbooks and checklists', 'Trade show planning playbook', 'Word · 8 pages', 'Playbook'),
    R(EVT, 'Playbooks and checklists', 'Booth day-of checklist', 'PDF · 2 pages', 'Checklist', 'g'),
    R(EVT, 'Playbooks and checklists', 'Post-show follow-up checklist', 'PDF · 2 pages', 'Checklist', 'g'),
    R(EVT, 'Event recaps', 'Cosmoprof 2026 recap', 'Nov 2026 · 42 qualified leads'),
    R(EVT, 'Event recaps', 'Indie Beauty Expo 2026 recap', 'Mar 2026 · 27 qualified leads'),
    R(EVT, 'Event recaps', 'Beauty Innovation Summit 2026', 'Jan 2026 · Key learnings'),
    // Sales playbook
    R(PLB, 'Battle cards', 'We are concerned about minimum order quantities', 'Lead with pilot runs and scalable batches', '', '', '', 'Offer pilot batches first, then scale to full production as volume grows.'),
    R(PLB, 'Battle cards', 'Can you meet clean-beauty standards?', 'Credo and Sephora compliance, documented', '', '', '', 'Share the clean standards pages and the ingredient library.'),
    R(PLB, 'Battle cards', 'How fast can you get samples to us?', 'Sampling timelines by category', '', '', '', 'Confirm the category, then quote the typical sampling lead time.'),
    R(PLB, 'Templates', 'Introduction email', 'Word · ready to send', 'Template'),
    R(PLB, 'Templates', 'Follow-up after sample', 'Word · ready to send', 'Template', 'o'),
    R(PLB, 'Templates', 'Proposal template', 'PowerPoint · 12 slides', 'Template', 'b'),
    R(PLB, 'Onboarding', 'Week 1: Company & products', '5 of 5', '', '', '', '100'),
    R(PLB, 'Onboarding', 'Week 2: Capabilities & facilities', '3 of 5', '', '', '', '60'),
    R(PLB, 'Onboarding', 'Week 3: Pricing & regulatory', '1 of 5', '', '', '', '20'),
    R(PLB, 'Onboarding', 'Week 4: Shadowing & first call', '0 of 5', '', '', '', '0'),
    // Accounts
    R(ACC, 'QBR decks', 'Q4 2026 QBR: Account A', 'Hayward, CA', '', '', '', '', '2026-12-15'),
    R(ACC, 'QBR decks', 'Q3 2026 QBR: Account B', 'Video call', '', '', '', '', '2026-09-22'),
    R(ACC, 'QBR decks', 'Q2 2026 QBR: Account C', 'Scottsdale, AZ', '', '', '', '', '2026-06-18'),
    R(ACC, 'CRM', 'Customer CRM', 'Pipeline, contacts and activity for every account'),
    // Company documents
    R(DOC, 'Org chart', 'Leadership', 'Executive team', 'lead'),
    R(DOC, 'Org chart', 'Sales Director', 'Sales & accounts'),
    R(DOC, 'Org chart', 'Operations Lead', 'Hayward & Scottsdale'),
    R(DOC, 'Org chart', 'Regulatory Lead', 'Compliance'),
    R(DOC, 'Org chart', 'Finance Lead', 'Finance & contracts'),
    R(DOC, 'Contracts and templates', 'Mutual NDA template', 'Word · Legal approved', 'Current', 'g'),
    R(DOC, 'Contracts and templates', 'Master services agreement (MSA)', 'Word · Legal approved', 'Current', 'g'),
    R(DOC, 'Contracts and templates', 'Quality agreement template', 'Word · Legal approved'),
    R(DOC, 'Vendor forms', 'W-9', 'PDF · 1 page'),
    R(DOC, 'Vendor forms', 'Certificate of insurance (COI)', 'PDF · 1 page'),
    R(DOC, 'Vendor forms', 'Vendor onboarding form', 'PDF · 3 pages'),
    R(DOC, 'Policies', 'Code of conduct', 'PDF · Updated Sep 2026'),
    R(DOC, 'Policies', 'Confidentiality policy', 'PDF · Updated Aug 2026'),
    R(DOC, 'Policies', 'Travel & expense policy', 'PDF · Updated Jul 2026'),
    // Site-wide text, steps, choices and media (added in v3)
    R(SITE, 'Site banner', 'Two industry trailblazers — Allure Labs and Kleen Concepts — are now Allure Beauty Concepts.'),
    R(SITE, 'Site footer', '30901 Wiegman Rd, Hayward, CA 94544', '(510) 489-8896'),
    R(SITE, 'Site footer', '8388 E Hartford Dr #105, Scottsdale, AZ 85255', '(480) 515-5576'),
    R(SITE, 'Site footer', 'Partner with us', 'info@allurebeautyconcepts.com'),
    R(SITE, 'Site footer', 'Allure Beauty Concepts · Internal use only', '', 'small'),
    R(SITE, 'Facilities', 'Hayward, CA', 'Manufacturing Facility', 'hayward', '', '', 'Contract manufacturing\nFilling & assembly\nMass & pilot production'),
    R(SITE, 'Facilities', 'Scottsdale, AZ', 'Manufacturing Facility', 'scottsdale', '', '', 'Specialized formulations\nInnovation & development\nScalable manufacturing'),
    R(PLB, 'Sales process steps', 'Prospect', 'Identify brands that fit our categories'),
    R(PLB, 'Sales process steps', 'Qualify', 'Budget, volume, timeline and fit'),
    R(PLB, 'Sales process steps', 'Develop', 'Samples, formula and pricing'),
    R(PLB, 'Sales process steps', 'Quote', 'Costing and approval'),
    R(PLB, 'Sales process steps', 'Launch', 'Production and first shipment'),
    R(PRI, 'Discount approval steps', 'Sales rep', 'Up to the standard threshold'),
    R(PRI, 'Discount approval steps', 'Sales Director', 'Above standard threshold'),
    R(PRI, 'Discount approval steps', 'Finance & leadership', 'Exceptions and strategic deals'),
    R(MKT, 'Brand colours', 'Navy', '#0A3F52'),
    R(MKT, 'Brand colours', 'Teal', '#159BAC'),
    R(MKT, 'Brand colours', 'Cyan', '#70CFDB'),
    R(MKT, 'Brand colours', 'Orange', '#FC6337'),
    R(MKT, 'Brand colours', 'Tint', '#E9F5F8'),
    R(MKT, 'Photos and videos', 'Hayward facility', '', 'fac1'),
    R(MKT, 'Photos and videos', 'Scottsdale facility', '', 'fac2'),
    R(MKT, 'Photos and videos', 'Skincare hero', '', 'jar'),
    R(MKT, 'Photos and videos', 'Serum close-up', '', 'dropper'),
    R(MKT, 'Photos and videos', 'Tube & packaging', '', 'tube'),
    R(MKT, 'Photos and videos', 'Botanical lifestyle', '', 'flower'),
    ...['Trade show', 'Conference', 'Customer visit', 'Meeting', 'Webinar', 'Other'].map((t: string) => R(CHO, 'Event types', t)),
    ...['Prospect', 'Sampling', 'Quoting', 'Active', 'On hold'].map((t: string) => R(CHO, 'Account stages', t)),
    ...['Skincare', 'Haircare', 'Color cosmetics', 'OTC', 'Other'].map((t: string) => R(CHO, 'Quote categories', t)),
    ...['New', 'In review', 'Quoted', 'Won', 'Lost'].map((t: string) => R(CHO, 'Quote statuses', t))
  ]
};

/** Groups added after the first release. A list from an earlier version only receives these, never a full refill. */
export const NEW_GROUPS: string[] = ['Site banner', 'Site footer', 'Facilities', 'Sales process steps', 'Discount approval steps', 'Brand colours', 'Photos and videos', 'Event types', 'Account stages', 'Quote categories', 'Quote statuses'];

/** Identifies a sample row, so rows that already exist are not written twice. */
export const seedKey = (key: ListKey, r: FieldValues): string => (key === 'resources' ? `${r.Section}|${r.Group}|${r.Title}` : String(r.Title));
