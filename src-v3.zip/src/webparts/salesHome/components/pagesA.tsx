import * as React from 'react';

import styles from './SalesHome.module.scss';
import { IconName } from './icons';
import {
  ActionTag, Calendar, Card, DateBadge, Grid, Hero, Icon, IconBox, Link, ListRow, SecHead, Tag, Thumb, Tone, Wrap, cx
} from './ui';

export type PageKey =
  | 'home' | 'capabilities' | 'innovation' | 'pricing' | 'regulatory'
  | 'marketing' | 'events' | 'playbook' | 'accounts' | 'documents';

/* ---------------------------------------------------------------- Home */

interface IHomeProps {
  firstName: string;
  go: (page: PageKey) => void;
}

const QUICK: Array<{ icon: IconName; label: string; page: PageKey }> = [
  { icon: 'shield', label: 'Regulatory hub', page: 'regulatory' },
  { icon: 'tag', label: 'Price lists', page: 'pricing' },
  { icon: 'file', label: 'Case studies', page: 'capabilities' },
  { icon: 'image', label: 'Marketing assets', page: 'marketing' },
  { icon: 'cal', label: 'Trade show calendar', page: 'events' },
  { icon: 'users', label: 'CRM', page: 'accounts' }
];

const NEWS: Array<{ title: string; date: string; tone: Tone; icon: IconName }> = [
  { title: 'New clean-beauty standards update', date: '04 Nov 2026', tone: 4, icon: 'shield' },
  { title: 'Q4 launch-ready concepts available', date: '28 Oct 2026', tone: 3, icon: 'flask' },
  { title: 'Scottsdale capacity expansion on track', date: '21 Oct 2026', tone: 5, icon: 'trend' }
];

const WINS: Array<[string, string, string]> = [
  ['Won 3-SKU skincare program', 'Private-label launch for a new retail partner', 'Skincare'],
  ['Sulfate-free shampoo line', 'Scottsdale facility, first PO received', 'Haircare'],
  ['SPF OTC reformulation', 'Approved by the customer', 'OTC']
];

const EVENTS: Array<[string, string, string, string]> = [
  ['02', 'Dec', 'Trade show: Cosmoprof', 'Las Vegas'],
  ['09', 'Dec', 'Customer visit: Scottsdale', 'Scottsdale'],
  ['15', 'Dec', 'Quarterly business review', 'Hayward']
];

export const HomePage: React.FC<IHomeProps> = ({ firstName, go }) => (
  <Wrap>
    <div className={cx(styles.hero, styles.heroTall)}>
      <svg className={styles.rings} width="360" height="360" viewBox="0 0 360 360" aria-hidden="true">
        <circle cx="180" cy="180" r="170" fill="none" stroke="#fff" strokeOpacity=".12" strokeWidth="2" />
        <circle cx="180" cy="180" r="120" fill="none" stroke="#fff" strokeOpacity=".12" strokeWidth="2" />
        <circle cx="180" cy="180" r="70" fill="none" stroke="#fff" strokeOpacity=".12" strokeWidth="2" />
      </svg>
      <div className={styles.heroIn}>
        <div className={styles.crumb}>Sales &nbsp;/&nbsp; Home</div>
        <h1>Hello, {firstName}</h1>
        <p>
          Everything you need to win business: capabilities, innovation, pricing, regulatory guidance and playbooks.
        </p>
      </div>
      <div className={styles.three}>
        <div><b>Quality</b>cGMP and ISO certified</div>
        <div><b>Speed</b>Fast sample turnaround</div>
        <div><b>Partnership</b>Two US facilities</div>
      </div>
    </div>

    <div className={styles.barWrap}>
      <div className={styles.bar}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <Icon name="cal" size={20} />
          <b>Cosmoprof North America starts 2 December. Booth B214, Las Vegas.</b>
        </div>
        <Link className={styles.btn} onClick={(): void => go('events')}>Learn more</Link>
      </div>
    </div>

    <Grid cols="home" style={{ marginTop: 26, alignItems: 'start' }}>
      <Card>
        <h3 style={{ fontSize: 17, marginBottom: 14 }}>Quick links</h3>
        <div className={styles.qt}>
          {QUICK.map(q => (
            <Link key={q.label} onClick={(): void => go(q.page)}>
              <Icon name={q.icon} size={26} sw={1.6} />
              {q.label}
            </Link>
          ))}
        </div>
      </Card>

      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <h3 style={{ fontSize: 17, margin: 0 }}>Latest news</h3>
          <Link style={{ fontSize: 12, fontWeight: 600, color: '#00589b' }}>See all news &rarr;</Link>
        </div>
        <div className={styles.ftabs}>
          <Link className={styles.on}>All</Link>
          <Link>My business</Link>
          <Link>Company news</Link>
        </div>
        <Card flush className={styles.featCard}>
          <Thumb tone={1} icon="award" size={56} sw={1.2} style={{ height: 'auto', minHeight: 200, position: 'relative' }}>
            <span className={styles.pill}>Company news</span>
          </Thumb>
          <div className={styles.body} style={{ padding: 22 }}>
            <Tag>Featured</Tag>
            <h3 style={{ fontSize: 19, margin: '12px 0 6px', lineHeight: 1.25 }}>Hayward facility completes annual audit</h3>
            <div className={styles.sub}>10 Nov 2026 &middot; All certifications renewed with no major findings.</div>
            <Link className={cx(styles.btn, styles.solid)} style={{ marginTop: 16 }}>Read more</Link>
          </div>
        </Card>
        <Card style={{ padding: '6px 20px' }}>
          {NEWS.map(n => (
            <div className={styles.row} key={n.title}>
              <Thumb tone={n.tone} icon={n.icon} size={22} sw={1.6} style={{ width: 58, height: 58, borderRadius: 10, flex: 'none' }} />
              <div className={styles.grow}>
                <b>{n.title}</b>
                <span className={styles.s}>{n.date}</span>
              </div>
            </div>
          ))}
        </Card>
      </div>
    </Grid>

    <Grid cols="g2" style={{ marginTop: 26, alignItems: 'start' }}>
      <div>
        <SecHead title="Recent wins" sub="Customer programs we have landed" link="See all" />
        <Card>
          {WINS.map(([title, sub, cat]) => (
            <div className={styles.row} key={title}>
              <div className={cx(styles.ic, styles.dark)} style={{ width: 34, height: 34, borderRadius: '50%' }}>
                <Icon name="check" size={16} sw={2.4} />
              </div>
              <div className={styles.grow}><b>{title}</b><span className={styles.s}>{sub}</span></div>
              <Tag tone="gold">{cat}</Tag>
            </div>
          ))}
        </Card>
      </div>
      <div>
        <SecHead title="Events calendar" sub="December 2026" link="Full calendar" />
        <Card>
          <div className={styles.split}>
            <Calendar highlight={[2, 9, 15]} />
            <div>
              {EVENTS.map(([d, m, title, place]) => (
                <div className={styles.row} key={title}>
                  <DateBadge day={d} month={m} />
                  <div className={styles.grow}><b>{title}</b><span className={styles.s}>{place}</span></div>
                </div>
              ))}
            </div>
          </div>
        </Card>
      </div>
    </Grid>
  </Wrap>
);

/* -------------------------------------------------------- Capabilities */

interface IFacility {
  name: string;
  city: string;
  desc: string;
  stats: Array<[string, string]>;
  tags: string[];
  tone: Tone;
}

const FACILITIES: IFacility[] = [
  {
    name: 'Hayward', city: 'Hayward, California', tone: 1,
    desc: 'Full-service skincare and haircare manufacturing with in-house formulation and R&D labs.',
    stats: [['120k', 'sq ft'], ['6', 'Fill lines'], ['2M', 'Units / month']], tags: ['Skincare', 'Haircare', 'Color']
  },
  {
    name: 'Scottsdale', city: 'Scottsdale, Arizona', tone: 2,
    desc: 'High-volume OTC and haircare production with dedicated filling and packaging suites.',
    stats: [['90k', 'sq ft'], ['5', 'Fill lines'], ['3M', 'Units / month']], tags: ['OTC', 'Haircare', 'Packaging']
  }
];

const CATEGORIES: Array<{ icon: IconName; title: string; desc: string }> = [
  { icon: 'drop', title: 'Skincare', desc: 'Serums, creams, cleansers and masks' },
  { icon: 'wind', title: 'Haircare', desc: 'Shampoo, conditioner and treatments' },
  { icon: 'palette', title: 'Color', desc: 'Hair color and cosmetic color products' },
  { icon: 'sun', title: 'OTC', desc: 'SPF, acne and drug-facts products' }
];

const CERTS = ['ISO 22716', 'cGMP', 'FDA registered', 'MoCRA', 'Vegan certified', 'Cruelty free'];

const CASES: Array<{ title: string; cat: string; tone: Tone }> = [
  { title: 'Private-label skincare launch', cat: 'Skincare', tone: 1 },
  { title: 'Sulfate-free haircare range', cat: 'Haircare', tone: 3 },
  { title: 'SPF reformulation program', cat: 'OTC', tone: 2 }
];

export const CapabilitiesPage: React.FC = () => (
  <Wrap>
    <Hero
      title="Capabilities"
      sub="Two facilities, four product categories and the certifications that back them."
      crumb="Sales  /  Capabilities"
      stats={[['2', 'Facilities'], ['5M', 'Units / month']]}
    />
    <SecHead title="Facility profiles" sub="Where we make it" />
    <Grid cols="g2">
      {FACILITIES.map(f => (
        <Card flush key={f.name}>
          <Thumb tone={f.tone} icon="pin" size={44} sw={1.3} style={{ height: 150, position: 'relative' }}>
            <span className={styles.chip} style={{ position: 'absolute', left: 18, bottom: 14, margin: 0, color: '#fff' }}>
              <Icon name="pin" size={12} sw={2} /> {f.city}
            </span>
          </Thumb>
          <div className={styles.body} style={{ padding: 20 }}>
            <h3 style={{ fontSize: 19 }}>{f.name}</h3>
            <div className={styles.sub} style={{ margin: '4px 0 16px' }}>{f.desc}</div>
            <div className={styles.stats3}>
              {f.stats.map(([v, l]) => (
                <div key={l}><div className={styles.stat}>{v}<small>{l}</small></div></div>
              ))}
            </div>
            {f.tags.map(t => <Tag key={t} style={{ marginRight: 6 }}>{t}</Tag>)}
            <div style={{ marginTop: 16 }}>
              <Link className={cx(styles.btn, styles.solid)}>View facility profile</Link>
            </div>
          </div>
        </Card>
      ))}
    </Grid>

    <SecHead title="Category capabilities" sub="What we make" />
    <Grid cols="g4">
      {CATEGORIES.map((c, i) => (
        <Card key={c.title}>
          <div style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
            <IconBox name={c.icon} variant={i % 2 ? 'gold' : ''} size={24} />
            <div><b style={{ fontSize: 15 }}>{c.title}</b><div className={styles.sub}>{c.desc}</div></div>
          </div>
          <div style={{ marginTop: 14, display: 'flex', justifyContent: 'space-between', fontSize: 12, color: '#5b6f86' }}>
            <span>Capability sheet</span>
            <Link style={{ color: '#1b365d', fontWeight: 600 }}>Open &rarr;</Link>
          </div>
        </Card>
      ))}
    </Grid>

    <SecHead title="Certifications and audits" sub="Current status across both facilities" link="View all audits" />
    <Grid cols="g6">
      {CERTS.map(c => (
        <Card key={c} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, padding: '18px 8px', textAlign: 'center' }}>
          <IconBox name="award" variant="gold" />
          <b style={{ fontSize: 12.5 }}>{c}</b>
          <Tag>Valid</Tag>
        </Card>
      ))}
    </Grid>

    <SecHead title="Case studies" sub="Proof points to share with customers" link="All case studies" />
    <Grid cols="g3">
      {CASES.map(c => (
        <Card flush key={c.title}>
          <Thumb tone={c.tone} icon="file" size={34} style={{ height: 110 }} />
          <div className={styles.body}>
            <Tag tone="gold">{c.cat}</Tag>
            <div style={{ fontWeight: 700, margin: '8px 0 4px' }}>{c.title}</div>
            <div className={styles.sub}>Challenge, solution and results in one page.</div>
            <Link style={{ display: 'inline-block', marginTop: 10, fontSize: 12, fontWeight: 600, color: '#1b365d' }}>Read case study &rarr;</Link>
          </div>
        </Card>
      ))}
    </Grid>
  </Wrap>
);

/* ---------------------------------------------------------- Innovation */

interface IConcept {
  name: string;
  cat: string;
  status: 'Launch-ready' | 'In testing' | 'Concept';
  tone: Tone;
  swatches: [string, string, string];
}

const CONCEPTS: IConcept[] = [
  { name: 'Overnight barrier serum', cat: 'Skincare', status: 'Launch-ready', tone: 1, swatches: ['#dbe7f5', '#7fa8d4', '#8fb8e6'] },
  { name: 'Scalp-care shampoo', cat: 'Haircare', status: 'Launch-ready', tone: 3, swatches: ['#dbe7f5', '#7fa8d4', '#1d4e89'] },
  { name: 'Tinted mineral SPF 30', cat: 'OTC', status: 'In testing', tone: 2, swatches: ['#dbe7f5', '#7fa8d4', '#5b8fb9'] },
  { name: 'Bond-repair mask', cat: 'Haircare', status: 'Concept', tone: 4, swatches: ['#dbe7f5', '#a9bfe0', '#4a6fa5'] },
  { name: 'Vitamin C glow cream', cat: 'Skincare', status: 'Launch-ready', tone: 5, swatches: ['#e4edf8', '#9cc0e6', '#5b8fb9'] },
  { name: 'Gloss color refresh', cat: 'Color', status: 'Concept', tone: 6, swatches: ['#dbe9f5', '#8fc5dc', '#2c6f8f'] }
];

const TRENDS: Array<[string, string, string]> = [
  ['Clean beauty 2027', 'Ingredient transparency and refill packaging', 'Oct 2026'],
  ['Scalp-first haircare', 'Skinification of haircare', 'Sep 2026'],
  ['Biotech actives', 'Fermented and peptide-led claims', 'Aug 2026']
];

const DECKS: Array<[string, string]> = [
  ['Innovation roadmap 2027', '24 slides'],
  ['Concept showcase: Skincare', '18 slides'],
  ['Customer-facing formula brief', '12 slides']
];

const INGREDIENTS: Array<[string, string, string, string]> = [
  ['Niacinamide', 'Brightening, pore-refining', 'Vegan', 'Approved'],
  ['Bakuchiol', 'Retinol alternative', 'Vegan', 'Approved'],
  ['Panthenol', 'Moisturising, soothing', 'Vegan', 'Approved'],
  ['Zinc oxide (non-nano)', 'Mineral SPF filter', 'Vegan', 'OTC review']
];

const INNOVATION_TABS: Array<[IconName, string]> = [
  ['beaker', 'New formulas & concepts'],
  ['trend', 'Trend reports'],
  ['play', 'Presentations'],
  ['drop', 'Ingredient & claims']
];

export const InnovationPage: React.FC = () => {
  const [tab, setTab] = React.useState<number>(0);
  return (
    <Wrap>
      <Hero
        title="Innovation"
        sub="New formulas, launch-ready concepts, trend insight and the ingredient and claims library in one place."
        crumb="Sales  /  Innovation"
        stats={[['12', 'Concepts'], ['3', 'Launch-ready'], ['140', 'Ingredients']]}
      />
      <div className={styles.tabs}>
        {INNOVATION_TABS.map(([icon, label], i) => (
          <Link key={label} className={i === tab ? styles.on : undefined} onClick={(): void => setTab(i)}>
            <Icon name={icon} size={16} />
            {label}
          </Link>
        ))}
      </div>

      <SecHead title="New formulas and launch-ready concepts" sub="Ready to present to customers" link="All concepts" />
      <Grid cols="g3">
        {CONCEPTS.map(c => (
          <Card flush key={c.name}>
            <Thumb tone={c.tone} icon="flask" size={40} style={{ height: 120 }} />
            <div className={styles.body}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <Tag tone={c.status === 'In testing' ? 'gold' : c.status === 'Concept' ? 'blue' : ''}>{c.status}</Tag>
                <div className={styles.sw}>
                  {c.swatches.map(s => <i key={s} style={{ background: s }} />)}
                </div>
              </div>
              <div style={{ fontWeight: 700, margin: '10px 0 2px' }}>{c.name}</div>
              <div className={styles.sub}>{c.cat} concept &middot; Sample available</div>
            </div>
          </Card>
        ))}
      </Grid>

      <Grid cols="g2" style={{ marginTop: 8, alignItems: 'start' }}>
        <div>
          <SecHead title="Trend reports" link="All reports" />
          <Card>
            {TRENDS.map(([a, b, c]) => (
              <ListRow key={a} icon="trend" title={a} sub={`${b} · ${c}`} right={<ActionTag label="PDF" />} />
            ))}
          </Card>
        </div>
        <div>
          <SecHead title="Innovation presentations" link="All decks" />
          <Card>
            {DECKS.map(([a, b]) => (
              <ListRow key={a} icon="play" title={a} sub={b} right={<ActionTag label="Open" />} />
            ))}
          </Card>
        </div>
      </Grid>

      <SecHead title="Ingredient and claims library" sub="Search approved ingredients and the claims they support" link="Open library" />
      <Card flush>
        <div className={styles.tblWrap}>
        <table className={styles.tbl}>
          <thead>
            <tr><th>Ingredient</th><th>Supported claims</th><th>Standard</th><th>Status</th></tr>
          </thead>
          <tbody>
            {INGREDIENTS.map(([a, b, c, d]) => (
              <tr key={a}>
                <td><b>{a}</b></td>
                <td>{b}</td>
                <td><Tag>{c}</Tag></td>
                <td><Tag tone={d === 'Approved' ? '' : 'gold'}>{d}</Tag></td>
              </tr>
            ))}
          </tbody>
        </table>
        </div>
      </Card>
    </Wrap>
  );
};
