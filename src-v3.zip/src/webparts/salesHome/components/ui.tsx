import * as React from 'react';

import styles from './SalesHome.module.scss';
import { ICON_PATHS, IconName } from './icons';

export type Tone = 1 | 2 | 3 | 4 | 5 | 6;
export type TagTone = '' | 'gold' | 'red' | 'blue';
export type BoxVariant = '' | 'round' | 'gold' | 'dark';

const TONES: string[] = [styles.t1, styles.t2, styles.t3, styles.t4, styles.t5, styles.t6];

export const cx = (...names: Array<string | false | undefined>): string =>
  names.filter(Boolean).join(' ');

export const Icon: React.FC<{ name: IconName; size?: number; sw?: number }> = ({ name, size = 22, sw = 1.8 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth={sw}
    strokeLinecap="round"
    strokeLinejoin="round"
    aria-hidden="true"
    focusable="false"
    dangerouslySetInnerHTML={{ __html: ICON_PATHS[name] }}
  />
);

interface ILinkProps {
  className?: string;
  style?: React.CSSProperties;
  onClick?: () => void;
  children?: React.ReactNode;
}

/** Placeholder link: real URLs are wired in later, so it never navigates the page. */
export const Link: React.FC<ILinkProps> = ({ className, style, onClick, children }) => (
  <a
    href="#"
    className={cx(styles.link, className)}
    style={style}
    onClick={(e: React.MouseEvent<HTMLAnchorElement>): void => {
      e.preventDefault();
      if (onClick) {
        onClick();
      }
    }}
  >
    {children}
  </a>
);

export const IconBox: React.FC<{ name: IconName; variant?: BoxVariant; size?: number; style?: React.CSSProperties }> = ({
  name,
  variant = '',
  size = 22,
  style
}) => (
  <div
    className={cx(
      styles.ic,
      variant === 'round' && styles.round,
      variant === 'gold' && styles.gold,
      variant === 'dark' && styles.dark
    )}
    style={style}
  >
    <Icon name={name} size={size} />
  </div>
);

export const Tag: React.FC<{ tone?: TagTone; style?: React.CSSProperties; children?: React.ReactNode }> = ({
  tone = '',
  style,
  children
}) => (
  <span
    className={cx(styles.tag, tone === 'gold' && styles.gold, tone === 'red' && styles.red, tone === 'blue' && styles.blue)}
    style={style}
  >
    {children}
  </span>
);

export const Thumb: React.FC<{
  tone: Tone;
  icon: IconName;
  size?: number;
  sw?: number;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}> = ({ tone, icon, size = 40, sw = 1.4, style, children }) => (
  <div className={cx(styles.thumb, TONES[tone - 1])} style={style}>
    <Icon name={icon} size={size} sw={sw} />
    {children}
  </div>
);

export const Wrap: React.FC<{ children?: React.ReactNode }> = ({ children }) => (
  <div className={styles.wrap}>{children}</div>
);

export const Grid: React.FC<{
  cols: 'g2' | 'g3' | 'g4' | 'g5' | 'g6' | 'g21' | 'g12' | 'home' | 'events' | 'docs' | 'gallery' | 'custom';
  style?: React.CSSProperties;
  children?: React.ReactNode;
}> = ({ cols, style, children }) => {
  const map: Record<string, string | undefined> = {
    g2: styles.g2,
    g3: styles.g3,
    g4: styles.g4,
    g5: styles.g5,
    g6: styles.g6,
    home: styles.gHome,
    events: styles.gEvents,
    docs: styles.gDocs,
    gallery: styles.gGallery,
    g21: styles.g21,
    g12: styles.g12,
    custom: undefined
  };
  return (
    <div className={cx(styles.grid, map[cols])} style={style}>
      {children}
    </div>
  );
};

export const Card: React.FC<{
  flush?: boolean;
  className?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}> = ({ flush, className, style, children }) => (
  <div className={cx(styles.card, flush && styles.flush, className)} style={style}>
    {children}
  </div>
);

export const SecHead: React.FC<{ title: string; sub?: string; link?: string }> = ({ title, sub, link }) => (
  <div className={styles.sec}>
    <div>
      <h2>{title}</h2>
      {sub && <p>{sub}</p>}
    </div>
    {link && <Link>{link} &rarr;</Link>}
  </div>
);

export interface IHeroProps {
  title: string;
  sub: string;
  crumb: string;
  stats?: Array<[string, string]>;
  chip?: string;
  buttons?: Array<[string, 'primary' | 'ghost']>;
}

export const Rings: React.FC = () => (
  <svg className={styles.rings} width="360" height="360" viewBox="0 0 360 360" aria-hidden="true">
    <circle cx="180" cy="180" r="170" fill="none" stroke="#fff" strokeOpacity=".12" strokeWidth="2" />
    <circle cx="180" cy="180" r="120" fill="none" stroke="#fff" strokeOpacity=".12" strokeWidth="2" />
    <circle cx="180" cy="180" r="70" fill="none" stroke="#fff" strokeOpacity=".12" strokeWidth="2" />
  </svg>
);

export const Hero: React.FC<IHeroProps> = ({ title, sub, crumb, stats, chip, buttons }) => (
  <div className={cx(styles.hero, styles.sm)}>
    <Rings />
    <div className={styles.heroIn}>
      <div className={styles.crumb}>{crumb}</div>
      <h1>{title}</h1>
      <p>{sub}</p>
      {chip && (
        <div className={styles.chip}>
          <Icon name="lock" size={12} sw={2} /> {chip}
        </div>
      )}
      {buttons && (
        <div className={styles.btns}>
          {buttons.map(([label, kind]) => (
            <Link key={label} className={cx(styles.btn, kind === 'ghost' && styles.ghost)}>
              {label}
            </Link>
          ))}
        </div>
      )}
    </div>
    {stats && (
      <div className={styles.stats}>
        {stats.map(([value, label]) => (
          <div key={label}>
            <b>{value}</b>
            <span>{label}</span>
          </div>
        ))}
      </div>
    )}
  </div>
);

export const ListRow: React.FC<{ icon: IconName; title: string; sub: string; right?: React.ReactNode }> = ({
  icon,
  title,
  sub,
  right
}) => (
  <div className={styles.row}>
    <IconBox name={icon} size={18} />
    <div className={styles.grow}>
      <b>{title}</b>
      <span className={styles.s}>{sub}</span>
    </div>
    {right}
  </div>
);

export const ActionTag: React.FC<{ label: string }> = ({ label }) => (
  <Link className={styles.tag}>{label}</Link>
);

export const MediaCard: React.FC<{
  tone: Tone;
  icon: IconName;
  title: string;
  sub: string;
  tag?: { label: string; tone: TagTone };
}> = ({ tone, icon, title, sub, tag }) => (
  <Card flush>
    <Thumb tone={tone} icon={icon} />
    <div className={styles.body}>
      {tag && (
        <>
          <Tag tone={tag.tone} style={{ marginBottom: 8 }}>
            {tag.label}
          </Tag>
          <br />
        </>
      )}
      <b style={{ fontSize: 14 }}>{title}</b>
      <div className={styles.sub} style={{ marginTop: 3 }}>
        {sub}
      </div>
    </div>
  </Card>
);

export const Calendar: React.FC<{ highlight: number[] }> = ({ highlight }) => {
  const cells: React.ReactNode[] = [];
  'SMTWTFS'.split('').forEach((d, i) => cells.push(<div key={`w${i}`} className={styles.w}>{d}</div>));
  cells.push(<div key="b1" />, <div key="b2" />);
  for (let d = 1; d <= 31; d++) {
    cells.push(
      <div key={`d${d}`} className={highlight.indexOf(d) >= 0 ? styles.e : undefined}>
        {d}
      </div>
    );
  }
  return <div className={styles.cal}>{cells}</div>;
};

export const DateBadge: React.FC<{ day: string; month: string }> = ({ day, month }) => (
  <div className={styles.date}>
    <b>{day}</b>
    {month}
  </div>
);
