import * as React from 'react';

import { c, Icon, press } from '../ui';
import { img } from '../images';
import { useStore } from '../store';
import { Card, Hero, ResCard, Row, Tiles } from '../blocks';
import { CalendarCard, EventsCard, NewsCard, WinsCard } from '../live';
import { CFG } from '../cfg';

const HomePage: React.FC = () => {
  const s = useStore();
  const go = (page: Parameters<typeof s.navigate>[0], anchor?: string): (() => void) => (): void => s.navigate(page, anchor);
  const bullets = (a: string, b: string, d: string): React.ReactNode => <ul><li>{a}</li><li>{b}</li><li>{d}</li></ul>;
  return (
    <>
      <Hero home title="Allure Sales Hub" sub="Your one-stop destination for capabilities, innovation, regulatory, marketing assets and sales resources."
        btn={{ label: 'Explore Capabilities', onClick: go('capabilities') }}
        facts={[
          { icon: 'factory', title: 'Hayward, CA', sub: 'Manufacturing Facility', onClick: go('capabilities', 'hayward') },
          { icon: 'factory', title: 'Scottsdale, AZ', sub: 'Manufacturing Facility', onClick: go('capabilities', 'scottsdale') }
        ]} />
      <Tiles widths={[269, 256, 240, 257, 248, 242]} items={[
        { icon: 'gear', title: 'Capabilities', desc: 'Facilities, Processes & Certifications', onClick: go('capabilities') },
        { icon: 'flask', title: 'Innovation', desc: 'New Formulas, Trends & Ingredient Library', onClick: go('innovation') },
        { icon: 'coins', title: 'Pricing', desc: 'Rate Cards, Quotations & Costing Guidelines', onClick: go('pricing') },
        { icon: 'shieldc', title: 'Regulatory', desc: 'Compliance, FDA, MoCRA & Restricted Substances', onClick: go('regulatory') },
        { icon: 'image', title: 'Marketing Assets', desc: 'Presentations, Photos, Videos & Brand Assets', onClick: go('marketing-assets') },
        { icon: 'cal', title: 'Events', desc: 'Trade Shows, Calendar & Event Resources', onClick: go('events') }
      ]} />
      <Row cols="400fr 411fr 393fr 322fr" mt={24}>
        <Card title="Company Capabilities" actions={<button type="button" className={c('iconBtn sm')} aria-label="Open Capabilities" onClick={go('capabilities', 'facilities')}><Icon n="arrowur" s={18} sw={1.8} /></button>}>
          <div className={c('fcard clk')} {...press(go('capabilities', 'hayward'))}>
            <img src={img.fac1} alt="" /><div><h4>Hayward, CA Facility</h4>{bullets('Contract Manufacturing', 'Filling & Assembly', 'Mass & Pilot Production')}</div>
          </div>
          <div className={c('hr')} style={{ margin: '13px 0' }} />
          <div className={c('fcard clk')} {...press(go('capabilities', 'scottsdale'))}>
            <img src={img.fac2} alt="" /><div><h4>Scottsdale, AZ Facility</h4>{bullets('Specialized Formulations', 'Innovation & Development', 'Scalable Manufacturing')}</div>
          </div>
        </Card>
        <NewsCard />
        <EventsCard limit={3} anchor="upcoming" />
        <ResCard cfg={CFG.quickLinks} />
      </Row>
      <Row cols="1fr 1.45fr" mt={18}>
        <WinsCard />
        <CalendarCard withList title="Events Calendar" />
      </Row>
    </>
  );
};

export default HomePage;
