import * as React from 'react';

import { c } from '../ui';
import { useStore } from '../store';
import { Card, Hero, ResCard, Row, Tiles } from '../blocks';
import { Onboarding } from '../live';
import { CFG } from '../cfg';

const STEPS: Array<[string, string]> = [
  ['Prospect', 'Identify brands that fit our categories'], ['Qualify', 'Budget, volume, timeline and fit'], ['Develop', 'Samples, formula and pricing'], ['Quote', 'Costing and approval'], ['Launch', 'Production and first shipment']
];

const PlaybookPage: React.FC = () => {
  const s = useStore();
  const go = (anchor: string): (() => void) => (): void => s.navigate('sales-playbook', anchor);
  return (
    <>
      <Hero crumb="Sales Playbook" title="Sales Playbook" sub="The sales process, qualification, battle cards, templates and onboarding for every new rep."
        btn={{ label: 'Start onboarding', onClick: go('onboarding') }}
        facts={[
          { icon: 'target', title: 'Sales Process', sub: 'Qualify to launch', onClick: go('process') },
          { icon: 'swords', title: 'Battle Cards', sub: 'Objection handling', onClick: go('battle') }
        ]} />
      <Tiles sq items={[
        { icon: 'target', title: 'Sales Process & Qualification', desc: 'Stages & criteria', onClick: go('process') },
        { icon: 'swords', title: 'Battle Cards', desc: 'Objection handling', onClick: go('battle') },
        { icon: 'mail', title: 'Email & Proposal Templates', desc: 'Ready-to-send', onClick: go('templates') },
        { icon: 'grad', title: 'New Rep Onboarding', desc: 'Training path', onClick: go('onboarding') }
      ]} />
      <Row cols="1fr">
        <Card title="Sales Process & Qualification" icon="target" anchor="process">
          <div className={c('steps')} style={{ '--c': 'repeat(5,1fr)' } as React.CSSProperties}>
            {STEPS.map((st: [string, string], i: number) => <div key={st[0]} className={c('step')}><i>{i + 1}</i><b>{st[0]}</b><span>{st[1]}</span></div>)}
          </div>
        </Card>
      </Row>
      <Row cols="1.35fr 1fr">
        <ResCard cfg={CFG.battle} />
        <ResCard cfg={CFG.templates} />
      </Row>
      <Row cols="1fr">
        <Onboarding cfg={CFG.onboarding} />
      </Row>
    </>
  );
};

export default PlaybookPage;
