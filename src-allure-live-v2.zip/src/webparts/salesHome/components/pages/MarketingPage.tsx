import * as React from 'react';

import { c } from '../ui';
import { img } from '../images';
import { useStore } from '../store';
import { Card, GroupPanel, Hero, ResCard, Row, SectionHead, Tiles } from '../blocks';
import { CFG } from '../cfg';

const SHOTS: Array<{ k: string; name: string }> = [
  { k: 'fac1', name: 'Hayward facility' }, { k: 'fac2', name: 'Scottsdale facility' }, { k: 'jar', name: 'Skincare hero' },
  { k: 'dropper', name: 'Serum close-up' }, { k: 'tube', name: 'Tube & packaging' }, { k: 'flower', name: 'Botanical lifestyle' }
];

const SWATCHES: Array<{ bg: string; fg: string; label: string }> = [
  { bg: '#0a3f52', fg: '#fff', label: 'NAVY #0A3F52' }, { bg: '#159bac', fg: '#fff', label: 'TEAL #159BAC' }, { bg: '#70cfdb', fg: '#0a3f52', label: 'CYAN #70CFDB' },
  { bg: '#fc6337', fg: '#fff', label: 'ORANGE #FC6337' }, { bg: '#e9f5f8', fg: '#0a3f52', label: 'TINT #E9F5F8' }
];

const MarketingPage: React.FC = () => {
  const s = useStore();
  const go = (anchor: string): (() => void) => (): void => s.navigate('marketing-assets', anchor);
  const brand = (): void => s.openModal(CFG.brandFiles.title, <GroupPanel cfg={CFG.brandFiles} />, { wide: true });
  const look = (name: string, src: string): void => s.openModal(name, <img src={src} alt={name} className={c('lightbox')} />, { wide: true });
  return (
    <>
      <Hero crumb="Marketing Assets" title="Marketing Assets" sub="Approved decks, brand guidelines, photos, videos and trade show materials, always current."
        btn={{ label: 'Download brand kit', icon: 'dl', onClick: brand }}
        facts={[
          { icon: 'image', title: 'Brand Assets', sub: 'Logos & guidelines', onClick: go('brand') },
          { icon: 'video', title: 'Photos & Videos', sub: 'Approved library', onClick: go('gallery') }
        ]} />
      <Tiles sq items={[
        { icon: 'file', title: 'Decks & One-Pagers', desc: 'Capabilities presentations', onClick: go('decks') },
        { icon: 'sparkle', title: 'Logos & Brand Guidelines', desc: 'Logo files & usage rules', onClick: go('brand') },
        { icon: 'image', title: 'Photos & Videos', desc: 'Facility & product media', onClick: go('gallery') },
        { icon: 'cal', title: 'Trade Show Materials', desc: 'Booth & print assets', onClick: go('trade') }
      ]} />
      <SectionHead title="Photos & Videos" sub="Approved for customer use. Select a photo to enlarge it." anchor="gallery" />
      <div className={c('gal')}>
        {SHOTS.map((p: { k: string; name: string }) => (
          <button key={p.k} type="button" className={c('shot')} onClick={() => look(p.name, img[p.k])}>
            <img className={c(p.k.indexOf('fac') === 0 ? '' : 'ct')} src={img[p.k]} alt={p.name} /><span>{p.name}</span>
          </button>
        ))}
      </div>
      <Row cols="1.3fr 1fr">
        <ResCard cfg={CFG.mktDecks} />
        <Card title="Logos & Brand Guidelines" icon="sparkle" anchor="brand">
          <img src={img.logo} alt="Allure Beauty Concepts" style={{ height: 54, width: 'auto', margin: '2px 0 16px' }} />
          <div style={{ fontSize: 13, color: '#5b6b73', marginBottom: 8 }}>Brand colors</div>
          <div className={c('sw')}>
            {SWATCHES.map((w: { bg: string; fg: string; label: string }) => (
              <button key={w.label} type="button" className={c('swb')} style={{ background: w.bg, color: w.fg }} onClick={() => { navigator.clipboard?.writeText(w.label.split(' ')[1]).catch(() => undefined); s.toast(`Copied ${w.label.split(' ')[1]}`); }}>{w.label}</button>
            ))}
          </div>
          <div style={{ display: 'flex', gap: 10, marginTop: 14, flexWrap: 'wrap' }}>
            <button type="button" className={c('btn line')} style={{ margin: 0 }} onClick={brand}>Logo pack and brand files</button>
          </div>
        </Card>
      </Row>
      <Row cols="1fr">
        <ResCard cfg={CFG.trade} />
      </Row>
    </>
  );
};

export default MarketingPage;
