import * as React from 'react';

import { c, Icon } from '../ui';
import { img } from '../images';
import { useStore } from '../store';
import { Card, GroupPanel, Hero, ResCard, ResTable, Row, Tiles, type IResCfg } from '../blocks';
import { Stats } from '../live';
import { CFG } from '../cfg';

const CapabilitiesPage: React.FC = () => {
  const s = useStore();
  const group = (cfg: IResCfg): (() => void) => (): void => s.openModal(cfg.title, <GroupPanel cfg={cfg} />, { wide: true });
  const facility = (anchor: string, name: string, pic: string, pts: string[], stats: IResCfg): React.ReactNode => (
    <Card title={name} icon="factory" anchor={anchor}>
      <div className={c('fac2')}>
        <img src={pic} alt="" />
        <ul>{pts.map((p: string) => <li key={p}>{p}</li>)}</ul>
      </div>
      <Stats cfg={stats} />
      <button type="button" className={c('btn')} style={{ marginTop: 2 }} onClick={group(CFG.capProfiles)}>Download facility profile <Icon n="dl" s={17} sw={2} /></button>
    </Card>
  );
  return (
    <>
      <Hero crumb="Capabilities" title="Capabilities" sub="Facility profiles, category capabilities, certifications and the case studies that prove them."
        btn={{ label: 'Download capabilities deck', icon: 'dl', onClick: group(CFG.capDecks) }}
        facts={[
          { icon: 'factory', title: 'Hayward, CA', sub: 'Manufacturing Facility', onClick: () => s.navigate('capabilities', 'hayward') },
          { icon: 'factory', title: 'Scottsdale, AZ', sub: 'Manufacturing Facility', onClick: () => s.navigate('capabilities', 'scottsdale') }
        ]} />
      <Tiles sq anchor="categories" items={[
        { icon: 'drop', title: 'Skincare', desc: 'Creams, serums, lotions & cleansers', onClick: group(CFG.catSkin) },
        { icon: 'wind', title: 'Haircare', desc: 'Shampoo, conditioner & treatments', onClick: group(CFG.catHair) },
        { icon: 'palette', title: 'Color Cosmetics', desc: 'Face, lip & eye products', onClick: group(CFG.catColor) },
        { icon: 'shieldc', title: 'OTC', desc: 'SPF, acne & drug-regulated products', onClick: group(CFG.catOtc) }
      ]} />
      <Row cols="1fr 1fr" anchor="facilities">
        {facility('hayward', 'Hayward, CA Facility', img.fac1, ['Contract manufacturing', 'Filling & assembly', 'Mass & pilot production'], CFG.capHayStats)}
        {facility('scottsdale', 'Scottsdale, AZ Facility', img.fac2, ['Specialized formulations', 'Innovation & development', 'Scalable manufacturing'], CFG.capScotStats)}
      </Row>
      <Row cols="1.35fr 1fr">
        <ResTable cfg={CFG.capCerts} cols={[{ head: 'Certification / audit', field: 'Title' }, { head: 'Facility', field: 'Sub' }, { head: 'Status', field: 'Tag' }, { head: 'Updated', field: 'Extra' }]} />
        <ResCard cfg={CFG.capCases} />
      </Row>
    </>
  );
};

export default CapabilitiesPage;
