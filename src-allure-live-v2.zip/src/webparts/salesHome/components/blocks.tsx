import * as React from 'react';

import { c, Icon, press, TONES, toneClass } from './ui';
import { img } from './images';
import { useGroup, useStore } from './store';
import { Form, type FormFiles, type FormValues, type IFieldCfg } from './forms';
import { dayNum, fmtLong, monShort, parts } from './data/dates';
import type { ILibFile, IResourceItem } from './data/types';
import type { PageKey } from './nav';

/* ---------- layout ---------- */

export interface IFact {
  icon: string;
  title: string;
  sub: string;
  onClick(): void;
}

export interface IHeroProps {
  home?: boolean;
  crumb?: string;
  title: string;
  sub: string;
  btn?: { label: string; icon?: string; onClick(): void };
  facts: IFact[];
}

export const Hero: React.FC<IHeroProps> = (props) => {
  const { firstName } = useStore();
  return (
    <div className={c(props.home ? 'hero' : 'hero sm')}>
      <img className={c('art')} src={img.hero} alt="" />
      <div className={c('copy')}>
        {props.home ? (
          <>
            <div className={c('eb')}>Sales team portal</div>
            <div className={c('w')}>Welcome{firstName && <>, <span className={c('hl')}>{firstName}</span></>}</div>
          </>
        ) : (
          <div className={c('cr')}>Home &nbsp;/&nbsp; {props.crumb}</div>
        )}
        <h1>{props.title}</h1>
        <p>{props.sub}</p>
        {props.btn && (
          <button type="button" className={c('btn')} onClick={props.btn.onClick}>
            {props.btn.label} <Icon n={props.btn.icon || 'arrowr'} s={17} sw={2} />
          </button>
        )}
      </div>
      <div className={c('panel')}>
        {props.facts.map((f: IFact) => (
          <div key={f.title} className={c('fac')} {...press(f.onClick)}>
            <div className={c('ib')}><Icon n={f.icon} s={28} sw={1.5} /></div>
            <div><b>{f.title}</b><span>{f.sub}</span></div>
            <div className={c('chv')}><Icon n="chev" s={24} sw={2} /></div>
          </div>
        ))}
      </div>
    </div>
  );
};

export interface ITile {
  icon: string;
  title: string;
  desc: string;
  onClick(): void;
}

export const Tiles: React.FC<{ items: ITile[]; sq?: boolean; widths?: number[]; anchor?: string }> = ({ items, sq, widths, anchor }) => {
  const cols: string = widths ? widths.map((w: number) => `${w}fr`).join(' ') : `repeat(${items.length},1fr)`;
  return (
    <div className={c(`tiles t${items.length}`)} style={{ '--c': cols } as React.CSSProperties} data-anchor={anchor}>
      {items.map((t: ITile, i: number) => (
        <div key={t.title} className={c(sq ? 'tile sq' : 'tile')} style={{ background: TONES[i % 6][0], color: TONES[i % 6][1] }} {...press(t.onClick)}>
          <Icon n={t.icon} s={44} sw={1.5} />
          <b>{t.title}</b>
          <span>{t.desc}</span>
        </div>
      ))}
    </div>
  );
};

export const Row: React.FC<{ cols: string; mt?: number; anchor?: string; children?: React.ReactNode }> = ({ cols, mt, anchor, children }) => (
  <div className={c('row r' + React.Children.count(children))} data-anchor={anchor} style={{ '--c': cols, marginTop: mt === undefined ? 22 : mt } as React.CSSProperties}>{children}</div>
);

export interface ICardProps {
  title?: string;
  icon?: string;
  anchor?: string;
  actions?: React.ReactNode;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export const Card: React.FC<ICardProps> = (props) => (
  <div className={c('card')} style={props.style} data-anchor={props.anchor}>
    {props.title && (
      <div className={c('ch')}>
        <h3>{props.icon && <Icon n={props.icon} s={22} />}{props.title}</h3>
        <div className={c('acts')}>{props.actions}</div>
      </div>
    )}
    {props.children}
  </div>
);

export const LinkBtn: React.FC<{ label: string; icon?: string; strong?: boolean; onClick(): void }> = ({ label, icon, strong, onClick }) => (
  <button type="button" className={c(strong ? 'vl add' : 'vl')} onClick={onClick}>
    {icon && <Icon n={icon} s={16} sw={2} />}{label}
  </button>
);

export const SectionHead: React.FC<{ title: string; sub?: string; anchor?: string }> = ({ title, sub, anchor }) => (
  <div className={c('sh')} data-anchor={anchor}><h2>{title}</h2><span>{sub}</span></div>
);

export const Tag: React.FC<{ text: string; tone?: string }> = ({ text, tone }) => (text ? <span className={c(('tag ' + toneClass(tone || '')).trim())}>{text}</span> : null);

export const Empty: React.FC<{ text: string }> = ({ text }) => <p className={c('empty')}>{text}</p>;

/* ---------- documents, links and lists backed by the Resources list ---------- */

export type Variant = 'docs' | 'plain' | 'thumbs' | 'dated' | 'qlinks';

export interface IResCfg {
  section: PageKey;
  group: string;
  title: string;
  icon: string;
  variant: Variant;
  anchor?: string;
  limit?: number;
  /** Labels of the optional columns in the add/edit form. */
  titleLabel?: string;
  subLabel?: string;
  extraLabel?: string;
  tagLabel?: string;
  dated?: boolean;
  addLabel?: string;
  singular?: string;
}

const TONE_OPTIONS: Array<{ value: string; label: string }> = [
  { value: '', label: 'Teal (default)' }, { value: 'g', label: 'Green' }, { value: 'o', label: 'Orange' }, { value: 'b', label: 'Blue' }, { value: 'p', label: 'Navy' }
];

export const resourceFields = (cfg: IResCfg): IFieldCfg[] => {
  const f: IFieldCfg[] = [
    { name: 'Title', label: cfg.titleLabel || 'Title', required: true },
    { name: 'Sub', label: cfg.subLabel || 'Description', placeholder: 'For example: PDF · 4 pages' }
  ];
  if (cfg.extraLabel) {
    f.push({ name: 'Extra', label: cfg.extraLabel, type: 'textarea' });
  }
  if (cfg.dated) {
    f.push({ name: 'ItemDate', label: 'Date', type: 'date' });
  }
  f.push({ name: 'Tag', label: cfg.tagLabel || 'Label (optional)', placeholder: 'For example: Current' });
  f.push({ name: 'TagTone', label: 'Label colour', type: 'select', options: TONE_OPTIONS, placeholder: 'Teal (default)' });
  f.push({ name: 'Link', label: 'Link (optional)', placeholder: 'Paste a SharePoint file link or web address' });
  return f;
};

export const useResourceActions = (cfg: IResCfg): {
  addNew(): void;
  edit(item: IResourceItem): void;
  activate(item: IResourceItem): void;
  viewAll(): void;
} => {
  const store = useStore();
  const { data, openModal, closeModal, openLink } = store;

  const fileSize = (n: number): string => (n >= 1048576 ? `${(n / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1024))} KB`);

  const form = (item?: IResourceItem): React.ReactNode => {
    const hasFile: boolean = !!(item && item.FileId);
    const initial: FormValues | undefined = item ? {
      Title: item.Title, Sub: item.Sub, Extra: item.Extra, Tag: item.Tag, TagTone: item.TagTone, Link: hasFile ? '' : item.Link, ItemDate: item.ItemDate,
      PickId: hasFile && !item!.FileMissing ? String(item!.FileId) : '', FileName: item ? item.FileName : ''
    } : undefined;
    let fields: IFieldCfg[] = resourceFields(cfg);
    if (store.supportsFiles) {
      const fileFields: IFieldCfg[] = [
        { name: 'File', label: hasFile ? 'Replace the file (optional)' : 'Upload a file', type: 'file', hint: 'Saved in the SH_Documents library. Up to 100 MB.' },
        {
          name: 'PickId', label: 'Attached file', type: 'select', placeholder: 'No file',
          options: store.files.map((f: ILibFile) => ({ value: String(f.Id), label: `${f.Name} (${fileSize(f.Size)})` })),
          hint: item && item.FileMissing ? 'The attached file was removed from the library. Choose another or upload a new one.' : 'Or choose a file that is already in the library.'
        }
      ];
      if (hasFile && !item!.FileMissing) {
        fileFields.push({ name: 'FileName', label: 'File name in the library', hint: 'Renaming here renames the file in SharePoint too.' });
      }
      const at: number = fields.map((x: IFieldCfg) => x.name).indexOf('Link');
      fields = fields.slice(0, at).concat(fileFields, [{ ...fields[at], label: 'Or a web link (optional)' }]);
    }
    return (
      <Form
        fields={fields}
        initial={initial}
        submitLabel={item ? 'Save changes' : 'Add'}
        footnote={store.supportsFiles ? 'Deleting an item that has an uploaded file also moves that file to the site Recycle Bin, unless another item uses it.' : undefined}
        onSubmit={async (v: FormValues, files: FormFiles): Promise<boolean> => {
          const values: { [k: string]: string | number } = {
            Title: v.Title.trim(), Sub: v.Sub || '', Tag: v.Tag || '', TagTone: v.TagTone || '', Link: (v.Link || '').trim()
          };
          if (cfg.extraLabel) { values.Extra = v.Extra || ''; }
          if (cfg.dated) { values.ItemDate = v.ItemDate || ''; }
          const before: number = item ? item.FileId : 0;
          let fileId: number = before;
          if (store.supportsFiles) {
            try {
              const up: File | undefined = files.File;
              if (up) {
                const lf: ILibFile = await store.uploadFile(up, cfg.section, cfg.group);
                fileId = lf.Id;
                values.FileName = lf.Name;
                if (!values.Sub) { values.Sub = `${(up.name.split('.').pop() || 'File').toUpperCase()} · ${fileSize(up.size)}`; }
              } else if (v.PickId) {
                fileId = Number(v.PickId);
                const picked: ILibFile | undefined = store.files.filter((f: ILibFile) => f.Id === fileId)[0];
                values.FileName = picked ? picked.Name : '';
                if (picked && fileId === before && v.FileName && v.FileName.trim() && v.FileName.trim() !== picked.Name) {
                  await store.renameFile(fileId, v.FileName.trim());
                }
              } else {
                fileId = 0;
                values.FileName = '';
              }
            } catch (e) {
              store.toast(e instanceof Error ? e.message : 'The file could not be saved. Please try again.', true);
              return false;
            }
            values.FileId = fileId;
            if (fileId) { values.Link = ''; }
          }
          let ok: boolean;
          if (item) {
            ok = await store.update('resources', item.Id, values, 'Changes saved');
          } else {
            const next: number = data.resources.reduce((m: number, r: IResourceItem) => Math.max(m, r.SortOrder), 0) + 1;
            ok = await store.add('resources', { ...values, Section: cfg.section, Group: cfg.group, SortOrder: next }, `${cfg.singular || 'Item'} added`);
          }
          if (ok && before && before !== fileId) {
            await store.releaseFile(before, item ? item.Id : undefined);
          }
          return ok;
        }}
        onDelete={item ? async (): Promise<boolean> => {
          const ok: boolean = await store.remove('resources', item.Id, `${cfg.singular || 'Item'} deleted`);
          if (ok && item.FileId) { await store.releaseFile(item.FileId, item.Id); }
          return ok;
        } : undefined}
      />
    );
  };

  const edit = (item: IResourceItem): void => openModal(`Edit ${(cfg.singular || 'item').toLowerCase()}`, form(item), { replace: false });

  const detail = (item: IResourceItem): void => {
    const rows: Array<[string, string]> = [['Description', item.Sub], [cfg.extraLabel || 'Details', cfg.extraLabel ? item.Extra : ''], ['Label', item.Tag], ['Date', item.ItemDate ? fmtLong(item.ItemDate) : '']];
    openModal(item.Title, (
      <div>
        <dl className={c('dl')}>
          {rows.filter((r: [string, string]) => !!r[1]).map((r: [string, string]) => <React.Fragment key={r[0]}><dt>{r[0]}</dt><dd>{r[1]}</dd></React.Fragment>)}
          {!item.Sub && !item.Extra && !item.Tag && <dd>No more details yet. Use Edit to add a description or a link to the file.</dd>}
        </dl>
        <div className={c('formBtns')}>
          <span className={c('grow')} />
          <button type="button" className={c('btn line')} onClick={closeModal}>Close</button>
          <button type="button" className={c('btn')} onClick={() => openModal(`Edit ${(cfg.singular || 'item').toLowerCase()}`, form(item), { replace: true })}>Edit</button>
        </div>
      </div>
    ));
  };

  return {
    addNew: (): void => openModal(cfg.addLabel || `Add ${(cfg.singular || 'item').toLowerCase()}`, form()),
    edit,
    activate: (item: IResourceItem): void => {
      if (item.FileMissing) { store.toast('This file was removed from the library. Edit the item to attach another file.', true); } else if (item.Link) { openLink(item.Link); } else { detail(item); }
    },
    // eslint-disable-next-line @typescript-eslint/no-use-before-define
    viewAll: (): void => openModal(cfg.title, <GroupPanel cfg={cfg} />, { wide: true })
  };
};

const iconFor = (variant: Variant, cfg: IResCfg): string => (variant === 'qlinks' ? 'cal' : cfg.icon);

export const ResList: React.FC<{ cfg: IResCfg; items: IResourceItem[] }> = ({ cfg, items }) => {
  const act = useResourceActions(cfg);
  if (!items.length) {
    return <Empty text={`Nothing here yet. Use "${cfg.addLabel || 'Add'}" to create the first one.`} />;
  }
  const pencil = (it: IResourceItem): React.ReactNode => (
    <button type="button" className={c('iconBtn sm ed')} aria-label={`Edit ${it.Title}`} onClick={(e: React.MouseEvent) => { e.stopPropagation(); act.edit(it); }}><Icon n="edit" s={16} sw={1.8} /></button>
  );
  return (
    <>
      {items.map((it: IResourceItem, i: number) => {
        const t: [string, string] = TONES[i % 6];
        if (cfg.variant === 'qlinks') {
          return (
            <div key={it.Id} className={c('ql')} {...press(() => act.activate(it))}>
              <Icon n={iconFor('qlinks', cfg)} s={20} sw={1.6} /><span>{it.Title}</span>
              <span className={c('grow')} />{pencil(it)}<Icon n={it.Link.indexOf('page:') === 0 ? 'chev' : 'ext'} s={17} sw={1.6} />
            </div>
          );
        }
        const lead: React.ReactNode =
          cfg.variant === 'thumbs' ? <img className={c('th')} src={[img.n1, img.n2, img.n3][i % 3]} alt="" />
            : cfg.variant === 'dated' && parts(it.ItemDate).valid ? <div className={c('db')}><i>{monShort(it.ItemDate)}</i><b>{dayNum(it.ItemDate)}</b></div>
              : <div className={c('th ph')} style={{ background: t[0], color: t[1] }}><Icon n={cfg.icon} s={26} sw={1.5} /></div>;
        return (
          <div key={it.Id} className={c('lr')} {...press(() => act.activate(it))}>
            {lead}
            <div className={c('g')}><b>{it.Title}</b>{it.Sub && <span className={c('s')}>{it.Sub}</span>}</div>
            <div className={c('ri')}>
              <Tag text={it.Tag} tone={it.TagTone} />
              {pencil(it)}
              <Icon n={cfg.variant === 'docs' ? 'dl' : 'chev'} s={18} sw={1.7} />
            </div>
          </div>
        );
      })}
    </>
  );
};

/** A titled card that lists one group of the Resources list, with Add and View all. */
export const ResCard: React.FC<{ cfg: IResCfg; style?: React.CSSProperties }> = ({ cfg, style }) => {
  const items: IResourceItem[] = useGroup(cfg.section, cfg.group);
  const act = useResourceActions(cfg);
  const limit: number = cfg.limit || 5;
  return (
    <Card title={cfg.title} icon={cfg.icon} anchor={cfg.anchor} style={style}
      actions={<>
        <LinkBtn label="Add" icon="plus" strong onClick={act.addNew} />
        {items.length > limit && <LinkBtn label="View all" onClick={act.viewAll} />}
      </>}>
      <ResList cfg={cfg} items={items.slice(0, limit)} />
    </Card>
  );
};

/** Full list in a popup (View all, category tiles, hero download buttons). */
export const GroupPanel: React.FC<{ cfg: IResCfg }> = ({ cfg }) => {
  const items: IResourceItem[] = useGroup(cfg.section, cfg.group);
  const act = useResourceActions(cfg);
  return (
    <div>
      <div className={c('panelBar')}><LinkBtn label={cfg.addLabel || 'Add'} icon="plus" strong onClick={act.addNew} /></div>
      <ResList cfg={cfg} items={items} />
    </div>
  );
};

export interface ITableCol {
  head: string;
  field: 'Title' | 'Sub' | 'Extra' | 'Tag' | 'ItemDate' | 'link';
}

/** A table whose rows come from one group of the Resources list. */
export const ResTable: React.FC<{ cfg: IResCfg; cols: ITableCol[] }> = ({ cfg, cols }) => {
  const items: IResourceItem[] = useGroup(cfg.section, cfg.group);
  const act = useResourceActions(cfg);
  return (
    <Card title={cfg.title} icon={cfg.icon} anchor={cfg.anchor} actions={<LinkBtn label="Add" icon="plus" strong onClick={act.addNew} />}>
      {!items.length ? <Empty text="No rows yet. Use Add to create the first one." /> : (
        <table>
          <tbody>
            <tr className={c('hd')}>{cols.map((col: ITableCol) => <th key={col.head}>{col.head}</th>)}<th /></tr>
            {items.map((it: IResourceItem) => (
              <tr key={it.Id} className={c('clk')} {...press(() => act.activate(it))}>
                {cols.map((col: ITableCol) => (
                  <td key={col.head} data-label={col.head}>
                    {col.field === 'Title' ? <b>{it.Title}</b>
                      : col.field === 'Tag' ? <Tag text={it.Tag} tone={it.TagTone} />
                        : col.field === 'ItemDate' ? fmtLong(it.ItemDate)
                          : col.field === 'link' ? (it.Link ? <Icon n="ext" s={17} sw={1.6} /> : null)
                            : it[col.field]}
                  </td>
                ))}
                <td data-label=""><button type="button" className={c('iconBtn sm ed')} aria-label={`Edit ${it.Title}`} onClick={(e: React.MouseEvent) => { e.stopPropagation(); act.edit(it); }}><Icon n="edit" s={16} sw={1.8} /></button></td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </Card>
  );
};

export const openGroupModal = (open: (title: string, body: React.ReactNode, o?: { wide?: boolean }) => void, cfg: IResCfg): void => {
  open(cfg.title, <GroupPanel cfg={cfg} />, { wide: true });
};
