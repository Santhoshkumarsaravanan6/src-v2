import { LISTS, listDef, type IFieldDef } from './lists';
import { SEED } from './seed';
import type { FieldValues, IDataService, IItem, ILibFile, ListKey } from './types';

type Store = { [key: string]: Array<{ [name: string]: unknown }> };
const STORAGE_KEY: string = 'allure-sales-hub-demo-v1';

/** Keeps the data in this browser only. Used for local previews and when the SharePoint lists cannot be created. */
export class MemDataService implements IDataService {
  public readonly persistent: boolean = false;
  public readonly supportsFiles: boolean = false;
  public readonly libraryUrl: string = '';
  private _store: Store = {};
  private _next: number = 1;

  public init(): Promise<void> {
    let saved: Store | undefined;
    try {
      const raw: string | null = window.localStorage.getItem(STORAGE_KEY);
      saved = raw ? (JSON.parse(raw) as Store) : undefined;
    } catch {
      saved = undefined;
    }
    if (saved) {
      this._store = saved;
      this._next = 1 + Math.max(0, ...Object.keys(saved).map((k: string) => Math.max(0, ...saved![k].map((r: { [name: string]: unknown }) => Number(r.Id) || 0))));
    } else {
      for (const def of LISTS) {
        this._store[def.key] = SEED[def.key].map((row: FieldValues) => this._withDefaults(def.key, row, this._next++));
      }
      this._save();
    }
    return Promise.resolve();
  }

  public getAll(key: ListKey): Promise<IItem[]> {
    return Promise.resolve((this._store[key] || []).map((r: { [name: string]: unknown }) => ({ ...r }) as unknown as IItem));
  }

  public add(key: ListKey, values: FieldValues): Promise<void> {
    this._store[key].push(this._withDefaults(key, values, this._next++));
    this._save();
    return Promise.resolve();
  }

  public update(key: ListKey, id: number, values: FieldValues): Promise<void> {
    const row: { [name: string]: unknown } | undefined = this._store[key].filter((r: { [name: string]: unknown }) => r.Id === id)[0];
    if (row) {
      Object.keys(values).forEach((k: string) => { row[k] = values[k]; });
      this._save();
    }
    return Promise.resolve();
  }

  public remove(key: ListKey, id: number): Promise<void> {
    this._store[key] = this._store[key].filter((r: { [name: string]: unknown }) => r.Id !== id);
    this._save();
    return Promise.resolve();
  }

  public listFiles(): Promise<ILibFile[]> {
    return Promise.resolve([]);
  }

  public uploadFile(): Promise<ILibFile> {
    return Promise.reject(new Error('Files can be uploaded once the hub runs inside SharePoint.'));
  }

  public renameFile(): Promise<void> {
    return Promise.reject(new Error('Files can be renamed once the hub runs inside SharePoint.'));
  }

  public deleteFile(): Promise<void> {
    return Promise.resolve();
  }

  private _withDefaults(key: ListKey, values: FieldValues, id: number): { [name: string]: unknown } {
    const row: { [name: string]: unknown } = { Id: id, Title: '', Created: new Date().toISOString() };
    listDef(key).fields.forEach((f: IFieldDef) => { row[f.name] = f.kind === 'Number' ? 0 : ''; });
    Object.keys(values).forEach((k: string) => { row[k] = values[k]; });
    return row;
  }

  private _save(): void {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(this._store));
    } catch {
      // Storage can be blocked; the data then lasts for this visit only.
    }
  }
}
