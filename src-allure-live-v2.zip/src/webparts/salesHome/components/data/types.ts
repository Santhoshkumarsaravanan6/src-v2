/** Keys of the SharePoint lists that back the Sales Hub. */
export type ListKey = 'events' | 'news' | 'wins' | 'resources' | 'accounts' | 'requests';

export interface IItem {
  Id: number;
  Title: string;
  Created?: string;
}

/** Dates are stored as plain text "YYYY-MM-DD" so they never shift with time zones. */
export interface IEventItem extends IItem {
  EventDate: string;
  Location: string;
  EventType: string;
  Notes: string;
}

export interface INewsItem extends IItem {
  PublishDate: string;
  Summary: string;
  Link: string;
}

export interface IWinItem extends IItem {
  Summary: string;
  Category: string;
}

/** One generic row used by every document list, table, link list, org chart and progress bar. */
export interface IResourceItem extends IItem {
  Section: string;
  Group: string;
  Sub: string;
  Extra: string;
  Tag: string;
  TagTone: string;
  Link: string;
  ItemDate: string;
  SortOrder: number;
  /** Id of the file in the SH_Documents library (0 = no file attached). */
  FileId: number;
  /** Name of the attached file, kept so the row still reads well if the library is unavailable. */
  FileName: string;
  /** Filled in by the hub when it loads: the file was deleted from the library. */
  FileMissing?: boolean;
}

/** A file in the SH_Documents library. */
export interface ILibFile {
  Id: number;
  Name: string;
  /** Absolute address of the file. */
  Url: string;
  Size: number;
  Modified: string;
  /** Filled when the hub uploaded the file; empty for files added straight to the library. */
  Section: string;
  Group: string;
}

export interface IAccountItem extends IItem {
  Segment: string;
  Owner: string;
  Stage: string;
  PlanLink: string;
}

export interface IRequestItem extends IItem {
  RequestType: string;
  Category: string;
  Quantity: string;
  TargetDate: string;
  Contact: string;
  Notes: string;
  Status: string;
}

export interface IListData {
  events: IEventItem[];
  news: INewsItem[];
  wins: IWinItem[];
  resources: IResourceItem[];
  accounts: IAccountItem[];
  requests: IRequestItem[];
}

export type FieldValues = { [name: string]: string | number };

export interface IDataService {
  /** True when data is saved in SharePoint lists; false when it only lives in this browser. */
  readonly persistent: boolean;
  /** Creates the lists (and sample content) the first time the hub is opened. */
  init(): Promise<void>;
  getAll(key: ListKey): Promise<IItem[]>;
  add(key: ListKey, values: FieldValues): Promise<void>;
  update(key: ListKey, id: number, values: FieldValues): Promise<void>;
  remove(key: ListKey, id: number): Promise<void>;

  /** True when files can be stored in the SH_Documents library. */
  readonly supportsFiles: boolean;
  /** Address of the SH_Documents library (empty when files are not supported). */
  readonly libraryUrl: string;
  listFiles(): Promise<ILibFile[]>;
  uploadFile(file: File, section: string, group: string): Promise<ILibFile>;
  renameFile(id: number, newName: string): Promise<void>;
  /** Moves the file to the site Recycle Bin. */
  deleteFile(id: number): Promise<void>;
}
